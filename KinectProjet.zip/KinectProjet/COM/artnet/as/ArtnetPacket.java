//  ArtnetPacket.java
//  Created by Bernard Thirion 20/02/2011

package artnet.as;

//import osc.space.Node;

public abstract class ArtnetPacket {

   /*
   public void interpret(Node space) {
      this.print();
   }
  */
      
}
