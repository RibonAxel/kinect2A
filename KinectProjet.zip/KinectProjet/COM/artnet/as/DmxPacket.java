//  DmxPacket.java
//  Created by Bernard Thirion 20/02/2011

package artnet.as;

public class DmxPacket extends ArtnetPacket {
   
   private final static int FRAME_LENGTH = 512;          // could be more dynamic

   private int[] channels = new int[FRAME_LENGTH];
   
   public DmxPacket() {
 
   }
   
   public int channelValue(int channel) {
      return channels[channel - 1]; 
   }
   
   public void channelValue(int channel, int value) {
      channels[channel - 1] = value; 
   }
   
      
}
