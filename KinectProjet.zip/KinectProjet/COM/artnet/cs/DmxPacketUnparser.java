//  DmxPacketUnparser.java
//  Created by Bernard Thirion on 21/12/2007

package artnet.cs;

import artnet.as.DmxPacket;
import java.nio.ByteBuffer;
import artnet.stream.ArtnetSink;

public class DmxPacketUnparser extends PacketUnparser {

   private final static int FRAME_LENGTH  =      512;          // could be more dynamic
   private final static int OP_CODE       =   0x5000;          // OpOutput
   private final static int BUFFER_SIZE   = 18 + FRAME_LENGTH; // Header + DMX Frame

   public DmxPacketUnparser() { 
      buffer = ByteBuffer.allocateDirect(BUFFER_SIZE);
   }

   protected void unparseSequenceNumber(int n) { 
      buffer.put((byte) (n));
   }
 
   protected void unparsePhysical() { 
      buffer.put((byte) 0);
   }
   
   protected void unparseUniverse(ArtnetSink destination) { 
      int s = destination.subnet()   & 0x0f;
      int u = destination.universe() & 0x0f;
      int v = (s << 4) | u;
      buffer.put((byte) 0);
      buffer.put((byte) v);
   }   

   protected void unparseDmxFrameLength() { // big endian
      buffer.putShort((short) FRAME_LENGTH); 
   }

   protected void unparseDmxFrame(DmxPacket packet) { 
      for (int i = 1; i <= FRAME_LENGTH; i++) {
         buffer.put((byte) packet.channelValue(i));
      }
    }   
   
   public ByteBuffer unparse(ArtnetSink destination, DmxPacket packet) {
      buffer.clear();
      this.unparseArtnetTag();
      this.unparseOpCode(OP_CODE);
      this.unparseProtocolNumber();
      this.unparseSequenceNumber(destination.sequenceNumber());
      this.unparsePhysical();
      this.unparseUniverse(destination);
      this.unparseDmxFrameLength();
      this.unparseDmxFrame(packet);
      buffer.flip();
      //dump(30);
      return buffer;
   }
      
}
