//  PacketUnparser.java
//  Created by Bernard Thirion on 21/12/2007

package artnet.cs;

import java.util.Date;
import java.nio.ByteBuffer;

public class PacketUnparser {

   private final static short PROTOCOL_REVISION_NUMER = 14;

   private final static byte[] ID_TAG = new byte[] {
         (byte) 'A', (byte) 'r', (byte) 't', (byte) '-', 
         (byte) 'N', (byte) 'e', (byte) 't', (byte)  0 
   };

   protected ByteBuffer buffer;
      
   protected void unparseArtnetTag() {
      buffer.put(ID_TAG);  
   }
   
   protected void unparseOpCode(int OpCode) { // little endian 
      byte B0 = (byte)  (OpCode       & 0xff);
      byte B1 = (byte) ((OpCode >> 8) & 0xff);
      buffer.put(B0); buffer.put(B1);  
   }
    
   protected void unparseProtocolNumber() { // big endian
      buffer.putShort(PROTOCOL_REVISION_NUMER);
   }
 

   
   protected void dump(int max) {
      for (int i = buffer.position(); (i < buffer.limit()) & (i < max) ; i++ ) {
         System.out.println(buffer.get() );
      }
      buffer.rewind();
   }
       
}
