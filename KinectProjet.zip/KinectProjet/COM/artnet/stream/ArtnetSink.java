// ArtnetSink.java// Created by Bernard Thirion on 20/02/2011

package artnet.stream;

import artnet.as.DmxPacket;
import artnet.cs.DmxPacketUnparser;

import stream.Sink;
import java.nio.ByteBuffer;

public class ArtnetSink {

   private int subnet;
   private int universe;
   private int sequenceNumber;
   
   DmxPacketUnparser unparser;
   Sink              sink;
   
   public ArtnetSink(Sink sink, int subnet,int universe) {
      this.sink           = sink;
      this.subnet         = subnet;
      this.universe       = universe;
      this.sequenceNumber = 0;
      unparser            = new DmxPacketUnparser();   
   }

   public int subnet()         { return this.subnet;         }
   public int universe()       { return this.universe;       }
   public int sequenceNumber() { return this.sequenceNumber; }
   
   public void send(DmxPacket packet) {
      ByteBuffer data = unparser.unparse(this, packet);
      sink.send(data); 
      sequenceNumber = (sequenceNumber + 1) % 256;
   }

}
