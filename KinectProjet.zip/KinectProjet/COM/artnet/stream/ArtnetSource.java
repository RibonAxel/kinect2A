// ArtnetSource.java
// Created by Bernard Thirion on 20/02/2011

package artnet.stream;

import java.nio.ByteBuffer;
import stream.Source;
//import osc.cs.PacketParser;
//import osc.as.OSCPacket;

public class ArtnetSource {

   private Source       source;
//   private PacketParser parser;
   
   public ArtnetSource(Source source) {
      this.source = source;
//      this.parser = new PacketParser();
   }

/*
   public OSCPacket receive() {
      ByteBuffer buffer = source.receive();
      return parser.parse(buffer); 
   }
*/
   
}
