//  Sink.java
//  Created by Bernard Thirion on Sat Dec 22 2007.

package stream;

import java.nio.ByteBuffer;

public abstract class Sink {
   public abstract void send(ByteBuffer buffer);
}
