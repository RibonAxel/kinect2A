//  Source.java
//  Created by Bernard Thirion on Sat Dec 24 2005.

package stream;

import java.nio.ByteBuffer;

public abstract class Source {

   protected ByteBuffer buffer;

   public ByteBuffer receive() {
      return this.buffer;
   }

}
