package stream;
//  Eclat.java
//  Created by Bernard Thirion on 20/02/11.

import artnet.as.*;
import artnet.cs.*;

import artnet.stream.ArtnetSink;

import java.nio.ByteBuffer;
import java.net.InetAddress;

public class Eclat {

  // private static final String ADDRESS = "255.255.255.255";

 //  private static final String ADDRESS  = "192.168.1.7";

  private static final String ADDRESS  = "10.59.14.101";
   private static final int ARTNET_PORT = 6454;
   private static final int SUBNET      = 0;
   private static final int UNIVERSE    = 0;
   
   public static void main (String args[]) {
      try {
         InetAddress address = InetAddress.getByName(ADDRESS);
         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
         DmxPacket packet = new DmxPacket();
         while (true) {
        	 

         //	packet.channelValue(1, 180);
         	
         	
            for (int i = 1; i <= 10; i++ ) {
            	
            	 ///*//demo max kolor 36
            	packet.channelValue(2, 20 * i);
                packet.channelValue(3, 3 * i);
                packet.channelValue(4, 0 * i);
                packet.channelValue(7, 20 * i);
                packet.channelValue(8, 20 * i);
                packet.channelValue(6, 20 * i); 
                //*/
                /*//demo led vision curtain + jaguar
            	packet.channelValue(14, 20 * i);
            	packet.channelValue(15, 13 * i);
            	packet.channelValue(16, 20 * i);  
            	packet.channelValue(17, 20 * i);
       
            	packet.channelValue(2, 20 * i);
            	
            	packet.channelValue(3, 3 * i);
            	packet.channelValue(4, 4 * i);
            	packet.channelValue(7, 20 * i);
            	packet.channelValue(8, 20 * i);
               
            	packet.channelValue(1, 2 * i);
            	packet.channelValue(5, 45 * i);
            	packet.channelValue(6, 20 * i); //COULEUR
                packet.channelValue(9, 13 * i);
            	packet.channelValue(10, 20 * i);
            	packet.channelValue(11, 20 * i);
            	packet.channelValue(12, 2 * i);
            	packet.channelValue(13, 45 * i);
            	//*/
               
               sink.send(packet );
               Thread.sleep(200);
             }
             for (int i = 9; i > 0; i-- ) {
            	 
            	 /*//demo max kolor 36
            	  packet.channelValue(2, 20 * i);
                  packet.channelValue(3, 0 * i);
                  packet.channelValue(4, 3 * i);
                  packet.channelValue(7, 20 * i);
                  packet.channelValue(8, 20 * i);
                  packet.channelValue(6, 20 * i); 
                  */
            	 
            	 /*//demo 
            	 packet.channelValue(14, 20 * i);
                 packet.channelValue(15, 13 * i);
                 packet.channelValue(16, 20 * i);
                 packet.channelValue(17, 20 * i);
                       
                 packet.channelValue(2, 20 * i);
                
                 packet.channelValue(3, 7 * i);
                 packet.channelValue(4, 3 * i);
               packet.channelValue(7, 20 * i);
                 packet.channelValue(8, 20 * i);

               
                 packet.channelValue(1, 2 * i);
                               packet.channelValue(5, 45 * i);
                 packet.channelValue(6, 20 * i); //COULEUR
                 packet.channelValue(9, 13 * i);
                 packet.channelValue(10, 20 * i);
                 packet.channelValue(11, 20 * i);
                 packet.channelValue(12, 2 * i);
                 packet.channelValue(13, 45 * i);
                 //*/
        
               sink.send(packet );
               Thread.sleep(200);
            }
         }
      } catch (Exception e) { System.out.println (e); }
   }
}
