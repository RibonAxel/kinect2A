//  UDPPacketSink.java
//  Created by Bernard Thirion on Sat Dec 22 2007.

package stream;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;

public class UDPSink extends Sink {
   private SocketAddress   target;
	private DatagramChannel	channel;
   
   public UDPSink(InetAddress targetHost, int targetPort) throws java.net.SocketException, java.io.IOException {
      channel = DatagramChannel.open();
      channel.socket().setBroadcast(true);
      channel.configureBlocking(true);
      target = new InetSocketAddress(targetHost, targetPort);
      System.out.println(target);
   }
   
   public void send(ByteBuffer packet) {
      // System.out.println(packet);
      try {
         channel.send(packet, target);
      } catch (Exception e) { System.out.println (e); }      
   }
}
