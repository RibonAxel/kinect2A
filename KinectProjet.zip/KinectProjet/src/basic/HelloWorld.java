package basic;

import pi.executive.Executive;
import pi.executive.FunctionalAgent;

public class HelloWorld implements FunctionalAgent {

	public void control() {
		System.out.println ("hello world");
	}
   
   public static void test() {
      Executive executive = new Executive(0.5, 0.010);
      executive.plugAgent(new HelloWorld());
      executive.start();
   }

}
