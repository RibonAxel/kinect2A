package basic;

import pi.executive.Executive;
import pi.executive.FunctionalAgent;
import java.io.PrintStream;

public class HelloWorld_1 implements FunctionalAgent {
   private PrintStream out;
   
   public HelloWorld_1(PrintStream out) {
      this.out = out;
   }
   
	public void control() {
		out.println ("hello world");
	}
   
   public static void test() {
      Executive executive = new Executive();
      executive.plugAgent(new HelloWorld_1(System.out));
      executive.start();
   }

}
