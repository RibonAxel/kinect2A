package basic;

import pi.executive.Executive;
import pi.executive.ContinuousAgent;
import java.io.PrintStream;

public class HelloWorld_2 implements ContinuousAgent {
   private boolean done = false;
   private PrintStream out;
   
   public HelloWorld_2(PrintStream out) {
      this.out = out;
   }
   
   public void control() {
		if (!done) out.println ("hello world");
	}

	public void delta(double dt) {
      done = true;
   }
   
   public static void test() {
      Executive executive = new Executive();
      executive.plugAgent(new HelloWorld_2(System.out));
      executive.start();
   }
   
}
