package record;

import java.util.ArrayList;

import pi.endpoint.DoubleValue;
import pi.executive.ContinuousAgent;

public class Recorder implements ContinuousAgent{
	
	private DoubleValue sourceValue;
	private ArrayList<Double> values;
	private boolean recording = false;
	
	public Recorder() {};
	
	public void start(DoubleValue recordedValue){
		this.recording = true;
		this.sourceValue = recordedValue;
		this.values = new ArrayList<Double>();
	}
	
	public void stop(){
		this.recording = false;
	}
	
	public String save(){
		return this.toString();
	}

	public String toString(){
		String result = "";
		for(Double value: values){
			result += value.toString() + "#";
		}
		return result;
	}
	
	@Override
	public void control() {
	}

	@Override
	public void delta(double dt) {
		if(recording)
			this.values.add(this.sourceValue.value());
	}
	
	

}
