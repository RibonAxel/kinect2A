//created by BB on 26 05 11

package record; 

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import pi.endpoint.DoubleValue;
import pi.executive.ContinuousAgent;

public class Player implements ContinuousAgent {

	//Map<DoubleValue, ArrayList<Double>> outputs = new HashMap<DoubleValue, ArrayList<Double>>();
	DoubleValue output;
	ArrayList<Double> values = new  ArrayList<Double>();
	Boolean playing = false;
	Iterator<Double> it;
	double instantValue;
	
	public Player(){
		
	}
	
	public void setOutput(DoubleValue output, String stringValues){
		StringTokenizer tokenizer = new StringTokenizer(stringValues, "#");
		while(tokenizer.hasMoreTokens()){
			this.values.add(new Double(tokenizer.nextToken()));
		}
		this.output = output;
	}
	
	public void start(){
		this.playing = true;
		this.it = this.values.iterator();
	}
	public void stop(){
		this.playing = false;
	}
	
	@Override
	public void control() {
		if(playing)
			output.value(instantValue);

	}

	@Override
	public void delta(double dt) {
		if(this.playing)
			if(it.hasNext())
				this.instantValue = it.next();
			
	}

}
