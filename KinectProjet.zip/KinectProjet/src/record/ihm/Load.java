package record.ihm;

import java.io.*;

public class Load {


	public static String loadData(File fichier){
		try {
			BufferedReader buffer = new BufferedReader(new FileReader (fichier));
			String ligne, donnees = "";
			while ((ligne=buffer.readLine()) != null){
				donnees = donnees + ligne + "\n";
			}
			return donnees;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	} 
}
