package record.ihm;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Save {

	public static void saveData(String contenu, File fichier){
		try {
			BufferedWriter buffer = new BufferedWriter(new FileWriter(fichier));
			buffer.write(contenu);
			buffer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
