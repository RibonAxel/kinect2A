//created by BB on 26/05/11

package record.ihm;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;

import pi.endpoint.DoubleValue;
import pi.executive.ContinuousAgent;
import record.Player;
import record.Recorder;

public class IHMPlayer extends JFrame implements ContinuousAgent{

	
	private static final int       WIDTH   = 530;
    private static final int       HEIGHT  = 270;
    private static final double FRAME_TIME = 0.050;
   
    private double  time    = 0;
    private boolean refresh = true;
    
	private  JLabel label;
	private Controller controller; 
	private Player player = new Player();
	
	private DoubleValue S;
    
	
	public IHMPlayer(DoubleValue s1, String name) {
	
		this.S=s1;
	   	this.setTitle(name);
	   	this.getContentPane().setLayout(null);
	   	this.setSize(WIDTH, HEIGHT);
	    controller = new Controller();
	    
	    this.show();
	}

	public void control () { 
		this.player.control();
    }
	
	public void delta(double dt) {
      this.player.delta(dt);
    }


   private class Controller implements ItemListener {
	    private CheckboxGroup buttons = new CheckboxGroup();
	    private Checkbox start, stop, load;
		     
		public Controller() {
			this.add_start_Checkbox();
		    this.add_stop_Checkbox();  
		    this.add_save_Checkbox();  
		}

		//geometric BOX		
	    private void add_start_Checkbox () {
	        start = new java.awt.Checkbox("start", buttons, false);
	        start.setBounds(10,22,70,23);
	        start.addItemListener(this);
	        getContentPane().add(start); 
	    }	     
		     
	    private void add_stop_Checkbox () {
	    	stop = new java.awt.Checkbox("stop", buttons, true);
	    	stop.setBounds(80,22,70,23);
	    	stop.addItemListener(this);
	        getContentPane().add(stop); 
	    }	     
	 
	    private void add_save_Checkbox () {
	    	load = new java.awt.Checkbox("load", buttons, true);
	    	load.setBounds(150,22,70,23);
	    	load.addItemListener(this);
	        getContentPane().add(load); 
	    }	   
		
	    public void itemStateChanged (ItemEvent e) { 
	        if (e.getSource() == start) { player.start(); }
	        if (e.getSource() == stop) { player.stop(); }
	        if (e.getSource() == load) { this.load(); }
	    }
	    
	    private void load() {
	    	JFrame frame = null;
	    	
	    	JFileChooser fin = new JFileChooser();
			fin.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			fin.showOpenDialog(frame);
			File filein = fin.getSelectedFile();
			
			if (filein != null) {
				player.setOutput(S, Load.loadData(new File(filein.toString())) );
			}
		}


   
   }
   
}