package record.ihm;

import generators.signal.Constant;
import generators.signal.startStop.StartStopController;
import generators.signal.startStop.StartStopGenerator;
import generators.signal.startStop.StartStopValue;
import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import universe.DMXUniverse;
import universe.Patch;

public class TestPlayer  {

	public static void test() {
		try 
		 {
			 
		
			 DoubleValue      S1 = new DoubleValue();           
		     IHMPlayer ip = new IHMPlayer(S1, "player");
		     	         
		     DMXUniverse universe = new DMXUniverse();
		     Patch p1 = new Patch(S1);  p1.add(255);
		
		
		     universe.add(p1);   
		    
		     DMXLevel 		L1 = new DMXLevel(universe , "level");
		     
		     SimpleContainer instrument  = new SimpleContainer(new Agent[] {ip, L1});
		     Application     application = new Application(instrument, 0.025, 0.005);
		  
		   
		   
		     application.start();      
		 }
		 catch (Exception e) { e.printStackTrace();	}	 
	}
	
}
	
	
