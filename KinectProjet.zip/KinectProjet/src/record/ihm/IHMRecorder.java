//  GUI.java
//  Created by Bernard Thirion on 20/03/07.

package record.ihm;

import java.awt.Frame;
import java.awt.Button;
import java.awt.event.*;
import java.awt.CheckboxGroup;
import java.awt.Checkbox;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.filechooser.FileFilter;

import pi.endpoint.DoubleValue;
import pi.executive.ContinuousAgent;
import pi.executive.Executive;
import pi.io.IOEvent;
import record.Recorder;

public class IHMRecorder extends JFrame implements ContinuousAgent{

   public IOEvent on         = new IOEvent();
   public IOEvent off        = new IOEvent();
   public IOEvent resume     = new IOEvent();
   public IOEvent accelerate = new IOEvent();
   public IOEvent brake      = new IOEvent();
   public IOEvent engineOn   = new IOEvent();
   public IOEvent engineOff  = new IOEvent();

   private static final int width  = 500;
   private static final int height = 150;

   private boolean engineIsOn = false;

   private Button startrecordButton, stoprecordButton, saveButton, accelerateButton, brakeButton;
   private Checkbox engineOnBox, engineOffBox;
   private ButtonListener buttonListener = new ButtonListener();
	private  JLabel label;
	private Recorder recorder = new Recorder();
	private DoubleValue S;
 
   public IHMRecorder(DoubleValue s1, String name) {
		this.S=s1;
	   	this.setTitle(name);
	   //	this.getContentPane().setLayout(null);
	   	this.setSize(WIDTH, HEIGHT);
	    
	    this.show();
      setTitle ("Recorder");
      setLayout(null);
      setSize  (width, height);
      addControllerButtons();
      this.setVisible(true);
   }

   private class Quit implements ActionListener {
      public void actionPerformed (ActionEvent e) {
         System.exit(0);
      }          
   }
   
   private void addControllerButtons () {
      startrecordButton = new Button ();
      startrecordButton.setLabel("start-record");
      startrecordButton.setBounds(20,100,40,23);
      startrecordButton.addMouseListener(buttonListener);
      add(startrecordButton); 	
      stoprecordButton = new Button ();
      stoprecordButton.setLabel("stop-record");
      stoprecordButton.setBounds(70,100,40,23);
      stoprecordButton.addMouseListener(buttonListener);
      add(stoprecordButton); 	
      saveButton = new Button ();
      saveButton.setLabel("save");
      saveButton.setBounds(120,100,60,23);
      saveButton.addMouseListener(buttonListener);
      add(saveButton); 	
   }
  
   
   private class ButtonListener extends MouseAdapter  {
      public void mousePressed (MouseEvent e) {
         if (e.getSource() == startrecordButton        ){ recorder.start(IHMRecorder.this.S); }
	   	 if (e.getSource() == stoprecordButton       ){ recorder.stop(); }
	   	 if (e.getSource() == saveButton    ){ this.save(); }
      }    
            
     
      
      private void save() {
			JFrame frame = null;

	    	JFileChooser fout = new JFileChooser();
	    	FileFilter filter1 = new ExtensionFileFilter("eclat or ECLAT", new String[] { "eclat", "ECLAT" });
	        fout.setFileFilter(filter1);
			fout.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			fout.showSaveDialog(frame);
			File fileout = fout.getSelectedFile();
			
			if (fileout != null) {
				System.out.println("nyaaa" +recorder.save());
					Save.saveData(recorder.save(),new File(fileout.toString() ));
			}

			
		}
   }
   
@Override
public void control() {
	// TODO Auto-generated method stub
	
}

@Override
public void delta(double dt) {
	  this.recorder.delta(dt);	
}
           
}

