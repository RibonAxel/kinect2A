package record.ihm;




//Created by BB on 26 05 11.




import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.filechooser.FileFilter;

import pi.endpoint.DoubleValue;
import pi.executive.ContinuousAgent;
import record.Recorder;


public class IHMRecorderBETA extends JFrame implements ContinuousAgent{

	
	private static final int       WIDTH   = 530;
    private static final int       HEIGHT  = 270;
    private static final double FRAME_TIME = 0.050;
   
    private double  time    = 0;
    private boolean refresh = true;
    
	private  JLabel label;
	private Controller controller; 
	private Recorder recorder = new Recorder();
	
	private DoubleValue S;
    
	
	public IHMRecorderBETA(DoubleValue s1, String name) {
	
		this.S=s1;
	   	this.setTitle(name);
	   	this.getContentPane().setLayout(null);
	   	this.setSize(WIDTH, HEIGHT);
	    controller = new Controller();
	    
	    this.show();
	}

	public void control () { 
		
    }
	
	public void delta(double dt) {
      this.recorder.delta(dt);
    }


   private class Controller implements ItemListener {
	    private CheckboxGroup buttons = new CheckboxGroup();
	    private Checkbox start, stop, save;
		     
		public Controller() {
			this.add_start_Checkbox();
		    this.add_stop_Checkbox();  
		    this.add_save_Checkbox();  
		}

		//geometric BOX		
	    private void add_start_Checkbox () {
	        start = new java.awt.Checkbox("start", buttons, false);
	        start.setBounds(10,22,70,23);
	        start.addItemListener(this);
	        getContentPane().add(start); 
	    }	     
		     
	    private void add_stop_Checkbox () {
	    	stop = new java.awt.Checkbox("stop", buttons, true);
	    	stop.setBounds(80,22,70,23);
	    	stop.addItemListener(this);
	        getContentPane().add(stop); 
	    }	     
	 
	    private void add_save_Checkbox () {
	    	save = new java.awt.Checkbox("save", buttons, true);
	    	save.setBounds(120,22,70,23);
	    	save.addItemListener(this);
	        getContentPane().add(save); 
	    }	   
		
	    public void itemStateChanged (ItemEvent e) { 
	        if (e.getSource() == start) { recorder.start(IHMRecorderBETA.this.S); }
	        if (e.getSource() == stop) { recorder.stop(); }
	        if (e.getSource() == save) { this.save(); }
	    }
	    
	    private void save() {
			JFrame frame = null;

	    	JFileChooser fout = new JFileChooser();
	    	FileFilter filter1 = new ExtensionFileFilter("eclat or ECLAT", new String[] { "eclat", "ECLAT" });
	        fout.setFileFilter(filter1);
			fout.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			fout.showSaveDialog(frame);
			File fileout = fout.getSelectedFile();
			
			if (fileout != null) {
					Save.saveData(recorder.save(),new File(fileout.toString() ));
			}

			
		}


   
   }
   
}