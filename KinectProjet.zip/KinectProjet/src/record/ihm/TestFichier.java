package record.ihm;
//Created by BB on 26 05 11.
import generators.signal.Constant;
import generators.signal.Sinewave;
import generators.signal.startStop.StartStopController;
import generators.signal.startStop.StartStopGenerator;
import generators.signal.startStop.StartStopValue;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;

import record.Recorder;
import universe.DMXUniverse;
import universe.Patch;

public class TestFichier {

	public static void test() {

		
		try 
		 {
			 

	    	 DoubleValue      S1 = new DoubleValue();     
	         StartStopValue		  TValue1 = new StartStopValue();
	 		 Constant c1 = new Constant(0.5);
			 StartStopController T1 = new StartStopController(TValue1, "Const");
	         StartStopGenerator  G1 = new StartStopGenerator(c1, TValue1, S1); 
	         
	         IHMRecorder irb = new IHMRecorder(S1,"vjhvh");
	         	         
	         DMXUniverse universe = new DMXUniverse();
	         Patch p1 = new Patch(S1);  p1.add(255);


	         universe.add(p1);   
	        
	         DMXLevel 		L1 = new DMXLevel(universe , "level");
	         
	         SimpleContainer instrument  = new SimpleContainer(new Agent[] {irb,G1, T1, L1});
	         Application     application = new Application(instrument, 0.025, 0.005);
	      
		   
		   
	         application.start();      
		 }
		 catch (Exception e) { e.printStackTrace();	}	 
	}
		
		
}
	



