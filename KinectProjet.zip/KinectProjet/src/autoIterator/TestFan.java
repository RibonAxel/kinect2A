package autoIterator;

import java.net.InetAddress;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.AdaptaterInverserDoubleValue;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.command.Chaser;
import autoIterator.command.Fan;
import autoIterator.command.LightOnGroups;
import autoIterator.command.Sequence;

public class TestFan {
	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREGREEN = {FIXTUREGREEN, FIXTUREGREEN+11, FIXTUREGREEN+22, FIXTUREGREEN+33};
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS);
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
			DmxPacket packet = new DmxPacket();
			
			DoubleValue	sPan = new DoubleValue();  DoubleValue	sPan2 = new DoubleValue(); DoubleValue	sPan3 = new DoubleValue(); 
			DoubleValue	sTilt = new DoubleValue(); DoubleValue	sTilt2 = new DoubleValue(); DoubleValue	sTilt3 = new DoubleValue(); 
			DoubleValue	sRed = new DoubleValue(); DoubleValue	sRed2 = new DoubleValue(); DoubleValue	sRed3 = new DoubleValue(); 
			DoubleValue	sBlue = new DoubleValue(); DoubleValue	sBlue2 = new DoubleValue(); DoubleValue	sBlue3 = new DoubleValue();
			DoubleValue	sGreen = new DoubleValue(); DoubleValue	sGreen2 = new DoubleValue(); DoubleValue	sGreen3 = new DoubleValue(); 
			DoubleValue sDimmer = new DoubleValue(); DoubleValue sDimmer2 = new DoubleValue(); DoubleValue sDimmer3 = new DoubleValue(); 
			
			FixturesGroup group = new FixturesGroup();
			group.addFixture(sPan, sTilt, sRed, sBlue, sGreen, new AdaptaterInverserDoubleValue(sDimmer));
			group.addFixture(sPan2, sTilt2, sRed2, sBlue2, sGreen2, sDimmer2);
			group.addFixture(sPan3, sTilt3, sRed3, sBlue3, sGreen3, sDimmer3);

			Sequence seq = new Sequence();
			seq.addCommand(new LightOnGroups(group));
			seq.addCommand(new Fan(new CommandTime(3, TimeScaleEnum.SEC), group));
			
			Sequenceur sequenceur = new Sequenceur();
		//	sequenceur.setCommand(new Chaser(new CommandTime(40, TimeScaleEnum.ECLAT), group));
			sequenceur.setCommand(seq);
			/*CommandBox commandBox = new CommandBox();
			
			AutoSequencerController seqController = new AutoSequencerController(sBlue, sRed, sGreen, sPan, sTilt, commandBox);
			
			SequencerParam sequencer = new SequencerParam(commandBox);			
			*/
			
			DMXUniverse universe = new DMXUniverse();
			Patch pTilt = new Patch(sTilt); pTilt.add(FIXTURETILT); Patch pTilt2 = new Patch(sTilt2); pTilt2.add(2+11); Patch pTilt3 = new Patch(sTilt3); pTilt3.add(FIXTURETILT +40);
			Patch pPan = new Patch(sPan); pPan.add(FIXTURETILT); Patch pPan2 = new Patch(sPan2); pPan2.add(1+11); Patch pPan3  = new Patch(sPan3); pPan3.add(FIXTUREPAN+40);
			Patch pRed  = new Patch(sRed); pRed.add(FIXTURERED); Patch pRed2  = new Patch(sRed2); pRed2.add(5+11); Patch pRed3  = new Patch(sRed3); pRed3.add(FIXTURERED+40);
			Patch pGreen  = new Patch(sGreen); pGreen.add(FIXTUREGREEN); Patch pGreen2  = new Patch(sGreen2); pGreen2.add(6+11); Patch pGreen3  = new Patch(sGreen3); pGreen3.add(FIXTUREGREEN+40);
			Patch pBlue = new Patch(sBlue); pBlue.add(FIXTUREBLUE); Patch pBlue2 = new Patch(sBlue2); pBlue2.add(7+11); Patch pBlue3 = new Patch(sBlue3); pBlue3.add(FIXTUREBLUE+40);
			Patch pDimmer = new Patch(sDimmer); pDimmer.add(FIXTUREDIMMER); Patch pDimmer2 = new Patch(sDimmer2); pDimmer2.add(8+11); Patch pDimmer3 = new Patch(sDimmer3); pDimmer3.add(FIXTUREDIMMER+40);

			
			universe.add(pPan); universe.add(pTilt); universe.add(pBlue); universe.add(pRed); universe.add(pGreen); universe.add(pDimmer);
			universe.add(pPan2); universe.add(pTilt2); universe.add(pBlue2); universe.add(pRed2); universe.add(pGreen2); universe.add(pDimmer2);
			universe.add(pPan3); universe.add(pTilt3); universe.add(pBlue3); universe.add(pRed3); universe.add(pGreen3); universe.add(pDimmer3);
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {sequenceur, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
	
}
