package autoIterator;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.ShapeEnum;
import generators.signal.startStop.StartStopValue;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import autoIterator.command.Command;

import GUI.DoubleSliderPanel;
import Global.GlobalController;
import pi.executive.ContinuousAgent;
import record.ihm.IHMRecorder;

public class SequencerControllerV2 extends JFrame implements ContinuousAgent{

	
	private static final int       WIDTH   = 900;
    private static final int       HEIGHT  = 500;
    private static final double FRAME_TIME = 0.050;
   
    private double  time    = 0;
    private boolean refresh = true;
    

	private JPanel jPanelCommands1;
	private JPanel jPanelCommands2;
	private JPanel jPanelCommands3;
	private ButtonListener buttonListener = new ButtonListener();
	private Controller controller;


    private CommandBox box;	
    
    private Command[] commands1;
    private Command[] commands2;
    private Command[] commands3;


    private ArrayList<Button>  buttons1  = new ArrayList<Button>();
    private ArrayList<Button>  buttons2  = new ArrayList<Button>();
    private ArrayList<Button>  buttons3  = new ArrayList<Button>();


    private Button commandStopButton;

    public SequencerControllerV2(CommandBox box, String[] names1, Command[] commands1,String[] names2, Command[] commands2,String[] names3, Command[] commands3){
    	this(box, "SequencerController", names1, commands1, names2, commands2, names3, commands3);
    }
    
	public SequencerControllerV2(CommandBox box, String name, String[] names1, Command[] commands1,String[] names2, Command[] commands2,String[] names3, Command[] commands3) {
		try {
			if((names1.length != commands1.length)&&(names1.length != commands1.length))
				throw new Exception("number of names isn't the same as number of commands");

			this.commands1 = commands1;
			this.commands2 = commands2;
			this.commands3 = commands3;

			
			this.box = box;
		   	this.box.setModeNewCommand(ModeNewCommand.REPLACE);
		   	this.box.setModePlay(ModePlay.SIMPLE);
		   	
		   	this.setTitle(name);
		   	this.setBounds(400, 400, WIDTH, HEIGHT);
		   	this.setLayout(null);
		   	this.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		   	this.setSize(WIDTH, HEIGHT);
		   	
		   	controller = new Controller();
		   
		   	jPanelCommands1 = new JPanel();
		   	jPanelCommands1.setBounds(100, 0, 300, HEIGHT);
		   	jPanelCommands1.setLayout(new FlowLayout());
		   	this.add(jPanelCommands1);
		   	

		   	jPanelCommands2 = new JPanel();
		   	jPanelCommands2.setBounds(350, 0, 300, HEIGHT);
		   	jPanelCommands2.setLayout(new FlowLayout());
		   	this.add(jPanelCommands2);
		   	
		   	jPanelCommands3 = new JPanel();
		   	jPanelCommands3.setBounds(600, 0, 300, HEIGHT);
		   	jPanelCommands3.setLayout(new FlowLayout());
		   	this.add(jPanelCommands3);
		   	
		   	for(int i=0; i<names1.length; i++)
		   	{
		   		addControllerButton1(names1[i], commands1[i]);
		   	}
		   	for(int i=0; i<names2.length; i++)
		   	{
		   		addControllerButton2(names2[i], commands2[i]);
		   	}
		   	for(int i=0; i<names3.length; i++)
		   	{
		   		addControllerButton3(names3[i], commands3[i]);
		   	}
		    this.show();
		}
		catch (Exception e) {e.printStackTrace(); }
	    this.show();

	}

	
	
	

	private void addControllerButton1(String name1, Command command1) {
		Button b = new Button();
		b.setPreferredSize(new Dimension(100, 30));
		b.setLabel(name1);
		b.addMouseListener(buttonListener);
		jPanelCommands1.add(b);
		buttons1.add(b);
	}
	
	private void addControllerButton2(String name2, Command command2) {
		Button b = new Button();
		b.setPreferredSize(new Dimension(100, 30));
		b.setLabel(name2);
		b.addMouseListener(buttonListener);
		jPanelCommands2.add(b);
		buttons2.add(b);
	}
	
	private void addControllerButton3(String name3, Command command3) {
		Button b = new Button();
		b.setPreferredSize(new Dimension(100, 30));
		b.setLabel(name3);
		b.addMouseListener(buttonListener);
		jPanelCommands3.add(b);
		buttons3.add(b);
	}
	
	private class ButtonListener extends MouseAdapter  {
		public void mousePressed (MouseEvent e) {
			int i=0,j=0,k=0;
			for(Button button : buttons1)
			{
				if(e.getSource() == button)
				{ 
					this.adjustCommand1(commands1[i]); 
				}
				i++;
			}
			for(Button button : buttons2)
			{
				if(e.getSource() == button)
				{ 
					this.adjustCommand2(commands2[j]); 
				}
				j++;
			}
			for(Button button : buttons3)
			{
				if(e.getSource() == button)
				{ 
					this.adjustCommand3(commands3[k]); 
				}
				k++;
			}
		}    
		
		private void adjustCommand1(Command command1) {
			SequencerControllerV2.this.adjustCommand1(command1);
		}
		private void adjustCommand2(Command command2) {
			SequencerControllerV2.this.adjustCommand2(command2);
		}
		private void adjustCommand3(Command command3) {
			SequencerControllerV2.this.adjustCommand3(command3);
		}
	}
	private synchronized void adjustCommand1(Command command1) {
		 box.setCommand(command1);		
	}
	private synchronized void adjustCommand2(Command command2) {
		 box.setCommand(command2);		
	}
	private synchronized void adjustCommand3(Command command3) {
		 box.setCommand(command3);		
	}
	
	private synchronized void adjustRun(boolean run) {
		box.setRun(run);
	}	
	private synchronized void adjustModePlay(ModePlay mode) {
		box.setModePlay(mode);
	}
	private synchronized void adjustModeNewCommand(ModeNewCommand mode) {
		box.setModeNewCommand(mode);
	}
	
	
	@Override
	public void control() {		
	}
	
	public void delta(double dt) {
       time = time + dt;
       if (time >= FRAME_TIME) {
          refresh = true;
          while (time >= FRAME_TIME) time = time - FRAME_TIME;
       }
    }



	
	
	  
   private class Controller implements ItemListener {
	    private CheckboxGroup runButtons = new CheckboxGroup();
	    private CheckboxGroup modePlayButtons = new CheckboxGroup();
	    private CheckboxGroup modeNewCmdButtons = new CheckboxGroup();
	    private Checkbox start, stop, simple, loop, reverse, add, replace;
		     
		public Controller() {
		    this.add_start_Checkbox();
		    this.add_stop_Checkbox();

		    this.add_simple_Checkbox();
		    this.add_loop_Checkbox();
		    this.add_reverse_Checkbox();   
		    
			this.add_add_Checkbox();   
		    this.add_replace_Checkbox();
		}

		//run BOX		
	    private void add_start_Checkbox () {
	        start = new java.awt.Checkbox("resume", runButtons, true);
	        start.setBounds(10,10,70,23);
	        start.addItemListener(this);
	        SequencerControllerV2.this.add(start); 
	    }	     
		     
	    private void add_stop_Checkbox () {
	        stop = new java.awt.Checkbox("pause", runButtons, false);
	        stop.setBounds(10,30,70,23);
	        stop.addItemListener(this);
	        SequencerControllerV2.this.add(stop); 
	    }	     
	      	    
	    //modePlay BOX
	    private void add_simple_Checkbox() {
			simple = new java.awt.Checkbox("simple", modePlayButtons, true);
	        simple.setBounds(10,70,70,23);
	        simple.addItemListener(this);
	        SequencerControllerV2.this.add(simple); 
		}
	    
	    private void add_loop_Checkbox () {
	        loop = new java.awt.Checkbox("loop", modePlayButtons, false);
	        loop.setBounds(10,100,80,23);
	        loop.addItemListener(this);
	        SequencerControllerV2.this.add(loop); 
	    }	     
		    
	    private void add_reverse_Checkbox () {
	        reverse = new java.awt.Checkbox("reverse", modePlayButtons, false);
	        reverse.setBounds(10,130,70,23);
	        reverse.addItemListener(this);
	        SequencerControllerV2.this.add(reverse); 
	    }

	    
	    //ModeNewCmd BOX
		private void add_add_Checkbox() {
			add = new java.awt.Checkbox("add", modeNewCmdButtons, false);
	        add.setBounds(10,180,70,23);
	        add.addItemListener(this);
	        SequencerControllerV2.this.add(add); 
		}
		
		private void add_replace_Checkbox() {
			replace = new java.awt.Checkbox("replace", modeNewCmdButtons, true);
	        replace.setBounds(10,210,70,23);
	        replace.addItemListener(this);
	        SequencerControllerV2.this.add(replace); 
			
		}
		
		
	    public void itemStateChanged (ItemEvent e) { 
	        if (e.getSource() == start) 	{ this.adjustRun(true); }
	        if (e.getSource() == stop) 		{ this.adjustRun(false); }

	        if (e.getSource() == simple) 	{  this.adjustModePlay(ModePlay.SIMPLE); }
	        if (e.getSource() == loop) 		{ this.adjustModePlay(ModePlay.LOOP); }
	        if (e.getSource() == reverse) 	{ this.adjustModePlay(ModePlay.REVERSE); }
	        
	        if (e.getSource() == add)		{ this.adjustModeNewCommand(ModeNewCommand.ADD); }
	        if (e.getSource() == replace) 	{ this.adjustModeNewCommand(ModeNewCommand.REPLACE);  }
	    }
	    
	    
	    private void adjustRun(boolean run) {
	    	SequencerControllerV2.this.adjustRun(run);
	    }
	    private void adjustModePlay(ModePlay mode) {
	    	SequencerControllerV2.this.adjustModePlay(mode);
	    } 
	    private void adjustModeNewCommand(ModeNewCommand mode) {
	    	SequencerControllerV2.this.adjustModeNewCommand(mode);
	    } 

   
   }

   

   
}