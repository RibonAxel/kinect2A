package autoIterator;

import generators.signal.polymorph.ShapeEnum;

import java.util.ArrayList;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;

public class AdaptaterOneToSeveralBox extends DropBox{

	private ArrayList<DropBox> boxs;
	
	public AdaptaterOneToSeveralBox(){
		boxs = new ArrayList<DropBox>();
	}
	
	
	public void addDropBox(DropBox box){
		this.boxs.add(box);
	}
	
	public void addDropBox(DoubleValue box){
		this.boxs.add(new AdaptaterDoubleValueToDropBox(box));
	}
	
	public void setAmplitude(double amplitude) {
		for(DropBox box : boxs){
			box.setAmplitude(amplitude);
		}
	}
	public void setFrequency(double frequency) {
		for(DropBox box : boxs){
			box.setFrequency(frequency);
		}
	}
	public void setDephas(double dephas   ) { 
		for(DropBox box : boxs){
			box.setDephas(dephas);
		}
	}
	public void setShape(ShapeEnum shape ) {
		for(DropBox box : boxs){
			box.setShape(shape);
		}
	}
	public void setRun(boolean run)	   {
		for(DropBox box : boxs){
			box.setRun(run);
		}
	}
}
