package autoIterator.command;

import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.FixturesGroup;

public class Fan extends GroupsCommand {
	
	private Parallele fanCommands = new Parallele();
	
	
	public Fan(CommandTime oneFixtureMoveTime, FixturesGroup group) {
		super(group);
		this.executionTime = oneFixtureMoveTime.getTimeValue();
	}
	
	private void createChaserCommand(){
		long oneMoveTime = this.executionTime;
		
		for(int i = 0; i < this.group.getNbrFixture(); i ++)
		{
			Sequence seq = new Sequence();
			seq.addCommand(new SetValue(0, group.getTilt().get(i)));
			seq.addCommand(new Wait(new CommandTime((oneMoveTime/4)*i, TimeScaleEnum.ECLAT)));
			seq.addCommand(new Interpolation(0, 1, new CommandTime(oneMoveTime/2, TimeScaleEnum.ECLAT), group.getTilt().get(i)));			
			seq.addCommand(new Wait(new CommandTime(10, TimeScaleEnum.ECLAT)));
			seq.addCommand(new Interpolation(1, 0, new CommandTime(oneMoveTime/2, TimeScaleEnum.ECLAT), group.getTilt().get(i)));

			fanCommands.addCommand(seq);
		
		}
		
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
		this.elapsedTime = 0;
		
		this.createChaserCommand();
		fanCommands.begin();
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
		this.elapsedTime = 0;
		
		this.createChaserCommand();
		fanCommands.reverseBegin();
	}

	@Override
	public void control() {
		if(!this.isExhausted)
			fanCommands.control();
	}

	@Override
	public void execute(double dt) {
		if(!this.isExhausted){
			fanCommands.execute(dt);
			if(this.fanCommands.isExhausted())
				this.isExhausted = true;
		}
	}

}
