package autoIterator.command;

import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.FixturesGroup;

public class Chaser extends GroupsCommand {

	private Parallele chaserCommands = new Parallele();
	
	public Chaser(CommandTime commandTime, FixturesGroup group) {
		super(group);
		this.executionTime = commandTime.getTimeValue();
	}

	private void createChaserCommand(){
		long flashTime = this.executionTime / (group.getNbrFixture()+1);
		chaserCommands.addCommand(new Interpolation(0, 1, new CommandTime(flashTime, TimeScaleEnum.ECLAT), group.getDimmer().get(0)));

		for(int i = 1; i < this.group.getNbrFixture(); i ++)
		{
			Sequence seqdown = new Sequence();
			seqdown.addCommand(new Wait(new CommandTime(flashTime*i, TimeScaleEnum.ECLAT)));
			seqdown.addCommand(new Interpolation(1, 0, new CommandTime(flashTime*2, TimeScaleEnum.ECLAT), group.getDimmer().get(i-1)));
			
			Sequence sequp = new Sequence();
			sequp.addCommand(new Wait(new CommandTime(flashTime*i, TimeScaleEnum.ECLAT)));
			sequp.addCommand(new Interpolation(0, 1, new CommandTime(flashTime, TimeScaleEnum.ECLAT), group.getDimmer().get(i)));
			
			chaserCommands.addCommand(sequp);
			chaserCommands.addCommand(seqdown);
		
		}
		Sequence seq = new Sequence();
		seq.addCommand(new Wait(new CommandTime(flashTime*this.group.getNbrFixture(), TimeScaleEnum.ECLAT)));
		seq.addCommand(new Interpolation(1, 0, new CommandTime(flashTime, TimeScaleEnum.ECLAT), group.getDimmer().get(group.getNbrFixture()-1)));
		
		chaserCommands.addCommand(seq);
		
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
		this.elapsedTime = 0;
		
		this.createChaserCommand();
		chaserCommands.begin();
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
		this.elapsedTime = 0;
		
		this.createChaserCommand();
		chaserCommands.reverseBegin();
	}

	@Override
	public void control() {
		if(!this.isExhausted)
			chaserCommands.control();

	}

	@Override
	public void execute(double dt) {
		if(!this.isExhausted){
			chaserCommands.execute(dt);
			if(this.chaserCommands.isExhausted())
				this.isExhausted = true;
		}
	}
}
