package autoIterator.command;

public class Parallele extends CommandCollection {

	public Parallele(){
		
	}
	
	
	@Override
	public void begin() {
		isExhausted = false;
		for (Command command : commands){
			command.begin();
		}
	}

	@Override
	public void reverseBegin() {
		isExhausted = false;
		for( Command command : commands){
			command.reverseBegin();
		}
	}

	@Override
	public void control() {
		for(Command command : commands)
			command.control();
	}

	@Override
	public void execute(double dt) {
		boolean isEnded = true;
		for(Command command : commands)
		{
			if(!command.isExhausted())
				isEnded = false;
			command.execute(dt);
		}
		isExhausted = isEnded;
	}

}
