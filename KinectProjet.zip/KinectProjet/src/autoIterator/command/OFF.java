package autoIterator.command;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;
import autoIterator.DropBox;

public class OFF extends InstantCommand {

	private static final int ZERO = 0;
	private DropBox output;
	
	public OFF(DropBox output){
		this.output = output;
	}
	public OFF(DoubleValue axisBox){
		this(new AdaptaterDoubleValueToDropBox(axisBox));
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
	}

	@Override
	public void control() {
		this.isExhausted = true;
		this.output.setAmplitude(ZERO);
	}

	@Override
	public void execute(double dt) {}

}
