package autoIterator.command;

import autoIterator.DropBox;
import autoIterator.FixturesGroup;

public class LightOnGroups extends GroupsCommand {

	public LightOnGroups(FixturesGroup group) {
		super(group);
	}

	@Override
	public void begin() {
		this.isExhausted = false;
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
	}

	@Override
	public void control() {
		for(DropBox box: this.group.getDimmer())
			box.setAmplitude(0);
		for(DropBox box: this.group.getRed())
			box.setAmplitude(1);
		for(DropBox box: this.group.getBlue())
			box.setAmplitude(1);
		for(DropBox box: this.group.getGreen())
			box.setAmplitude(1);
		
		this.isExhausted = true;
	}

	@Override
	public void execute(double dt) {}

}
