package autoIterator.command;

import java.util.Iterator;

import autoIterator.command.Command;

public class Sequence extends CommandCollection {

	private Iterator<Command> itCommands;
	private Command currentCommand = null;
	private boolean reverted = false;
	
	public Sequence(){
	}
	
	@Override
	public void begin() {
		isExhausted = false;
		for (Command command : commands){
			command.begin();
		}
		itCommands = commands.iterator();
		if(itCommands.hasNext())
			this.currentCommand = itCommands.next();
	}

	@Override
	public void reverseBegin() {
		isExhausted = false;
		for (Command command : commands){
			command.reverseBegin();
		}
		itCommands = commands.descendingIterator();
		if(itCommands.hasNext())
			this.currentCommand = itCommands.next();
	}

	@Override
	public void control() {
		if(currentCommand != null)
			currentCommand.control();
		
	}

	@Override
	public void execute(double dt) {
		this.currentCommand.execute(dt);
		if(itCommands.hasNext()){
			if(this.currentCommand.isExhausted)
			{
				this.currentCommand = itCommands.next();
			}
		}
		else if(this.currentCommand.isExhausted)
		{
			this.isExhausted = true;
		}
		
	}

}
