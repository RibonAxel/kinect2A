package autoIterator.command;

import java.util.LinkedList;

public abstract class CommandCollection extends Command {

	protected LinkedList<Command> commands = new LinkedList<Command>();
	
	public void addCommand(Command command)
	{
		this.commands.add(command);
	}	
	
	public void removeCommand(Command command)
	{
		this.commands.remove(command);
	}
	
}
