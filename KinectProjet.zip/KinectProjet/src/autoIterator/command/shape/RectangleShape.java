package autoIterator.command.shape;

import javax.crypto.spec.OAEPParameterSpec;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.DropBox;
import autoIterator.command.Interpolation;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;

public class RectangleShape extends Shape {

	private double width, height;

	private DropBox tiltBox, panBox;
	
	public RectangleShape(double width, double height, CommandTime commandTime, DropBox tiltBox, DropBox panBox){
		super(commandTime);
		this.executionTime -= 40; //(the command will wait 4times 10 dt)
		this.width = width;
		this.height = height;
		
		this.tiltBox = tiltBox;
		this.panBox = panBox;
		
		
	}
		
	public RectangleShape(double width, double height, CommandTime commandTime, DoubleValue tiltBox, DoubleValue panBox){
		this(width, height, commandTime, new AdaptaterDoubleValueToDropBox(tiltBox), new AdaptaterDoubleValueToDropBox(panBox));
	}
	
	private void createShape() {
		double startPan = 0;
		double startTilt = 0;

		this.shape = new Sequence();
		//init pos
		this.shape.addCommand(new SetValue(startPan, panBox));
		this.shape.addCommand(new SetValue(startTilt, tiltBox));
		this.shape.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.SEC)));
		//rectangle
		this.shape.addCommand(new Interpolation(startPan, startPan+width, new CommandTime(this.executionTime/4, TimeScaleEnum.ECLAT), panBox));
		this.shape.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.SEC)));
		this.shape.addCommand(new Interpolation(startTilt, startTilt+height, new CommandTime(this.executionTime/4, TimeScaleEnum.ECLAT), tiltBox));
		this.shape.addCommand(new Wait(new CommandTime(1, TimeScaleEnum.SEC)));
		this.shape.addCommand(new Interpolation(startPan+width, startPan, new CommandTime(this.executionTime/4, TimeScaleEnum.ECLAT), panBox));
		this.shape.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.SEC)));
		this.shape.addCommand(new Interpolation(startTilt+height, startTilt, new CommandTime(this.executionTime/4, TimeScaleEnum.ECLAT), tiltBox));
		this.shape.addCommand(new Wait(new CommandTime(1, TimeScaleEnum.SEC)));
		
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
		this.createShape();
		this.shape.begin();
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
		this.createShape();
		this.shape.reverseBegin();
	}
	
	@Override
	public void control() {
		if(!this.shape.isExhausted())
			this.shape.control();
		
	}

	@Override
	public void execute(double dt) {
		if(!this.shape.isExhausted()){
			this.shape.execute(dt);
		}
		else{
			this.isExhausted = true;
		}
	}
}