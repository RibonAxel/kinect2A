package autoIterator.command.shape;

import auto.command.CommandTime;
import autoIterator.command.Sequence;
import autoIterator.command.TimedCommand;

public abstract class Shape extends TimedCommand {

	protected Sequence shape = new Sequence();
	
	public Shape(CommandTime commandTime) {
		super(commandTime);
		// TODO Auto-generated constructor stub
	}

}
