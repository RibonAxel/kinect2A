package autoIterator.command.shape;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.DropBox;
import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;

public class RandomShape extends Shape {

	private int nbrOfMove;

	private DropBox tiltBox, panBox;
	
	public RandomShape(int nbrOfMove, DropBox tiltBox, DropBox panBox){
		super(new CommandTime(0, TimeScaleEnum.ECLAT));
		this.nbrOfMove = nbrOfMove;
		
		this.tiltBox = tiltBox;
		this.panBox = panBox;
	}
		
	public RandomShape(int nbrOfMove, DoubleValue tiltBox, DoubleValue panBox){
		this(nbrOfMove, new AdaptaterDoubleValueToDropBox(tiltBox), new AdaptaterDoubleValueToDropBox(panBox));
	}
	
	private void createShape() {
		double startPan = 0;
		double startTilt = 0;

		this.shape = new Sequence();
		
		for(int i=0; i<nbrOfMove; i++)
		{
			Parallele p = new Parallele();
			p.addCommand(new SetValue(Math.random(), tiltBox));
			p.addCommand(new SetValue(Math.random(), panBox));
			
			this.shape.addCommand(p);
			this.shape.addCommand(new Wait(new CommandTime(1, TimeScaleEnum.SEC)));
			
		}
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
		this.createShape();
		this.shape.begin();
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
		this.createShape();
		this.shape.reverseBegin();
	}
	
	@Override
	public void control() {
		if(!this.shape.isExhausted())
			this.shape.control();
		
	}

	@Override
	public void execute(double dt) {
		if(!this.shape.isExhausted()){
			this.shape.execute(dt);
		}
		else{
			this.isExhausted = true;
		}
	}
}