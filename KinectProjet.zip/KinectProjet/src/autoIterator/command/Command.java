package autoIterator.command;

public abstract class Command {

	protected boolean isExhausted = true;
	protected long executionTime;
	protected long elapsedTime;
	public static Command STOP = null;
	
	public abstract void begin();
	public abstract void reverseBegin();

	
	public abstract void control();
	public  boolean isExhausted() { return this.isExhausted; }
	
	
	public abstract void execute(double dt);
}
