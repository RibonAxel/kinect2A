package autoIterator.command;

import auto.command.CommandTime;

public abstract class TimedCommand extends Command {

	public TimedCommand(CommandTime commandTime){
		this.executionTime = commandTime.getTimeValue();
		this.elapsedTime = 0;
	}

	
}
