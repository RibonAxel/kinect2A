package autoIterator.command;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;
import auto.command.CommandTime;
import autoIterator.DropBox;

public class Interpolation extends TimedCommand {

	private double target;
	private double increment;
	private double value;
	private double startValue;
	private DropBox box;
	
	public Interpolation(double startValue, double target, CommandTime commandTime, DropBox Box){
		super(commandTime);
		this.target = target;

		this.value = startValue;
		this.startValue = startValue;
		this.majIncrement();
		
		this.box = Box;
	}
	public Interpolation(double startValue, double target, CommandTime commandTime, DoubleValue box){
		this(startValue, target, commandTime, new AdaptaterDoubleValueToDropBox(box));
	}

	private void majIncrement(){
		this.increment=((this.target-this.startValue)/this.executionTime);
	}
	private void reverseMajIncrement(){
		this.increment=((this.startValue-this.target)/this.executionTime);
	}
	private void incValues() {
		this.value += this.increment;
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
		this.elapsedTime = 0;
		this.value = this.startValue;
		this.majIncrement();
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
		this.elapsedTime = 0;
		this.value = this.target;
		this.reverseMajIncrement();
	}

	@Override
	public void control() {
			this.box.setAmplitude(this.value);
	}

	@Override
	public void execute(double dt) {
		elapsedTime++;
		if(elapsedTime > executionTime)
			isExhausted = true;
		if(!this.isExhausted)
		{
			this.incValues();
		}
		else
		{
			this.value = this.target;
		}
	}

}
