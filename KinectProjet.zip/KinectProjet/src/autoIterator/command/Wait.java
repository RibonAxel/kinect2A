package autoIterator.command;

import auto.command.CommandTime;

public class Wait extends TimedCommand {

	public Wait(CommandTime commandTime) {
		super(commandTime);
	}

	@Override
	public void begin() {
		this.elapsedTime = 0;
		this.isExhausted = false;
	}
	@Override
	public void reverseBegin() {
		this.elapsedTime = 0;
	}
	
	public void execute(double dt){
		if(!this.isExhausted)
		{
			elapsedTime++;
			if(elapsedTime >= executionTime)
				isExhausted = true;
		}
	}

	@Override
	public void control() { }
	
	
}
