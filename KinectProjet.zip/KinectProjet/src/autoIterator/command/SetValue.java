package autoIterator.command;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;
import autoIterator.DropBox;

public class SetValue extends InstantCommand {

	private double target;
	private DropBox box;
	
	public SetValue(double target, DropBox axisBox){
		this.box = axisBox;
		if(0 <= target && target <= 1)
			this.target = target;
		else{
			try {
				throw new Exception("target is a value between 0 and 1");
			} catch (Exception e) {e.printStackTrace();}
		}
	}
	public SetValue(double target, DoubleValue axisBox){
		this(target, new AdaptaterDoubleValueToDropBox(axisBox));
	}
	
	
	
	@Override
	public void begin() {
		this.isExhausted = false;
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
	}

	@Override
	public void control() {
		this.isExhausted = true;
		this.box.setAmplitude(target);
	}
	
	@Override
	public void execute(double dt) {}


}
