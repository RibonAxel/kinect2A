package autoIterator.command;

import autoIterator.FixturesGroup;

public abstract class GroupsCommand extends Command {

	protected FixturesGroup group;
	
	public GroupsCommand(FixturesGroup group){
		this.group = group;
	}
	
}
