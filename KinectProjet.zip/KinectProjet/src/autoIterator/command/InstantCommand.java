package autoIterator.command;

public abstract class InstantCommand extends Command {

	



}
