package autoIterator;

import generators.GlobalSequenceGenerator;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;

import java.net.InetAddress;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;

public class TestIteratorSequenceParallele {
	
	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS);
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
			DmxPacket packet = new DmxPacket();
			
			DropBox panValue = new DropBox();
			DropBox blueValue  = new DropBox();
			DropBox redValue  = new DropBox();
			
			SetValue panMoove = new SetValue(0.5, panValue);
			SetValue redMoove = new SetValue(0.5, redValue);
			Interpolation interBleu = new Interpolation(0, 1, new CommandTime(10, TimeScaleEnum.SEC), blueValue);
			Interpolation interpolation = new Interpolation(0, 1, new CommandTime(5, TimeScaleEnum.SEC), panValue);
			Interpolation interpolation2 = new Interpolation(0.5, 0, new CommandTime(20, TimeScaleEnum.ECLAT), panValue);
			Wait wait2s = new Wait(new CommandTime(2, TimeScaleEnum.SEC));
			Wait wait10Techno = new Wait(new CommandTime(10, TimeScaleEnum.TECHNO));
			Wait wait1s = new Wait(new CommandTime(1, TimeScaleEnum.SEC));

			Sequence sequence = new Sequence();
			sequence.addCommand(interpolation);
			sequence.addCommand(wait2s);
			sequence.addCommand(interpolation2);
			sequence.addCommand(wait10Techno);
			
			Parallele parallele = new Parallele();
			parallele.addCommand(redMoove);
			parallele.addCommand(panMoove);
			parallele.addCommand(interBleu);
			
			Sequence sequenceIn = new Sequence();
			sequenceIn.addCommand(parallele);
			sequenceIn.addCommand(wait1s);
			
			sequence.addCommand(sequenceIn);
			
			Sequenceur sequenceur = new Sequenceur();			
			sequenceur.setCommand(sequence);
			
			
			DoubleValue      sPan = new DoubleValue(); 
			PolymorphWave pwPan = new PolymorphWave(ShapeEnum.CONST);
			DoubleValue      sRed = new DoubleValue(); 
			PolymorphWave pwRed = new PolymorphWave(ShapeEnum.CONST);
			DoubleValue sBlue = new DoubleValue();
			PolymorphWave pwBlue = new PolymorphWave(ShapeEnum.CONST);

			GlobalSequenceGenerator  gPan = new GlobalSequenceGenerator(pwPan, panValue, panValue.getStartStopValue(), sPan); 
			GlobalSequenceGenerator  gBlue = new GlobalSequenceGenerator(pwBlue, blueValue, blueValue.getStartStopValue(), sBlue); 
			GlobalSequenceGenerator  gRed = new GlobalSequenceGenerator(pwRed, redValue, redValue.getStartStopValue(), sRed); 

			
			DMXUniverse universe = new DMXUniverse();
			Patch pRed  = new Patch(sRed); pRed.add(MULTFIXTURERED);
			Patch pPan  = new Patch(sPan); pPan.add(MULTFIXTUREPAN);
			Patch pBlue  = new Patch(sBlue); pBlue.add(MULTFIXTUREBLUE);
			
			universe.add(pPan); universe.add(pBlue); universe.add(pRed);
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {gPan, gBlue, gRed, sequenceur, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
	
}
