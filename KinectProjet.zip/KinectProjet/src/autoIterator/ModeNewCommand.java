package autoIterator;

public enum ModeNewCommand {
	REPLACE, ADD
}
