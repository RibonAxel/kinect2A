package autoIterator;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.ShapeEnum;
import generators.signal.startStop.StartStopValue;

public class DropBox {

	private double amplitude =0;
	private double frequency=0;
	private double dephas=0;
	private ShapeEnum shape = ShapeEnum.CONST;
	private boolean run = true;

	
	public DropBox() {};
	
	public double getAmplitude(){ return this.amplitude;}
	public double getFrequency(){ return this.frequency;}
	public double getDephas   (){ return this.dephas;}
	public ShapeEnum getShape (){ return this.shape;}
	public boolean run()        { return this.run;}
	
	public void setAmplitude(double amplitude) { this.amplitude = amplitude;}
	public void setFrequency(double frequency) { this.frequency = frequency;}
	public void setDephas   (double dephas   ) { this.dephas = dephas;}
	public void setShape    (ShapeEnum shape ) { this.shape  = shape; }
	public void setRun		(boolean run)	   {this.run = run;}
	
	public void copyVal(DropBox dropBox)
	{
		this.setAmplitude(dropBox.getAmplitude());
		this.setFrequency(dropBox.getFrequency());
		this.setDephas   (dropBox.getDephas()   );
		this.setShape    (dropBox.getShape());
		this.setRun		 (dropBox.run());
		
	}
	
	public PolymorphValue getPolymorphValue(){
		PolymorphValue PV = new PolymorphValue();
		PV.frequency(this.frequency);
		PV.amplitude(this.amplitude);
		PV.waveShape(this.shape);
		PV.dephas(this.dephas);
		return PV;
	}
	
	public StartStopValue getStartStopValue(){
		StartStopValue SSV = new StartStopValue();
		SSV.run(this.run);
		return SSV;	
	}
}