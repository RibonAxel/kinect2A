package autoIterator;

import java.util.ArrayList;

import pi.executive.ContinuousAgent;
import autoIterator.command.Command;

public class SequencerParametrable implements ContinuousAgent{

	private ArrayList<Command> currentCommands = new ArrayList<Command>();
	private Command currentCommand;
	private CommandBox commandBox;

	
	public SequencerParametrable(CommandBox commandBox){
		this.commandBox = commandBox;
		this.currentCommand = Command.STOP;
	}
	
	private void setCommand(Command command){
		this.resetCommands();
		this.currentCommands.add(command);
	}
	private void resetCommands(){
		this.currentCommands = new ArrayList<Command>();
	}
	
	private void addCommand(Command command){
		this.currentCommands.add(command);
	}
	
	@Override
	public void control() {
		if(this.commandBox.getRun()){
			for(Command command: currentCommands){
				if(!command.isExhausted() )
					command.control();
			}
		}
	}
	@Override
	public void delta(double dt) {
		if(this.currentCommand != this.commandBox.getCommand() )
		{
			this.currentCommand = this.commandBox.getCommand();
			switch (this.commandBox.getModeNewCommand()) {
			case REPLACE:
				this.setCommand(currentCommand);
				this.currentCommand.begin();
			break;
				
			case ADD:
				this.addCommand(currentCommand);
				this.currentCommand.begin();
			break;
				
			default:
				break;
			}
		}
				
		if(this.commandBox.getRun())
		{
			ArrayList<Command> toDeleteCommands = new ArrayList<Command>();
			for(Command command: currentCommands)
			{
				if(!command.isExhausted()){
					command.execute(dt);
				}
				else{
					switch (this.commandBox.getModePlay()) {
					case LOOP:
						command.begin();
					break;
					
					case REVERSE: 
						command.reverseBegin();
					break;
					
					case SIMPLE:
						toDeleteCommands.add(command);
					break;
						
					default:
						break;
					}	
				}
			}
			for(Command command: toDeleteCommands)
				this.currentCommands.remove(command);
			
		}
		
	}
}
