package autoIterator;

import pi.executive.ContinuousAgent;
import autoIterator.command.Command;

public class SequencerParam implements ContinuousAgent{

	private Command currentCommand = Command.STOP;
	private CommandBox commandBox;

	
	public SequencerParam(CommandBox commandBox){
		this.commandBox = commandBox;
	}
	
	private void setCommand(Command command){
		this.currentCommand = command;
	}
	
	private void addCommand(Command command){
		
	}
	
	@Override
	public void control() {
		if(this.currentCommand != Command.STOP && !this.currentCommand.isExhausted() )
			this.currentCommand.control();
	}
	@Override
	public void delta(double dt) {
		if(this.currentCommand != this.commandBox.getCommand() )
		{
			switch (this.commandBox.getModeNewCommand()) {
			case REPLACE:
				this.currentCommand = this.commandBox.getCommand();
				if(this.currentCommand != Command.STOP)
					this.currentCommand.begin();
			break;
				
			case ADD:
				//mode add non impl�ment� pour le moment
			break;
				
			default:
				break;
			}
		}
				
		if(this.currentCommand != Command.STOP)
		{
			if(!this.currentCommand.isExhausted()){
				if(this.commandBox.getRun())
				{
					this.currentCommand.execute(dt);
				}
			}
			else{
				switch (this.commandBox.getModePlay()) {
				case LOOP:
					this.currentCommand.begin();
				break;
				
				case REVERSE: 
					this.currentCommand.reverseBegin();
				break;
				
				case SIMPLE:
				break;
					
				default:
					break;
				}	
			}
		}
		
	}
}
