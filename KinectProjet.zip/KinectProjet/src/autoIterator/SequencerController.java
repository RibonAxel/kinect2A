package autoIterator;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.ShapeEnum;
import generators.signal.startStop.StartStopValue;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import autoIterator.command.Command;

import GUI.DoubleSliderPanel;
import Global.GlobalController;
import pi.executive.ContinuousAgent;
import record.ihm.IHMRecorder;

public class SequencerController extends JFrame implements ContinuousAgent{

	
	private static final int       WIDTH   = 400;
    private static final int       HEIGHT  = 300;
    private static final double FRAME_TIME = 0.050;
   
    private double  time    = 0;
    private boolean refresh = true;
    
	private JPanel jPanelCommands;
	private ButtonListener buttonListener = new ButtonListener();
	private Controller controller;


    private CommandBox box;	
    
    private Command[] commands;
    private ArrayList<Button>  buttons  = new ArrayList<Button>();
    private Button commandStopButton;

    public SequencerController(CommandBox box, String[] names, Command[] commands){
    	this(box, "SequencerController", names, commands);
    }
    
	public SequencerController(CommandBox box, String name, String[] names, Command[] commands) {
		try {
			if(names.length != commands.length)
				throw new Exception("number of names isn't the same as number of commands");

			this.commands = commands;
			
			this.box = box;
		   	this.box.setModeNewCommand(ModeNewCommand.REPLACE);
		   	this.box.setModePlay(ModePlay.SIMPLE);
		   	
		   	this.setTitle(name);
		   	this.setBounds(400, 400, WIDTH, HEIGHT);
		   	this.setLayout(null);
		   	this.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		   	this.setSize(WIDTH, HEIGHT);
		   	
		   	controller = new Controller();
		   
		   	jPanelCommands = new JPanel();
		   	jPanelCommands.setBounds(100, 0, WIDTH-100, HEIGHT);
		   	jPanelCommands.setLayout(new FlowLayout());
		   	this.add(jPanelCommands);
		   	
		   	for(int i=0; i<names.length; i++)
		   	{
		   		addControllerButton(names[i], commands[i]);
		   	}
		    this.show();
		}
		catch (Exception e) {e.printStackTrace(); }
	    this.show();

	}

	
	
	

	private void addControllerButton(String name, Command command) {
		Button b = new Button();
		b.setPreferredSize(new Dimension((WIDTH-100)/4, 30));
		b.setLabel(name);
		b.addMouseListener(buttonListener);
		jPanelCommands.add(b);
		buttons.add(b);
	}
	
	private class ButtonListener extends MouseAdapter  {
		public void mousePressed (MouseEvent e) {
			int i=0;
			for(Button button : buttons)
			{
				if(e.getSource() == button)	{ this.adjustCommand(commands[i]);  }
				i++;
			}
		}    
		
		private void adjustCommand(Command command) {
			SequencerController.this.adjustCommand(command);
		}
	}
	private synchronized void adjustCommand(Command command) {
		 box.setCommand(command);		
	}
	private synchronized void adjustRun(boolean run) {
		box.setRun(run);
	}	
	private synchronized void adjustModePlay(ModePlay mode) {
		box.setModePlay(mode);
	}
	private synchronized void adjustModeNewCommand(ModeNewCommand mode) {
		box.setModeNewCommand(mode);
	}
	
	
	@Override
	public void control() {		
	}
	
	public void delta(double dt) {
       time = time + dt;
       if (time >= FRAME_TIME) {
          refresh = true;
          while (time >= FRAME_TIME) time = time - FRAME_TIME;
       }
    }



	
	
	  
   private class Controller implements ItemListener {
	    private CheckboxGroup runButtons = new CheckboxGroup();
	    private CheckboxGroup modePlayButtons = new CheckboxGroup();
	    private CheckboxGroup modeNewCmdButtons = new CheckboxGroup();
	    private Checkbox start, stop, simple, loop, reverse, add, replace;
		     
		public Controller() {
		    this.add_start_Checkbox();
		    this.add_stop_Checkbox();

		    this.add_simple_Checkbox();
		    this.add_loop_Checkbox();
		    this.add_reverse_Checkbox();   
		    
			this.add_add_Checkbox();   
		    this.add_replace_Checkbox();
		}

		//run BOX		
	    private void add_start_Checkbox () {
	        start = new java.awt.Checkbox("resume", runButtons, true);
	        start.setBounds(10,10,70,23);
	        start.addItemListener(this);
	        SequencerController.this.add(start); 
	    }	     
		     
	    private void add_stop_Checkbox () {
	        stop = new java.awt.Checkbox("pause", runButtons, false);
	        stop.setBounds(10,30,70,23);
	        stop.addItemListener(this);
	        SequencerController.this.add(stop); 
	    }	     
	      	    
	    //modePlay BOX
	    private void add_simple_Checkbox() {
			simple = new java.awt.Checkbox("simple", modePlayButtons, true);
	        simple.setBounds(10,70,70,23);
	        simple.addItemListener(this);
	        SequencerController.this.add(simple); 
		}
	    
	    private void add_loop_Checkbox () {
	        loop = new java.awt.Checkbox("loop", modePlayButtons, false);
	        loop.setBounds(10,100,80,23);
	        loop.addItemListener(this);
	        SequencerController.this.add(loop); 
	    }	     
		    
	    private void add_reverse_Checkbox () {
	        reverse = new java.awt.Checkbox("reverse", modePlayButtons, false);
	        reverse.setBounds(10,130,70,23);
	        reverse.addItemListener(this);
	        SequencerController.this.add(reverse); 
	    }

	    
	    //ModeNewCmd BOX
		private void add_add_Checkbox() {
			add = new java.awt.Checkbox("add", modeNewCmdButtons, false);
	        add.setBounds(10,180,70,23);
	        add.addItemListener(this);
	        SequencerController.this.add(add); 
		}
		
		private void add_replace_Checkbox() {
			replace = new java.awt.Checkbox("replace", modeNewCmdButtons, true);
	        replace.setBounds(10,210,70,23);
	        replace.addItemListener(this);
	        SequencerController.this.add(replace); 
			
		}
		
		
	    public void itemStateChanged (ItemEvent e) { 
	        if (e.getSource() == start) 	{ this.adjustRun(true); }
	        if (e.getSource() == stop) 		{ this.adjustRun(false); }

	        if (e.getSource() == simple) 	{  this.adjustModePlay(ModePlay.SIMPLE); }
	        if (e.getSource() == loop) 		{ this.adjustModePlay(ModePlay.LOOP); }
	        if (e.getSource() == reverse) 	{ this.adjustModePlay(ModePlay.REVERSE); }
	        
	        if (e.getSource() == add)		{ this.adjustModeNewCommand(ModeNewCommand.ADD); }
	        if (e.getSource() == replace) 	{ this.adjustModeNewCommand(ModeNewCommand.REPLACE);  }
	    }
	    
	    
	    private void adjustRun(boolean run) {
	    	SequencerController.this.adjustRun(run);
	    }
	    private void adjustModePlay(ModePlay mode) {
	    	SequencerController.this.adjustModePlay(mode);
	    } 
	    private void adjustModeNewCommand(ModeNewCommand mode) {
	    	SequencerController.this.adjustModeNewCommand(mode);
	    } 

   
   }

   

   
}