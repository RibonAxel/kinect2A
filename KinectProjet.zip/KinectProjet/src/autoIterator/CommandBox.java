package autoIterator;

import autoIterator.command.Command;

public class CommandBox {

	private Command command;
	private boolean run = true;
	private ModePlay modePlay = ModePlay.SIMPLE;
	private ModeNewCommand modeNewCommand = ModeNewCommand.REPLACE;
	
	
	
	public CommandBox(){
		this.command = Command.STOP;
	modePlay = ModePlay.LOOP;
	modePlay = ModePlay.REVERSE;
	modePlay = ModePlay.SIMPLE;
	
	modeNewCommand = ModeNewCommand.ADD;
	modeNewCommand = ModeNewCommand.REPLACE;

	};
	
	public Command getCommand() { return this.command;}
	public boolean getRun()     { return this.run;}
	public ModePlay getModePlay()		{ return this.modePlay;}
	public ModeNewCommand getModeNewCommand() { return this.modeNewCommand;}
	
	public void setCommand(Command command) { this.command = command;}
	public void setRun(boolean run)       	{ this.run = run;}
	public void setModePlay(ModePlay mode) 			{ this.modePlay = mode;}
	public void setModeNewCommand(ModeNewCommand mode) { this.modeNewCommand = mode; }
	
}
