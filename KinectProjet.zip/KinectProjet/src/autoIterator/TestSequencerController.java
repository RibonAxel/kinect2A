package autoIterator;

import java.net.InetAddress;

import level.DMXLevel;

import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.command.Command;
import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;
import autoIterator.command.shape.DifferentialRectangleShape;
import autoIterator.command.shape.RandomShape;
import autoIterator.command.shape.RectangleShape;

public class TestSequencerController {

	
	
	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREGREEN = {FIXTUREGREEN, FIXTUREGREEN+11, FIXTUREGREEN+22, FIXTUREGREEN+33};
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS);
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
			DmxPacket packet = new DmxPacket();
			
			DoubleValue	pan = new DoubleValue(); 
			DoubleValue	tilt = new DoubleValue(); 
			DoubleValue	red = new DoubleValue(); 
			DoubleValue	blue = new DoubleValue();
			DoubleValue	green = new DoubleValue(); 
			
			RectangleShape rectangle = new RectangleShape(0.3, 0.2, new CommandTime(5, TimeScaleEnum.SEC), tilt, pan);
			
			Parallele setV= new Parallele();
			setV.addCommand(new SetValue(0.5, pan));
			setV.addCommand(new SetValue(0.5, tilt));
			setV.addCommand(new SetValue(0.5, green));
			setV.addCommand(new SetValue(0.5, blue));
			setV.addCommand(new SetValue(0.5, red));
			
			Parallele p1 = new Parallele();
			p1.addCommand(new Interpolation(1, 0.33, new CommandTime(1, TimeScaleEnum.SEC), blue));
			p1.addCommand(new Interpolation(0.33, 0.66, new CommandTime(1, TimeScaleEnum.SEC), red));
			p1.addCommand(new Interpolation(0.66, 1, new CommandTime(1, TimeScaleEnum.SEC), green));
			Parallele p2 = new Parallele();
			p2.addCommand(new Interpolation(1, 0.33, new CommandTime(1, TimeScaleEnum.SEC), green));
			p2.addCommand(new Interpolation(0.33, 0.66, new CommandTime(1, TimeScaleEnum.SEC), blue));
			p2.addCommand(new Interpolation(0.66, 1, new CommandTime(1, TimeScaleEnum.SEC), red));
			Parallele p3 = new Parallele();
			p3.addCommand(new Interpolation(1, 0.33, new CommandTime(1, TimeScaleEnum.SEC), red));
			p3.addCommand(new Interpolation(0.33, 0.66, new CommandTime(1, TimeScaleEnum.SEC), green));
			p3.addCommand(new Interpolation(0.66, 1, new CommandTime(1, TimeScaleEnum.SEC), blue));

			Sequence lightRoll= new Sequence();
			lightRoll.addCommand(p1);
			lightRoll.addCommand(p2);
			lightRoll.addCommand(p3);
			
			SetValue cmdBlue = new SetValue(1, blue);
			SetValue cmdRed = new SetValue(1, red);
			
			RandomShape randomCmd = new RandomShape(10, tilt, pan);
			String[] names1 = {"rectangle", "initPosition", "lightRoll", "red on", "blue on", "random", "strobo", "fan move", "change gobo", "Max500 pan move", "Max500 tilt move", "Acrobat auto on", "Acrobat auto off", };
			String[] names2 = { "red on", "blue on", "random", "strobo", "fan move", "change gobo", "Max500 pan move", "Max500 tilt move", "Acrobat auto on", "Acrobat auto off", };
			String[] names3 = { "red on", "blue on", "random", "strobo", "fan move", "change gobo", "Max500 pan move", "Max500 tilt move", "Acrobat auto on", "Acrobat auto off", };

			
			Command[] commands1 = {rectangle, setV, lightRoll, cmdRed, cmdBlue, randomCmd, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP};
			Command[] commands2 = {cmdRed, cmdBlue, randomCmd, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP};
			Command[] commands3 = {cmdRed, cmdBlue, randomCmd, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP};

			
			CommandBox commandBox = new CommandBox();
		
			SequencerControllerV2 sequencerController = new  SequencerControllerV2(commandBox, names1, commands1, names2, commands2, names3, commands3);
			
			SequencerParametrable sequencer = new SequencerParametrable(commandBox);			
			
			
			DMXUniverse universe = new DMXUniverse();
			Patch pTilt = new Patch(tilt); pTilt.add(MULTFIXTURETILT);
			Patch pPan = new Patch(pan); pPan.add(MULTFIXTUREPAN);
			Patch pRed  = new Patch(red); pRed.add(MULTFIXTURERED);
			Patch pGreen  = new Patch(green); pGreen.add(MULTIFIXTUREGREEN);
			Patch pBlue = new Patch(blue); pBlue.add(MULTFIXTUREBLUE);
			
			universe.add(pPan); universe.add(pTilt); universe.add(pBlue); universe.add(pRed); universe.add(pGreen);
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {sequencerController, sequencer, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
}
