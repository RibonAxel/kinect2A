package autoIterator;

public enum ModePlay {
	SIMPLE, LOOP, REVERSE
}
