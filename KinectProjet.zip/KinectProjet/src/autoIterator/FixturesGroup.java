package autoIterator;

import java.util.ArrayList;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;

public class FixturesGroup {

	
	private ArrayList<DropBox> listPan = new ArrayList<DropBox>();
	private ArrayList<DropBox> listTilt = new ArrayList<DropBox>();
	private ArrayList<DropBox> listRed = new ArrayList<DropBox>();
	private ArrayList<DropBox> listGreen = new ArrayList<DropBox>();
	private ArrayList<DropBox> listBlue = new ArrayList<DropBox>();
	private ArrayList<DropBox> listDimmer = new ArrayList<DropBox>();

	private int nbrFixture = 0;
	
	public FixturesGroup(){}

	public void addFixture(DoubleValue pan, DoubleValue tilt, DoubleValue red, DoubleValue blue, DoubleValue green, DoubleValue dimmer){
		this.listPan.add(new AdaptaterDoubleValueToDropBox(pan));
		this.listTilt.add(new AdaptaterDoubleValueToDropBox(tilt));
		this.listBlue.add(new AdaptaterDoubleValueToDropBox(blue));
		this.listRed.add(new AdaptaterDoubleValueToDropBox(red));
		this.listGreen.add(new AdaptaterDoubleValueToDropBox(green));
		this.listDimmer.add(new AdaptaterDoubleValueToDropBox(dimmer));
		nbrFixture++;
	}
	
	public ArrayList<DropBox> getPan()  	{ return this.listPan; }
	public ArrayList<DropBox> getTilt() 	{ return this.listTilt; }
	public ArrayList<DropBox> getDimmer() 	{ return this.listDimmer; }
	public ArrayList<DropBox> getGreen()	{ return this.listGreen; }
	public ArrayList<DropBox> getBlue() 	{ return this.listBlue; }
	public ArrayList<DropBox> getRed() 	 	{ return this.listRed; }
	public int getNbrFixture() 				{ return this.nbrFixture;}
}
