package autoIterator;

import generators.GlobalSequenceGenerator;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;

import java.net.InetAddress;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;

import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;

public class TestAutoSequencerController {
	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREGREEN = {FIXTUREGREEN, FIXTUREGREEN+11, FIXTUREGREEN+22, FIXTUREGREEN+33};
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS);
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
			DmxPacket packet = new DmxPacket();
			
			DoubleValue	sPan = new DoubleValue(); 
			DoubleValue	sTilt = new DoubleValue(); 
			DoubleValue	sRed = new DoubleValue(); 
			DoubleValue	sBlue = new DoubleValue();
			DoubleValue	sGreen = new DoubleValue(); 
			 
			CommandBox commandBox = new CommandBox();
			
			AutoSequencerController seqController = new AutoSequencerController(sBlue, sRed, sGreen, sPan, sTilt, commandBox);
			
			SequencerParam sequencer = new SequencerParam(commandBox);			
			
			
			DMXUniverse universe = new DMXUniverse();
			Patch pTilt = new Patch(sTilt); pTilt.add(MULTFIXTURETILT);
			Patch pPan = new Patch(sPan); pPan.add(MULTFIXTUREPAN);
			Patch pRed  = new Patch(sRed); pRed.add(MULTFIXTURERED);
			Patch pGreen  = new Patch(sGreen); pGreen.add(MULTIFIXTUREGREEN);
			Patch pBlue = new Patch(sBlue); pBlue.add(MULTFIXTUREBLUE);
			
			universe.add(pPan); universe.add(pTilt); universe.add(pBlue); universe.add(pRed); universe.add(pGreen);
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {seqController, sequencer, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
	
}
