//Created by BB on 24/05/11

package autoIterator;

import generators.signal.startStop.StartStopValue;
import autoIterator.command.Command;
import pi.executive.ContinuousAgent;

public class Sequenceur implements ContinuousAgent{

	private Command command;
//	private StartStopValue globalStartStopValue = new StartStopValue();
	
	public Sequenceur(){
//		this.globalStartStopValue.run(true);
	}
	
	public void setCommand(Command command){
		this.command = command;
		this.command.begin();
	}
	
	@Override
	public void control() {
		if(!this.command.isExhausted())
			this.command.control();
	}
	@Override
	public void delta(double dt) {
		if(!this.command.isExhausted())
			this.command.execute(dt);
		else
			this.command.begin();

	}
}
