package autoIterator;

import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.command.Command;
import autoIterator.command.Wait;
import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import pi.endpoint.DoubleValue;
import pi.executive.ContinuousAgent;

public class AutoSequencerController implements ContinuousAgent{


	private double time = 0;
	private Sequence rectangle = new Sequence();
	private Parallele setV= new Parallele();
	private Sequence lightRoll= new Sequence();
	private CommandBox commandBox;
	
	public AutoSequencerController(DoubleValue blue, DoubleValue red, DoubleValue green, DoubleValue pan, DoubleValue tilt, CommandBox commandBox){
		this.rectangle.addCommand(new Interpolation(0, 0.4, new CommandTime(5, TimeScaleEnum.SEC), pan));
		this.rectangle.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.ECLAT)));
		this.rectangle.addCommand(new Interpolation(0, 0.4, new CommandTime(5, TimeScaleEnum.SEC), tilt));
		this.rectangle.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.ECLAT)));
		this.rectangle.addCommand(new Interpolation(0.4, 0, new CommandTime(5, TimeScaleEnum.SEC), pan));
		this.rectangle.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.ECLAT)));
		this.rectangle.addCommand(new Interpolation(0.4, 0, new CommandTime(5, TimeScaleEnum.SEC), tilt));
		this.rectangle.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.ECLAT)));

		this.setV.addCommand(new SetValue(0.5, pan));
		this.setV.addCommand(new SetValue(0.5, tilt));
		this.setV.addCommand(new SetValue(0.5, green));
		this.setV.addCommand(new SetValue(0.5, blue));
		this.setV.addCommand(new SetValue(0.5, red));
		
		Parallele p1 = new Parallele();
		p1.addCommand(new Interpolation(1, 0.33, new CommandTime(1, TimeScaleEnum.SEC), blue));
		p1.addCommand(new Interpolation(0.33, 0.66, new CommandTime(1, TimeScaleEnum.SEC), red));
		p1.addCommand(new Interpolation(0.66, 1, new CommandTime(1, TimeScaleEnum.SEC), green));
		Parallele p2 = new Parallele();
		p2.addCommand(new Interpolation(1, 0.33, new CommandTime(1, TimeScaleEnum.SEC), green));
		p2.addCommand(new Interpolation(0.33, 0.66, new CommandTime(1, TimeScaleEnum.SEC), blue));
		p2.addCommand(new Interpolation(0.66, 1, new CommandTime(1, TimeScaleEnum.SEC), red));
		Parallele p3 = new Parallele();
		p3.addCommand(new Interpolation(1, 0.33, new CommandTime(1, TimeScaleEnum.SEC), red));
		p3.addCommand(new Interpolation(0.33, 0.66, new CommandTime(1, TimeScaleEnum.SEC), green));
		p3.addCommand(new Interpolation(0.66, 1, new CommandTime(1, TimeScaleEnum.SEC), blue));

		this.lightRoll.addCommand(p1);
		this.lightRoll.addCommand(p2);
		this.lightRoll.addCommand(p3);
		
		this.commandBox = commandBox;
		this.commandBox.setModeNewCommand(ModeNewCommand.REPLACE);
		this.commandBox.setModePlay(ModePlay.SIMPLE);
		this.commandBox.setRun(true);
		this.commandBox.setCommand(rectangle);
	}
	
	@Override
	public void control() {
		if(time>120 && time<300){
			this.commandBox.setCommand(setV);
		}
		if(this.time>300 && this.time< 800)
		{
			this.commandBox.setCommand(lightRoll);
			this.commandBox.setModePlay(ModePlay.REVERSE);
		}
		if(this.time > 800)
		{
			this.commandBox.setCommand(Command.STOP);
		}
	}

	@Override
	public void delta(double dt) {
		time++;
			
	}

	
	
	
}
