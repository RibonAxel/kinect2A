package autoIterator;

import pi.executive.ContinuousAgent;
import autoIterator.command.Command;
import autoIterator.command.Parallele;

public class SequencerParametrableParallele  implements ContinuousAgent{

	private Command currentCommand = Command.STOP;
	private Parallele commands = new Parallele();
	private CommandBox commandBox;

	
	public SequencerParametrableParallele(CommandBox commandBox){
		this.commandBox = commandBox;
	}
	
	private void setCommand(Command command){
		this.commands = new Parallele();
		this.commands.addCommand(command);
		this.commands.begin();
	}
	
	private void addCommand(Command command){
		this.commands.addCommand(command);
		command.begin();
	}
	
	@Override
	public void control() {
		if(this.commandBox.getRun()){
			if(!this.commands.isExhausted() )
				this.commands.control();
		}

	}
	@Override
	public void delta(double dt) {
		if(this.currentCommand != this.commandBox.getCommand() )
		{
			this.currentCommand = this.commandBox.getCommand();
			switch (this.commandBox.getModeNewCommand()) {
			case REPLACE:
				this.setCommand(currentCommand);
			break;
				
			case ADD:
				this.addCommand(currentCommand);
			break;
				
			default:
				break;
			}
		}
				
		if(this.commandBox.getRun())
		{
			if(!this.commands.isExhausted()){
				this.commands.execute(dt);
			}
			else{
				switch (this.commandBox.getModePlay()) {
				case LOOP:
					this.commands.begin();
				break;
				
				case REVERSE: 
					this.commands.reverseBegin();
				break;
				
				case SIMPLE:
				break;
					
				default:
					break;
				}	
			}
		}
		
	}
}
