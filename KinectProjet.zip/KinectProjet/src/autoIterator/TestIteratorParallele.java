package autoIterator;

import generators.GlobalSequenceGenerator;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;

import java.net.InetAddress;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;

public class TestIteratorParallele {
	
	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTUREGREEN = {FIXTUREGREEN, FIXTUREGREEN+11, FIXTUREGREEN+22, FIXTUREGREEN+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS);
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
			DmxPacket packet = new DmxPacket();
			
			DropBox blueValue  = new DropBox();
			DropBox redValue   = new DropBox();
			DropBox greenValue = new DropBox();
			DropBox panValue = new DropBox();

			
			SetValue setValueBlue = new SetValue( 1, blueValue);
			SetValue setValueGreen = new SetValue( 1, greenValue);
			SetValue setValueRed = new SetValue( 1, redValue);
			Interpolation interpolation = new Interpolation(0, 1, new CommandTime(5, TimeScaleEnum.SEC), panValue);

			
			Parallele parallele = new Parallele();
			parallele.addCommand(setValueBlue);
			parallele.addCommand(setValueGreen);
			parallele.addCommand(setValueRed);
			parallele.addCommand(interpolation);
			
			Sequenceur sequenceur = new Sequenceur();			
			sequenceur.setCommand(parallele);
			
			
			DoubleValue     	sBlue = new DoubleValue(); 
			PolymorphWave pwBlue = new PolymorphWave(ShapeEnum.CONST);
			DoubleValue     	sGreen = new DoubleValue(); 
			PolymorphWave pwGreen = new PolymorphWave(ShapeEnum.CONST);
			DoubleValue     	sRed = new DoubleValue(); 
			PolymorphWave pwRed = new PolymorphWave(ShapeEnum.CONST);
			DoubleValue      sPan = new DoubleValue(); 
			PolymorphWave pwPan = new PolymorphWave(ShapeEnum.CONST);

			GlobalSequenceGenerator  gBlue= new GlobalSequenceGenerator(pwBlue, blueValue, blueValue.getStartStopValue(), sBlue); 
			GlobalSequenceGenerator  gGreen = new GlobalSequenceGenerator(pwGreen, greenValue, greenValue.getStartStopValue(), sGreen); 
			GlobalSequenceGenerator  gRed = new GlobalSequenceGenerator(pwRed, redValue, redValue.getStartStopValue(), sRed); 
			GlobalSequenceGenerator  gPan = new GlobalSequenceGenerator(pwPan, panValue, panValue.getStartStopValue(), sPan); 

			
			DMXUniverse universe = new DMXUniverse();
			Patch pBlue  = new Patch(sBlue); pBlue.add(MULTFIXTUREBLUE);  
			Patch pGreen  = new Patch(sGreen); pGreen.add(MULTFIXTUREGREEN);
			Patch pRed  = new Patch(sRed); pRed.add(MULTFIXTURERED);
			Patch pPan  = new Patch(sPan); pPan.add(MULTFIXTUREPAN);

			universe.add(pBlue); universe.add(pGreen); universe.add(pRed);universe.add(pPan);
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {gBlue, gGreen, gRed, gPan, sequenceur, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
	
}