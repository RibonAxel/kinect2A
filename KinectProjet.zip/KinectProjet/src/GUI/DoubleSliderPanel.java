// Created by BB on 17/05/11

package GUI;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class DoubleSliderPanel {

	private JSlider slider;
	private JTextField txt;
	private JLabel label;
	JPanel panel;
	private double value;
	
	public DoubleSliderPanel(JPanel container, int x, int y, int width,int height, String name) {
		this.panel = new JPanel();
		panel.setLayout(null);
		
	    panel.setPreferredSize(new Dimension(width+40,height+40));
		panel.setBounds(x,y, width+50,height+50);
		
		this.slider = new JSlider(JSlider.VERTICAL,0,100,0);//direction , min , max , current
        this.slider.setFont(new Font("Tahoma",Font.BOLD,12));
        this.slider.setMajorTickSpacing(10);
        this.slider.setMinorTickSpacing(1);
        this.slider.setPaintLabels(true);
        this.slider.setPaintTicks(true);
        this.slider.setPaintTrack(true);
                 
      //  this.slider.setPreferredSize(new Dimension(width, height));
        this.slider.setPreferredSize(new Dimension( width, height));
        this.slider.setBounds((this.panel.getPreferredSize().width/2) - (this.slider.getPreferredSize().width/2) , 50, this.slider.getPreferredSize().width, this.slider.getPreferredSize().height);
        panel.add(this.slider); 
	        
	    this.txt = new JTextField(4);
	    this.txt.setText(String.valueOf(slider.getValue()));
	    this.txt.addActionListener(new ActionListener() {    
            public void actionPerformed(ActionEvent e) {
                try
                {
                	
                    slider.setValue((int) (Double.parseDouble(txt.getText())*100));
                    value = ((double)slider.getValue())/100;
                }
                catch(Exception ex)
                {
                    txt.setText("ERROR");
                    txt.setToolTipText("Set Value in Range between 0 - 1 ") ;
                }
            }
        });
        //When Changing Slider 2 Cursor...do this
        slider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                txt.setText(String.valueOf(((double)slider.getValue())/100));
                value = ((double)slider.getValue())/100;
            }
        });
       
        //Create the label table
        Hashtable labelTable = new Hashtable();
        labelTable.put( new Integer( 0 ), new JLabel("0") );
        labelTable.put( new Integer(100  ), new JLabel("1") );
        this.slider.setLabelTable( labelTable );
        this.slider.setPaintLabels(true);

        //this.txt.set(x, y+25,width,25);
        this.txt.setBounds((this.panel.getPreferredSize().width/2) - (this.txt.getPreferredSize().width/2) , 25, this.txt.getPreferredSize().width, this.txt.getPreferredSize().height);
	    panel.add(this.txt/*, BorderLayout.PAGE_END*/);
	    
	    this.label = new JLabel(name);
	    this.label.setBounds((this.panel.getPreferredSize().width/2) - (this.label.getPreferredSize().width/2) , 0, this.label.getPreferredSize().width, this.label.getPreferredSize().height);
	    panel.add(this.label/*, BorderLayout.PAGE_END*/);
	    
	    panel.setPreferredSize(new Dimension(width+40,height+40));
	    
	    panel.setVisible(true);
	    container.add(panel);
	    container.setVisible(true);
	    container.repaint();
	}
	
	public double getValue(){
		return this.value;
	}
}
