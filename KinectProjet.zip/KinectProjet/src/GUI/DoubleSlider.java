// Created by BB on 13/05/11

package GUI;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class DoubleSlider {

	private JSlider slider;
	private JTextField txt;
	private JLabel label;
	private double value;
	
	public DoubleSlider(JFrame container, int x, int y, int width,int height, String name) {
  	  	this.slider = new JSlider(JSlider.VERTICAL,0,100,0);//direction , min , max , current
        this.slider.setFont(new Font("Tahoma",Font.BOLD,12));
        this.slider.setMajorTickSpacing(10);
        this.slider.setMinorTickSpacing(1);
        this.slider.setPaintLabels(true);
        this.slider.setPaintTicks(true);
        this.slider.setPaintTrack(true);
                 
        this.slider.setBounds(x,y+50, width, height);
          
        container.getContentPane().add(this.slider); 
	    container.setVisible(true);
	        
	    this.txt = new JTextField(4);
	    this.txt.setText(String.valueOf(slider.getValue()));
	    this.txt.addActionListener(new ActionListener() {    
            public void actionPerformed(ActionEvent e) {
                try
                {
                	
                    slider.setValue((int) (Double.parseDouble(txt.getText())*100));
                    value = ((double)slider.getValue())/100;
                }
                catch(Exception ex)
                {
                    txt.setText("ERROR");
                    txt.setToolTipText("Set Value in Range between 0 - 1 ") ;
                }
            }
        });
        //When Changing Slider 2 Cursor...do this
        slider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                txt.setText(String.valueOf(((double)slider.getValue())/100));
                value = ((double)slider.getValue())/100;
            }
        });
       
        //Create the label table
        Hashtable labelTable = new Hashtable();
        labelTable.put( new Integer( 0 ), new JLabel("0") );
        labelTable.put( new Integer(100  ), new JLabel("1") );
        this.slider.setLabelTable( labelTable );
        this.slider.setPaintLabels(true);

        this.txt.setBounds(x, y+25,width,25);
	    container.getContentPane().add(this.txt);
	    
	    this.label = new JLabel(name);
	    this.label.setBounds(x,y, width, 25);
	    container.getContentPane().add(this.label);
	    container.repaint();
	}
	
	public double getValue(){
		return this.value;
	}
}
