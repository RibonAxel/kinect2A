//  TestOscilloscope.java
//  Created by Bernard Thirion on 21/03/07.

package oscillo;

import pi.executive.Agent;
import pi.endpoint.DoubleValue;
import pi.container.Container;
import pi.container.SimpleContainer;
import pi.container.CompositeContainer;
import pi.application.Application;

import vanderpol.VanderpolGenerator;

public class TestOscilloscope {
   
   public static void test() {
   
      DoubleValue        S1 = new DoubleValue();
      VanderpolGenerator G1 = new VanderpolGenerator(S1, 1.0, 2.0, 3.0);
      SimpleContainer    O1 = new SimpleContainer(new Oscilloscope(S1, "Vand Der Pol 1"));

      DoubleValue        S2 = new DoubleValue();
      VanderpolGenerator G2 = new VanderpolGenerator(S2, 2.0, 3.0, 2.0);
      SimpleContainer    O2 = new SimpleContainer(new Oscilloscope(S2, "Vand Der Pol 2"));

      DoubleValue        S3 = new DoubleValue();
      VanderpolGenerator G3 = new VanderpolGenerator(S3, 4.0, 4.0, 2.0);
      SimpleContainer    O3 = new SimpleContainer(new Oscilloscope(S3, "Vand Der Pol 3"));
      
      CompositeContainer C  = new CompositeContainer();
      
      C.addMembers (new Container[] {G1, O1, G2, O2, G3, O3});
      
      Application        A  = new Application(C, 0.015, 0.001);
      
      A.start();   
   }
        
}
