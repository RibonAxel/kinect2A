//  Created by BB on 06 05 11.

package oscillo;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class DMXOscilloscopeCanvas extends Canvas  {

	   private static final int U       = 40;         // Grid size
	   public  static final int SAMPLES = 10 * U;     // Number of samples
	   private static final int YMAX    = SAMPLES - 1;   

	   private static final int MARGE  = 10;
	   private static final int WIDTH  = SAMPLES + 2*MARGE + 1;
	   private static final int HEIGHT =     6*U + 2*MARGE + 1;
	   private static final int ZERO   = HEIGHT / 2;
	      
	   private static final Color screenColor = new Color(25,   60,  74);
	   private static final Color gridColor   = new Color(20,  110, 100);
	   private static final Color traceColor  = new Color(180, 255, 255);

	   private double  yScale         = 0.020 * U; 
	   private boolean drawAsCurve    = true; 
	   private Image   offscreenImage = null;   
	    
	   
	   private DMXOscilloscopeData samples;
	   
	   public DMXOscilloscopeCanvas (int X0, int Y0, DMXOscilloscopeData samples) { 
	      this.setBounds(X0, Y0, WIDTH, HEIGHT);
	      this.samples = samples;
	   }

	   private void drawScreen(Graphics g) {
	      g.setColor(screenColor); 
	      g.fillRect(0,0, WIDTH, HEIGHT);
	   }
	  
	   private void drawGrid(Graphics g) {
	      g.setColor(gridColor);
	      g.drawLine(MARGE, ZERO, MARGE + YMAX, ZERO); 
	      g.drawLine(MARGE, ZERO +   U, MARGE + YMAX, ZERO +   U); 
	      g.drawLine(MARGE, ZERO + 2*U, MARGE + YMAX, ZERO + 2*U); 
	      g.drawLine(MARGE, ZERO + 3*U, MARGE + YMAX, ZERO + 3*U);
	      g.drawLine(MARGE, ZERO -   U, MARGE + YMAX, ZERO -   U); 
	      g.drawLine(MARGE, ZERO - 2*U, MARGE + YMAX, ZERO - 2*U); 
	      g.drawLine(MARGE, ZERO - 3*U, MARGE + YMAX, ZERO - 3*U); 
	      
	      for (int i = 0; i <= 10; i++) {
	         int x = MARGE + i*U;  
	         g.drawLine(x, ZERO - 3*U, x, ZERO + 3*U); 
	      }
	   }
	      
	   private void drawTraceAsDots(Graphics g) {
	      int x, y;
	      g.setColor(traceColor); 
	      for (int i = 0; i < YMAX; i++) {
	         x = MARGE + i;     
	         y = ZERO-(int) (samples.sample(i) * yScale);  
	         g.drawLine(x, y, x, y); 
	      }
	   }

	   private void drawTraceAsCurve(Graphics g) {
	      int x1, x2, y1, y2;
	      g.setColor(traceColor); 
	      for (int i = 0; i < (YMAX - 1); i++) {
	         x1 = MARGE + i; x2 = x1 + 1;     
	         y1 = HEIGHT-10 - (int) (samples.sample(i  ) * yScale);     
	         y2 = HEIGHT-10 - (int) (samples.sample(i+1) * yScale);     
	         g.drawLine(x1, y1, x2, y2);          
	      }
	   }

	   private void draw(Graphics g) {
	      this.drawScreen(g);
	      this.drawGrid(g);
	      if (drawAsCurve) drawTraceAsCurve(g); else drawTraceAsDots(g);
	   }

	   public void paint(Graphics g){
	      if (offscreenImage == null)
	          offscreenImage = createImage(WIDTH, HEIGHT);
	      Graphics image = offscreenImage.getGraphics();
	      this.draw(image);
	      g.drawImage(offscreenImage, 0, 0, this);
	   }
	   
	   public synchronized void update () {
	      paint(this.getGraphics());
	   }
	   
	}
