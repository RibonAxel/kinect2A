//  Created by BB on 09/05/11.

package oscillo;

import generators.SignalGenerator;
import generators.signal.Constant;
import pi.executive.Agent;
import pi.endpoint.AdaptaterDoubleValueToDMXValue;
import pi.endpoint.DoubleValue;
import pi.container.SimpleContainer;
import pi.container.CompositeContainer;
import pi.application.Application;


public class TestDMXOscilloscope {
   
	
	 public static void main (String[] args) {
   
      DoubleValue        S1 = new DoubleValue();
      SignalGenerator  G1 = new SignalGenerator(new Constant(1), S1); 
      DMXOscilloscope    O1 = new DMXOscilloscope(new AdaptaterDoubleValueToDMXValue(S1), "254");

      DoubleValue        S2 = new DoubleValue();
      SignalGenerator  G2 = new SignalGenerator(new Constant(0), S2); 
      DMXOscilloscope    O2 = new DMXOscilloscope(S2, "0");

      DoubleValue        S3 = new DoubleValue();
      SignalGenerator  G3 = new SignalGenerator(new Constant(0.5), S3); 
      DMXOscilloscope    O3 = new DMXOscilloscope(new AdaptaterDoubleValueToDMXValue(S3), "127");
      
      CompositeContainer C  = new CompositeContainer();
      
      SimpleContainer instrument  = new SimpleContainer(new Agent[] { O1, G2,O2, G3,O3, G1});
      Application     application = new Application(instrument, 0.025, 0.005);
   
	   
	   
      application.start();      
   }
        
}


