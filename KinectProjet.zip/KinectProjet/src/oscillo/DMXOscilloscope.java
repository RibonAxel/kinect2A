//  Created by BB on 06 05 11.


package oscillo;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;

import java.awt.Label;
import java.awt.event.*;
import javax.swing.JFrame;

import pi.executive.ContinuousAgent;
import pi.endpoint.AdaptaterDoubleSourceToDMXSource;
import pi.endpoint.DMXSource;
import pi.endpoint.DoubleSource;
import pi.endpoint.DMXProbe;

public class DMXOscilloscope extends JFrame implements ContinuousAgent {

	   private static final int       WIDTH   = 530;
	   private static final int       HEIGHT  = 350;
	   private static final double FRAME_TIME = 0.050;
	   
	   private double  time    = 0;
	   private boolean refresh = true;

	   private DMXOscilloscopeData   samples;
	   private DMXOscilloscopeCanvas canvas;
	   private Controller         controller; 
	   private DMXProbe        	probe;

	   private Label  zero  = new Label ("0", Label.LEFT);
	   private Label  max   = new Label ("?", Label.RIGHT);

	   public DMXOscilloscope(DMXSource source) {
	      this (source, "DMXOscilloscope");
	   }   
	   public DMXOscilloscope(DoubleSource source) {
		      this (new AdaptaterDoubleSourceToDMXSource(source), "DMXOscilloscope");
	   }   
	   
	   public DMXOscilloscope(DoubleSource source, String name) {
		      this.probe   = new DMXProbe( new AdaptaterDoubleSourceToDMXSource(source));
		      this.setTitle(name);
		      this.samples = new DMXOscilloscopeData (DMXOscilloscopeCanvas.SAMPLES);
		      this.getContentPane().setLayout(null);
		      this.setSize(WIDTH, HEIGHT);
		      this.samples = samples;
		      canvas = new DMXOscilloscopeCanvas(15, 25, samples);
		      controller = new Controller();
		      this.getContentPane().add(canvas);
		      zero.setBounds( 20,8, 20,16); getContentPane().add(zero);
		      max.setBounds (340,8,100,16); getContentPane().add(max );
		      this.show();
		   }
	   
	   public DMXOscilloscope(DMXSource source, String name) {
	      this.probe   = new DMXProbe(source);
	      this.setTitle(name);
	      this.samples = new DMXOscilloscopeData (DMXOscilloscopeCanvas.SAMPLES);
	      this.getContentPane().setLayout(null);
	      this.setSize(WIDTH, HEIGHT);
	      this.samples = samples;
	      canvas = new DMXOscilloscopeCanvas(15, 25, samples);
	      controller = new Controller();
	      this.getContentPane().add(canvas);
	      zero.setBounds( 20,8, 20,16); getContentPane().add(zero);
	      max.setBounds (340,8,100,16); getContentPane().add(max );
	      this.show();
	   }

	   
	   public String toString () { return "DMXOscilloscope " + this.getTitle(); }

	   public void control () { 
	      if (refresh) {
	         this.refresh();
	         refresh = false;
	      }
	    }
	   
	   	public void delta(double dt) {
	       this.sample();
	       time = time + dt;
	       if (time >= FRAME_TIME) {
	          refresh = true;
	          while (time >= FRAME_TIME) time = time - FRAME_TIME;
	       }
	       max.setText(String.valueOf(dt*samples.size()));
	    }
	 
	   // the 3 following methods are synchronized to provide mutual exclusion 
	   // of the pi thread and the controller (gui thread)
	     
	   private synchronized void sample () { 
	      double sample = probe.value();
	      samples.addSample(sample); 
	   }

	   private synchronized void refresh () {
	      canvas.update();
	   }
	   
	   private synchronized void adjustGain(double g) {
	      probe.adjust(g);
	      samples.clear();
	   }
	  
	   private class Controller implements ItemListener {
	      private CheckboxGroup buttons = new CheckboxGroup();
	      private Checkbox mul_1, mul_10, mul_100, mul_1000, div_10, div_100, div_1000;
		     
	      public Controller() {
		        this.add_div_1000_Checkbox();
		        this.add_div_100_Checkbox ();
		        this.add_div_10_Checkbox  ();
		        this.add_mul_1_Checkbox   ();
		        this.add_mul_10_Checkbox  ();
		        this.add_mul_100_Checkbox ();
		        this.add_mul_1000_Checkbox();
	     }

	      private void add_div_1000_Checkbox () {
	         div_1000 = new java.awt.Checkbox("1/1000", buttons, false);
	         div_1000.setBounds(450,25,80,23);
	         div_1000.addItemListener(this);
	         getContentPane().add(div_1000); 
	      }	     

	      private void add_div_100_Checkbox () {
	         div_100 = new java.awt.Checkbox("1/100", buttons, false);
	         div_100.setBounds(450,50,80,23);
	         div_100.addItemListener(this);
	         getContentPane().add(div_100); 
	      }	     

	      private void add_div_10_Checkbox () {
	         div_10 = new java.awt.Checkbox("1/10", buttons, false);
	         div_10.setBounds(450,75,80,23);
	         div_10.addItemListener(this);
	         getContentPane().add(div_10); 
	      }	     
			  	    
	      private void add_mul_1_Checkbox () {
	         mul_1 = new java.awt.Checkbox("1", buttons, true);
	         mul_1.setBounds(450,100,80,23);
	         mul_1.addItemListener(this);
	         getContentPane().add(mul_1); 
	      }	 
	      
	      private void add_mul_10_Checkbox () {
	         mul_10 = new java.awt.Checkbox("10", buttons, false);
	         mul_10.setBounds(450,125,80,23);
	         mul_10.addItemListener(this);
	         getContentPane().add(mul_10); 
	      }	     
	      
	      private void add_mul_100_Checkbox () {
	         mul_100 = new java.awt.Checkbox("100", buttons, false);
	         mul_100.setBounds(450,150,80,23);
	         mul_100.addItemListener(this);
	         getContentPane().add(mul_100); 
	      }	     

	      private void add_mul_1000_Checkbox () {
	         mul_1000 = new java.awt.Checkbox("1000", buttons, false);
	         mul_1000.setBounds(450,175,80,23);
	         mul_1000.addItemListener(this);
	         getContentPane().add(mul_1000); 
	      }	     
	    
	      public void itemStateChanged (ItemEvent e) { 
	         if (e.getSource() == div_1000) { this.adjustGain(0.001 ); }
	         if (e.getSource() == div_100 ) { this.adjustGain(0.01  ); }
	         if (e.getSource() == div_10  ) { this.adjustGain(0.1   ); }
	         if (e.getSource() == mul_1   ) { this.adjustGain(1.0   ); }
	         if (e.getSource() == mul_10  ) { this.adjustGain(10.0  ); }
	         if (e.getSource() == mul_100 ) { this.adjustGain(100.0 ); }
	         if (e.getSource() == mul_1000) { this.adjustGain(1000.0); }
	      } 
	      
	      private void adjustGain(double g) {
	         DMXOscilloscope.this.adjustGain(g);
	      }
	      
	   }

}
