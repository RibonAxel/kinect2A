//  Data.java
//  Created by Bernard Thirion on Sun Jan 08 2006.

package oscillo;

public class OscilloscopeData {

   private int writeIndex;  
   private int origine;  

   private double[] samples;
   
   
   public OscilloscopeData (int size) { // size is number of samples
      this.samples   = new double[size];
      this.clear();
   }

   public int size()      { return samples.length;  }
   
   public double sample(int index) {
      int i = (origine + index) % samples.length ;
      return this.samples[i]; 
   }
   
   public void clear () {
      for (int i = 0;  i < samples.length; i++) { 
        samples[i] = 0.0;
      }    
      this.writeIndex = samples.length - 1;
      this.origine    = 0;
   }      
   
   public void addSample(double v) {
      samples[writeIndex] = v; 
      writeIndex = (writeIndex + 1) % samples.length;
      origine    = (origine    + 1) % samples.length;
   }
           
}
