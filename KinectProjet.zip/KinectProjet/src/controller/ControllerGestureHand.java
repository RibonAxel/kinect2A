package controller;

import algo.Algo;
import algo.BDD;
import algo.Template;
import dmx.osc.DMXProxy;
import joints.Hand;

import java.awt.Canvas;
import java.awt.Point;
import java.util.ArrayList;

public class ControllerGestureHand extends Canvas implements ControllerInterface {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ArrayList<Integer> CANAL = new ArrayList<Integer>();
	private ArrayList<Template> t = BDD.getBDD();
	public static ArrayList<Point> shape = new ArrayList<Point>();

	private DMXProxy dmxProxy;

	private Hand left;
	private Hand right;

	private int testOne =0;

	public ControllerGestureHand(DMXProxy dmxProxy,ArrayList<Integer> canal,Hand right, Hand left){
		for (int i =0;i<canal.size();i++){
			CANAL.addAll(canal);
		}

		this.left = left;
		this.right = right;
		this.dmxProxy = dmxProxy;
	}

	public  void update() {
		fonction();
	}

	private void fonction() {
		
		if (!right.getOpen()){

			shape.add(new Point( (int) left.getX(),(int) left.getY()));
			System.out.println(shape.size());
			testOne =0;
		}
		
		else 
			resetNull();

		if (right.getOpen() && shape.size() != 0 && testOne  == 0){
			testOne =1;
			
			shape = Algo.formalizeTemplate(new Template(shape, "tested"));
			System.out.println(Algo.Trecognize(shape, t).getName());
			System.out.println("name");
			System.out.println(Algo.Drecognize(shape,t));
			System.out.println("terminated");


			if (Algo.Trecognize(shape, t).getName() == "caret")
				dmxProxy.set(35, 250);
			
			if (Algo.Trecognize(shape, t).getName() == "rectangle")
				dmxProxy.set(36, 240);
			
			System.out.println(shape);
			shape.clear();
		}
	}

	public void resetNull(){

		dmxProxy.set(34,0);
		dmxProxy.set(35,0);
		dmxProxy.set(36,0);
		dmxProxy.set(37,0);
		dmxProxy.set(38,0);
		dmxProxy.set(39,0);
		dmxProxy.set(40,0);

		dmxProxy.set(50,0);
		dmxProxy.set(51,0);
		dmxProxy.set(52,0);
		dmxProxy.set(53,0);
		dmxProxy.set(54,0);
		dmxProxy.set(55,0);
	}
}

