package controller;

import java.awt.Point;
import java.util.ArrayList;

import javax.swing.JFrame;

import algo.Algo;
import algo.BDD;
import algo.Template;
import dmx.osc.DMXProxy;
import graphics.shapes.ui.Editor;
import joints.Hand;

public class ControllerPaintHand extends JFrame implements ControllerInterface{

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	
	private ArrayList<Integer> CANAL = new ArrayList<Integer>();
	public static ArrayList<Point> shape = new ArrayList<Point>();
	
	private ArrayList<Template> t = BDD.getBDD();
	
	private DMXProxy dmxProxy;
	private int testOne =0;

	private Hand right;
	private Hand left;
	
	Editor self = new Editor();
	
	public ControllerPaintHand(DMXProxy dmxProxy ,ArrayList<Integer> canal, Hand right, Hand left){
		
        self.pack();
        self.setVisible(true);
		
		for (int i =0;i<canal.size();i++){
			CANAL.addAll(canal);
		}
		
		this.left = left;
		this.right = right;
		this.dmxProxy = dmxProxy;
		
	}

	public  void update() {	
		fonction();
	}

	private void fonction(){
		if (!right.getOpen()){

			shape.add(new Point( (int) left.getX(),(int) left.getY()));
			testOne =0;
		}

		else if (right.getOpen() && shape.size() != 0 && testOne  == 0){
			testOne =1;
			
			shape = Algo.formalizeTemplate(new Template(shape, "tested"));
			System.out.println(Algo.Trecognize(shape, t).getName());
			System.out.println("name");
			System.out.println(Algo.Drecognize(shape,t));
			System.out.println("terminated");


			if (Algo.Trecognize(shape, t).getName() == "caret"){
				self.setVisible(false);
				Editor.buildCircle();
				self.setVisible(true);
				
				//dmxProxy.set(CANAL.get(i), (int) (left.getX()/2000*255));
			}

			if (Algo.Trecognize(shape, t).getName() == "rectangle"){
				self.setVisible(false);
				Editor.buildRectangle();
				self.setVisible(true);
			}
			
			if (Algo.Trecognize(shape, t).getName() == "circle"){
				self.setVisible(false);
				Editor.buildCircle();
				self.setVisible(true);
			}
			
			if (Algo.Trecognize(shape, t).getName() == "delete"){
				System.out.println("delete imprim�");
			}

			Editor.model.resize((int) left.getX(), 0);
			System.out.println(shape);
			shape.clear();
		}
	}

	public void resetNull(){
		dmxProxy.set(34,0);
		dmxProxy.set(35,0);
		dmxProxy.set(36,0);
		dmxProxy.set(37,0);
		dmxProxy.set(38,0);
		dmxProxy.set(39,0);
		dmxProxy.set(40,0);

		dmxProxy.set(50,0);
		dmxProxy.set(51,0);
		dmxProxy.set(52,0);
		dmxProxy.set(53,0);
		dmxProxy.set(54,0);
		dmxProxy.set(55,0);
	}
}
