package controller;

import java.util.ArrayList;
import dmx.osc.DMXProxy;
import joints.Hand;

public class ControllerSliderHand implements ControllerInterface{

	private ArrayList<Integer> CANAL = new ArrayList<Integer>();
	private DMXProxy dmxProxy;

	private Hand right;
	private Hand left;

	public ControllerSliderHand(DMXProxy dmxProxy ,ArrayList<Integer> canal, Hand right, Hand left){
		for (int i =0;i<canal.size();i++){
			CANAL.addAll(canal);
		}
		this.left = left;
		this.right = right;
		this.dmxProxy = dmxProxy;
	}

	public  void update() {	
		fonction();
	}

	private void fonction(){
		dmxProxy.set(CANAL.get(0), 255);
	dmxProxy.set(CANAL.get(1), 255);

	dmxProxy.set(CANAL.get(3), 255);
	dmxProxy.set(CANAL.get(4), 255);

	dmxProxy.set(CANAL.get(6), 255);
	dmxProxy.set(CANAL.get(7), 255);

	dmxProxy.set(CANAL.get(9), 255);
	dmxProxy.set(CANAL.get(10), 255);

	dmxProxy.set(CANAL.get(12), 255);
	dmxProxy.set(CANAL.get(13), 255);

	dmxProxy.set(CANAL.get(15), 255);
	dmxProxy.set(CANAL.get(16), 255);

	if (!right.getOpen()){
		dmxProxy.set(CANAL.get(2), (int) ((left.getX()/2000)*50));
		dmxProxy.set(CANAL.get(5), (int) ((left.getX()/2000)*50));
		dmxProxy.set(CANAL.get(8), (int) ((left.getX()/2000)*50));
		dmxProxy.set(CANAL.get(11), (int) ((left.getX()/2000)*50));
		dmxProxy.set(CANAL.get(14), (int) ((left.getX()/2000)*50));
		dmxProxy.set(CANAL.get(17), (int) ((left.getX()/2000)*50));

	}
	else resetNull();
	}

	public void resetNull(){
		dmxProxy.set(34,0);
		dmxProxy.set(35,0);
		dmxProxy.set(36,0);
		dmxProxy.set(37,0);
		dmxProxy.set(38,0);
		dmxProxy.set(39,0);
		dmxProxy.set(40,0);

		dmxProxy.set(50,0);
		dmxProxy.set(51,0);
		dmxProxy.set(52,0);
		dmxProxy.set(53,0);
		dmxProxy.set(54,0);
		dmxProxy.set(55,0);
	}
}
