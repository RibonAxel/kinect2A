package controller;

import java.util.ArrayList;

import dmx.osc.DMXProxy;
import joints.Hand;
import kinectprojet.KinectProjet;

public class ControllerMoveHand implements ControllerInterface{

	private ArrayList<Integer> CANAL = new ArrayList<Integer>();
	private DMXProxy dmxProxy;

	public float xDepart;

	private Hand right;
	private Hand left;

	public ControllerMoveHand(DMXProxy dmxProxy ,ArrayList<Integer> canal, Hand right, Hand left){
		for (int i =0;i<canal.size();i++){
			CANAL.addAll(canal);
		}
		this.left = left;
		this.right = right;
		this.dmxProxy = dmxProxy;
	}

	@Override
	public void update() {
		xDepart = KinectProjet.xDepart;
		fonction();
	}

	private void fonction(){
		dmxProxy.set(CANAL.get(0), 255);
		dmxProxy.set(CANAL.get(1), 255);
		
		dmxProxy.set(CANAL.get(3), 255);
		dmxProxy.set(CANAL.get(4), 255);
		
		dmxProxy.set(CANAL.get(6), 255);
		dmxProxy.set(CANAL.get(7), 255);
		
		dmxProxy.set(CANAL.get(9), 255);
		dmxProxy.set(CANAL.get(10), 255);
		
		dmxProxy.set(CANAL.get(12), 255);
		dmxProxy.set(CANAL.get(13), 255);
		
		dmxProxy.set(CANAL.get(15), 255);
		dmxProxy.set(CANAL.get(16), 255);
		
		System.out.println(xDepart);
		System.out.println(left.getX());
		if (left.getOpen() && right.getOpen()){
			if (Math.abs(xDepart - left.getX()) < 50){
				dmxProxy.set(CANAL.get(2), 50);
				resetNull1();
			}
			else if ((Math.abs(xDepart - left.getX()) > 50) && (Math.abs(xDepart - left.getX()) < 100)){
				dmxProxy.set(CANAL.get(5), 50);
				resetNull2();
			}
			else if ((Math.abs(xDepart - left.getX()) > 100) && (Math.abs(xDepart - left.getX()) < 150)){
				dmxProxy.set(CANAL.get(8), 50);
				resetNull3();
			}
			else if ((Math.abs(xDepart - left.getX()) > 150) && (Math.abs(xDepart - left.getX()) < 200)){
				dmxProxy.set(CANAL.get(11), 50);
				resetNull4();
			}
			else if ((Math.abs(xDepart - left.getX()) > 250) && (Math.abs(xDepart - left.getX()) < 300)){
				dmxProxy.set(CANAL.get(14), 50);
				resetNull5();
			}
			else if (Math.abs(xDepart - left.getX()) > 350){
				dmxProxy.set(CANAL.get(17), 50);
				resetNull6();
			}
			else
				resetNull();
		}
		else 
			resetNull();
	}

	private void resetNull6() {
		dmxProxy.set(CANAL.get(5),0);
		dmxProxy.set(CANAL.get(8),0);
		dmxProxy.set(CANAL.get(11),0);
		dmxProxy.set(CANAL.get(14),0);
		dmxProxy.set(CANAL.get(2),0);
		
	}

	private void resetNull5() {
		dmxProxy.set(CANAL.get(5),0);
		dmxProxy.set(CANAL.get(8),0);
		dmxProxy.set(CANAL.get(11),0);
		dmxProxy.set(CANAL.get(2),0);
		dmxProxy.set(CANAL.get(17),0);
		
	}

	private void resetNull4() {
		dmxProxy.set(CANAL.get(5),0);
		dmxProxy.set(CANAL.get(8),0);
		dmxProxy.set(CANAL.get(2),0);
		dmxProxy.set(CANAL.get(14),0);
		dmxProxy.set(CANAL.get(17),0);
		
	}

	private void resetNull3() {
		dmxProxy.set(CANAL.get(5),0);
		dmxProxy.set(CANAL.get(2),0);
		dmxProxy.set(CANAL.get(11),0);
		dmxProxy.set(CANAL.get(14),0);
		dmxProxy.set(CANAL.get(17),0);
		
	}

	private void resetNull2() {
		dmxProxy.set(CANAL.get(2),0);
		dmxProxy.set(CANAL.get(8),0);
		dmxProxy.set(CANAL.get(11),0);
		dmxProxy.set(CANAL.get(14),0);
		dmxProxy.set(CANAL.get(17),0);
		
	}

	private void resetNull1() {

		dmxProxy.set(CANAL.get(5),0);
		dmxProxy.set(CANAL.get(8),0);
		dmxProxy.set(CANAL.get(11),0);
		dmxProxy.set(CANAL.get(14),0);
		dmxProxy.set(CANAL.get(17),0);
	}

	@Override
	public void resetNull() {
		dmxProxy.set(33,0);
		dmxProxy.set(34,0);
		dmxProxy.set(35,0);
		dmxProxy.set(36,0);
		dmxProxy.set(37,0);
		dmxProxy.set(38,0);
		dmxProxy.set(39,0);
		dmxProxy.set(40,0);

		dmxProxy.set(49,0);
		dmxProxy.set(50,0);
		dmxProxy.set(51,0);
		dmxProxy.set(52,0);
		dmxProxy.set(53,0);
		dmxProxy.set(54,0);
		dmxProxy.set(55,0);
		dmxProxy.set(56,0);
		
		dmxProxy.set(45,0);
		dmxProxy.set(46,0);
		dmxProxy.set(47,0);
		dmxProxy.set(48,0);
		
		dmxProxy.set(65,0);
		dmxProxy.set(66,0);
		dmxProxy.set(67,0);
		dmxProxy.set(68,0);

		dmxProxy.set(69,0);
		dmxProxy.set(70,0);
		dmxProxy.set(71,0);
		dmxProxy.set(72,0);
		
		dmxProxy.set(73,0);
		dmxProxy.set(74,0);
		dmxProxy.set(75,0);
		dmxProxy.set(76,0);
		
		dmxProxy.set(81,0);
		dmxProxy.set(82,0);
		dmxProxy.set(83,0);
		dmxProxy.set(84,0);
		
		dmxProxy.set(61,0);
		dmxProxy.set(62,0);
		dmxProxy.set(63,0);
		dmxProxy.set(64,0);
	}

}
