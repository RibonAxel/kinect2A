package controller;

public interface ControllerInterface {

	public void update();
	public void resetNull();
}
