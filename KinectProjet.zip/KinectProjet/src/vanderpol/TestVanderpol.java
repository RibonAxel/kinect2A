//  TestVanderpol.java
//  Created by Bernard Thirion on 21/03/07.

package vanderpol;

import pi.endpoint.DoubleValueWithPut;
import pi.application.Application;

public class TestVanderpol {
   
   public static void test() {
        DoubleValueWithPut         X = new DoubleValueWithPut(System.out);           
        VanderpolGenerator generator = new VanderpolGenerator(X);
		Application                a = new Application(generator);
        a.start();        
    }
   
}