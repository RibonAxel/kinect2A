//  VanderpolGenerator.java
//  Created by Bernard Thirion on 22/03/07.

package vanderpol;

import pi.endpoint.DoubleEndpoint;
import pi.endpoint.DoubleValue;
import pi.continuous.Integrator;

import pi.executive.Agent;
import pi.executive.SchedulingOrder;

import pi.container.Container;

public class VanderpolGenerator extends Container {

   private Integrator I1, I2;
   private DoubleValue     S;
   private Feedback        A;

   public VanderpolGenerator (DoubleEndpoint X) {
      this (X, 1.0, 2.0, 3.0);
   }
   
   public VanderpolGenerator (DoubleEndpoint X, double w0, double a, double b) {
       S  = new DoubleValue();
       A  = new Feedback  (S, X , w0, a, b);
       I1 = new Integrator(A, S, 0.0);   
       I2 = new Integrator(S, X, 0.01);  
   }

   public int agentCount() { return 2; }
   
   public Agent agent(int index) {
      switch (index) {
         case   0: return I1;
         case   1: return I2;
         default : return null;
      }
   }

}
