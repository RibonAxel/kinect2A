//  Feedback.java
//  Created by Bernard Thirion on 21/03/07.
 
package vanderpol;

import pi.endpoint.DoubleSource;

public class Feedback implements DoubleSource {

   private DoubleSource S, X;
   private double k, b2, a;

   public Feedback(DoubleSource S, DoubleSource X) {
      this (S, X, 1.0, 2.0, 3.0); 
   }

   public Feedback(DoubleSource S, DoubleSource X, double w0, double a, double b) {
      this.S  = S; 
      this.X  = X; 
      this.k  = w0 * w0; 
      this.b2 = b * b;
      this.a  = a;
   }

   public double value() {
      double s  = S.value();
      double x  = X.value();
      double x2 = x * x;
      double r  = -k*x + a*s*(1 - x2 / b2);
      return r;
   }

}
