//  User.java
//  Created by Bernard Thirion on Fri May 21 2004.

package user;

import java.io.PrintStream;

import pi.executive.DefaultDiscreteAgent;
import pi.executive.State;
import pi.io.IOEvent;

public class User extends DefaultDiscreteAgent {

   private PrintStream out;
   private GUI         gui;
   
   private class UserState extends State { }
 
   public UserAction  on, off, resume, accelerate, brake, engineOn, engineOff;
   
   public User (GUI gui, PrintStream out) {
      this.out = out;
      this.gui = gui;
      UserState state = new UserState();
      on              = new UserAction (this, gui.on,         state, state, "on" ); 
      off             = new UserAction (this, gui.off,        state, state, "off"); 
      resume          = new UserAction (this, gui.resume,     state, state, "resume"); 
      accelerate      = new UserAction (this, gui.accelerate, state, state, "accelerate"); 
      brake           = new UserAction (this, gui.brake,      state, state, "brake"); 
      engineOn        = new UserAction (this, gui.engineOn,   state, state, "engineOn"); 
      engineOff       = new UserAction (this, gui.engineOff,  state, state, "engineOff"); 
      this.adapt(state);
   }
   
   public PrintStream out() { return this.out; }
   
}
