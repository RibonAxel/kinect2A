//  GUI.java
//  Created by Bernard Thirion on 20/03/07.

package user;

import java.awt.Frame;
import java.awt.Button;
import java.awt.event.*;
import java.awt.CheckboxGroup;
import java.awt.Checkbox;
import pi.executive.Executive;
import pi.io.IOEvent;

public class GUI extends Frame {

   public IOEvent on         = new IOEvent();
   public IOEvent off        = new IOEvent();
   public IOEvent resume     = new IOEvent();
   public IOEvent accelerate = new IOEvent();
   public IOEvent brake      = new IOEvent();
   public IOEvent engineOn   = new IOEvent();
   public IOEvent engineOff  = new IOEvent();

   private static final int width  = 500;
   private static final int height = 150;

   private boolean engineIsOn = false;

   private Button onButton, offButton, resumeButton, accelerateButton, brakeButton;
   private Checkbox engineOnBox, engineOffBox;
   private ButtonListener buttonListener = new ButtonListener();
 
   public GUI() {
      setTitle ("Cruise Controller");
      setLayout(null);
      setSize  (width, height);
      addControllerButtons();
      addEngineButtons    ();
      addPedalButtons     ();
      addQuitButton       ();
      this.setVisible(true);
   }
      
   private void addQuitButton () {
      Button B = new Button ();
      B.setLabel ("done");
      B.setBounds(450,100,40,23);
      B.addActionListener(new Quit());
      add(B); 	
   }

   private class Quit implements ActionListener {
      public void actionPerformed (ActionEvent e) {
         System.exit(0);
      }          
   }
   
   private void addControllerButtons () {
      onButton = new Button ();
      onButton.setLabel("on");
      onButton.setBounds(20,100,40,23);
      onButton.addMouseListener(buttonListener);
      add(onButton); 	
      offButton = new Button ();
      offButton.setLabel("off");
      offButton.setBounds(70,100,40,23);
      offButton.addMouseListener(buttonListener);
      add(offButton); 	
      resumeButton = new Button ();
      resumeButton.setLabel("resume");
      resumeButton.setBounds(120,100,60,23);
      resumeButton.addMouseListener(buttonListener);
      add(resumeButton); 	
   }
   
   private void addPedalButtons () {
      accelerateButton = new Button ();
      accelerateButton.setLabel ("accelerate");
      accelerateButton.setBounds(200,100,80,23);
      accelerateButton.addMouseListener(buttonListener);
      add(accelerateButton); 	
      brakeButton = new Button ();
      brakeButton.setLabel ("brake");
      brakeButton.setBounds(280,100,80,23);
      brakeButton.addMouseListener(buttonListener);
      add(brakeButton); 	
   }
   
   private void addEngineButtons () {
      CheckboxGroup buttons = new CheckboxGroup();
      ItemListener listener = new EngineListener();
      engineOnBox = new Checkbox("on", buttons, false);
      engineOnBox.setBounds(60,40,40,23);
      engineOnBox.addItemListener(listener);
      add(engineOnBox); 
      engineOffBox = new Checkbox("off", buttons, true);
      engineOffBox.setBounds(60,60,40,23);
      engineOffBox.addItemListener(listener);
      add(engineOffBox); 
   }
   
   private class ButtonListener extends MouseAdapter  {
      public void mousePressed (MouseEvent e) {
         if (e.getSource() == onButton        ) on.present();
	   	 if (e.getSource() == offButton       ) off.present();
	   	 if (e.getSource() == resumeButton    ) resume.present();
	   	 if (e.getSource() == accelerateButton) accelerate.present();
	   	 if (e.getSource() == brakeButton     ) brake.present();
      }    
            
      public void mouseReleased (MouseEvent e) {
         if (e.getSource() == onButton        ) on.absent();
	   	 if (e.getSource() == offButton       ) off.absent();
	   	 if (e.getSource() == resumeButton    ) resume.absent();
	   	 if (e.getSource() == accelerateButton) accelerate.absent();
	   	 if (e.getSource() == brakeButton     ) brake.absent();
      }                  
   }
   
   private class EngineListener implements ItemListener {
      public void itemStateChanged (ItemEvent e) { 
      
         if (!engineIsOn &&(e.getSource() == engineOnBox)) {
            engineOff.absent();
            engineOn.present();
            engineIsOn = true;
         }
         
         if (engineIsOn && (e.getSource() == engineOffBox)) {
             engineOn.absent();
             engineOff.present();
             engineIsOn = false;                    
         }
          
      }  
   }
           
}

