//  UserAction.java
//
//  Created by Bernard Thirion on Fri May 21 2004.

package user;

import pi.executive.DefaultDiscreteAgent;
import pi.executive.State;
import pi.io.InputAction;
import pi.io.IOEvent;

public class UserAction extends InputAction {
   User   context;
   State  then;
   String name;
      
   public UserAction (User context, IOEvent event, State from, State then, String name) {
      super(event, from);
      this.context = context;
      this.then    = then;
      this.name    = name;
   }
   
   public DefaultDiscreteAgent context() { return context;          }
   public State then()                   { return then;             }
      
   public void jump()                    { context.out().println (name); }

}
