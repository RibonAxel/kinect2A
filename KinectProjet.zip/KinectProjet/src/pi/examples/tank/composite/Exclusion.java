/*
 * Created on 15 avr. 2003
 *
 */

package pi.examples.tank.composite;

import pi.executive.Action;
import pi.executive.DefaultDiscreteAgent;
import pi.executive.DiscreteAction;
import pi.executive.State;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Exclusion extends DefaultDiscreteAgent {
	public final Action actionFill, actionEndFill, actionRack, actionEndRack;

	/**
	 * 
	 */

	public Exclusion() {
		super();
		Rest rest = new Rest();
		Filling filling = new Filling();
		Racking racking = new Racking();
		actionFill = new ActionFill(rest, filling);
		actionEndFill = new ActionEndFill(filling, rest);
		actionRack = new ActionRack(rest, racking);
		actionEndRack = new ActionEndRack(racking, rest);
		adapt(rest);
	}

	private class Rest extends State {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
		}

	}

	private class Filling extends State {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
		}

	}

	private class Racking extends State {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
		}

	}

	private class ActionFill extends DiscreteAction {
		private Filling then;

		ActionFill(Rest from, Filling then) {
			super(from);
			this.then = then;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultDiscreteAgent context() {
			return Exclusion.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public State then() {
			return then;
		}

	}

	private class ActionEndFill extends DiscreteAction {
		private Rest then;

		ActionEndFill(Filling from, Rest then) {
			super(from);
			this.then = then;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultDiscreteAgent context() {
			return Exclusion.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public State then() {
			return then;
		}

	}

	private class ActionRack extends DiscreteAction {
		private Racking then;

		ActionRack(Rest from, Racking then) {
			super(from);
			this.then = then;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultDiscreteAgent context() {
			return Exclusion.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public State then() {
			return then;
		}

	}

	private class ActionEndRack extends DiscreteAction {
		private Rest then;

		ActionEndRack(Racking from, Rest then) {
			super(from);
			this.then = then;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultDiscreteAgent context() {
			return Exclusion.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public State then() {
			return then;
		}

	}
}
