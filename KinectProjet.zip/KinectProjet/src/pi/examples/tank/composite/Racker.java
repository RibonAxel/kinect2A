/*
 * Created on 15 avr. 2003
 *
 */

package pi.examples.tank.composite;

import pi.executive.Action;
import pi.executive.Activity;
import pi.executive.DefaultHybridAgent;
import pi.executive.HybridAction;
import pi.examples.tank.DoubleTerminal;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Racker extends DefaultHybridAgent {
	public final DoubleTerminal Vspec, ds, V, nextV;
	public final Action actionRack, actionEndRack;

	/**
	 * 
	 */

	public Racker(
		DoubleTerminal Vspec,
		DoubleTerminal ds,
		DoubleTerminal V,
		DoubleTerminal nextV,
		String name) {
		super();
		this.Vspec = Vspec;
		this.ds = ds;
		this.V = V;
		this.nextV = nextV;
		Rest rest = new Rest();
		Racking racking = new Racking();
		actionRack = new ActionRack(rest, racking, name + ".rack");
		actionEndRack = new ActionEndRack(racking, rest, name + ".endrack");
		adapt(rest);
	}

	private class Rest extends Activity {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
			V.value = nextV.value;
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
			nextV.value = V.value;
		}

	}

	private class Racking extends Activity {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
			V.value = nextV.value;
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
			nextV.value = V.value - ds.value * dt;
		}

	}

	private class ActionRack extends HybridAction {
		private Racking then;
		private String name;

		ActionRack(Rest from, Racking then, String name) {
			super(from);
			this.then = then;
			this.name = name;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultHybridAgent context() {
			return Racker.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public Activity then() {
			return then;
		}

		/**
		 * @see java.lang.Object#toString()
		 */
		public String toString() {
			return name;
		}

	}

	private class ActionEndRack extends HybridAction {
		private Rest then;
		private String name;

		ActionEndRack(Racking from, Rest then, String name) {
			super(from);
			this.then = then;
			this.name = name;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultHybridAgent context() {
			return Racker.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public Activity then() {
			return then;
		}

		/**
		 * @see java.lang.Object#toString()
		 */
		public String toString() {
			return name;
		}

	}
}
