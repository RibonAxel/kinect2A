/*
 * Created on 15 avr. 2003
 *
 */

package pi.examples.tank.composite;

import pi.executive.Fireable;
import pi.executive.interaction.RendezVous;
import pi.examples.tank.DoubleTerminal;
import pi.examples.tank.TankInterface;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class CompositeTank implements TankInterface {
	public final Filler filler;
	public final Racker racker;
	public final Exclusion exclusion;
	public final DoubleTerminal Vspec;
	public final Fireable a, b, c, e;
	private final DoubleTerminal V, nextV;

	/**
	 * 
	 */

	public CompositeTank(
		Filler filler,
		Racker racker,
		Exclusion exclusion,
		DoubleTerminal V,
		DoubleTerminal nextV,
		String name) {
		super();
		this.filler = filler;
		this.racker = racker;
		this.exclusion = exclusion;
		this.Vspec = filler.Vspec;
		this.V = V;
		this.nextV = nextV;
		// Create interactions
		a =
			new RendezVous(
				new Fireable[] { filler.actionFill, exclusion.actionFill });
		b =
			new RendezVous(
				new Fireable[] {
					filler.actionEndFill,
					exclusion.actionEndFill });
		c =
			new RendezVous(
				new Fireable[] { racker.actionRack, exclusion.actionRack });
		e =
			new RendezVous(
				new Fireable[] {
					racker.actionEndRack,
					exclusion.actionEndRack });
	}

	/**
	 * @see examples.tank.TankInterface#V()
	 */

	public double V() {
		return V.value;
	}

	/**
	 * @see examples.tank.TankInterface#Vspec()
	 */

	public double Vspec() {
		return Vspec.value;
	}

}
