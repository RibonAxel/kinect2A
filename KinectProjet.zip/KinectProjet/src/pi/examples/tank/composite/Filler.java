/*
 * Created on 15 avr. 2003
 *
 */

package pi.examples.tank.composite;

import pi.executive.Action;
import pi.executive.Activity;
import pi.executive.DefaultHybridAgent;
import pi.executive.HybridAction;
import pi.examples.tank.DoubleTerminal;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Filler extends DefaultHybridAgent {
	public final DoubleTerminal Vspec, de, V, nextV;
	public final Action actionFill, actionEndFill;

	/**
	 * 
	 */

	public Filler(
		DoubleTerminal Vspec,
		DoubleTerminal de,
		DoubleTerminal V,
		DoubleTerminal nextV,
		String name) {
		super();
		this.Vspec = Vspec;
		this.de = de;
		this.V = V;
		this.nextV = nextV;
		Rest rest = new Rest();
		Filling filling = new Filling();
		actionFill = new ActionFill(rest, filling, name + ".fill");
		actionEndFill = new ActionEndFill(filling, rest, name + ".endfill");
		adapt(rest);
	}

	private class Rest extends Activity {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
			V.value = nextV.value;
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
			nextV.value = V.value;
		}

	}

	private class Filling extends Activity {

		/**
		 * @see pi.executive.Activity#control()
		 */

		public void control() {
			V.value = nextV.value;
		}

		/**
		 * @see pi.executive.Activity#delta(double)
		 */

		public void delta(double dt) {
			nextV.value = V.value + de.value * dt;
		}

	}

	private class ActionFill extends HybridAction {
		private Filling then;
		private String name;

		ActionFill(Rest from, Filling then, String name) {
			super(from);
			this.then = then;
			this.name = name;
		}

		/**
		 * @see pi.executive.Action#context()
		 */

		public DefaultHybridAgent context() {
			return Filler.this;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public Activity then() {
			return then;
		}

		/**
		 * @see java.lang.Object#toString()
		 */
		public String toString() {
			return name;
		}

	}

	private class ActionEndFill extends HybridAction {
		private Rest then;
		private String name;

		ActionEndFill(Filling from, Rest then, String name) {
			super(from);
			this.then = then;
			this.name = name;
		}

		/**
		* @see pi.executive.Action#context()
		*/

		public DefaultHybridAgent context() {
			return Filler.this;
		}

		/**
		 * @see pi.executive.Fireable#isEnabled()
		 */

		public boolean isEnabled() {
			return nextV.value >= Vspec.value;
		}

		/**
		 * @see pi.executive.Action#then()
		 */

		public Activity then() {
			return then;
		}

		/**
		 * @see java.lang.Object#toString()
		 */
		public String toString() {
			return name;
		}

	}
}
