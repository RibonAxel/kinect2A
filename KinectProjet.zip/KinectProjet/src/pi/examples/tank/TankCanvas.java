/*
 * Created on 2 avr. 2003
 *
 */

package pi.examples.tank;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class TankCanvas extends Canvas {
	private Image offscreenImage = null;
	private TankInterface t1, t2;
	private double VMax1, VMax2;
	private int width = 240;
	private int height = 320;

	/**
	 * 
	 */
	public TankCanvas(TankInterface t1, double VMax1, TankInterface t2, double VMax2) {
		super();
		this.setSize(width, height);
		this.t1 = t1;
		this.t2 = t2;
		this.VMax1 = VMax1;
		this.VMax2 = VMax2;
	}

	public void draw(Graphics graphics) {
		graphics.setColor(Color.white);
		graphics.fillRect(0, 0, width, height);
		int w = (width - 40) / 2;
		int h = (height - 40) / 2;
		// Tank 1
		graphics.setColor(Color.black);
		graphics.drawPolyline(
			new int[] { 10, 10, 10 + w, 10 + w },
			new int[] { 10, 10 + h, 10 + h, 10 },
			4);
		graphics.setColor(Color.green);
		int s = h - (int) (t1.V() * h / VMax1);
		graphics.fillRect(11, 10 + s, w - 1, h - s);
		graphics.setColor(Color.red);
		s = h - (int) (t1.Vspec() * h / VMax1);
		graphics.drawLine(11, 10 + s, 9 + w, 10 + s);
		// Tank 2
		graphics.setColor(Color.black);
		graphics.drawPolyline(
			new int[] { 30 + w, 30 + w, 30 + w + w, 30 + w + w },
			new int[] { 30 + h, 30 + h + h, 30 + h + h, 30 + h },
			4);
		graphics.setColor(Color.green);
		s = h - (int) (t2.V() * h / VMax2);
		graphics.fillRect(31 + w, 30 + h + s, w - 1, h - s);
		graphics.setColor(Color.red);
		s = h - (int) (t2.Vspec() * h / VMax2);
		graphics.drawLine(31 + w, 30 + h + s, 29 + w + w, 30 + h + s);
	}

	/**
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics graphics) {
		if (offscreenImage == null || width != getWidth() || height != getHeight()) {
			width = getWidth();
			height = getHeight();
			offscreenImage = createImage(width, height);
		}
		Graphics image = offscreenImage.getGraphics();
		draw(image);
		graphics.drawImage(offscreenImage, 0, 0, this);
	}

	/**
	 * @see java.awt.Component#update(java.awt.Graphics)
	 */
	public void update(Graphics graphics) {
		paint(graphics);
	}

}
