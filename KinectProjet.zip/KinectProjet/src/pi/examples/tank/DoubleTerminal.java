/*
 * Created on 2 avr. 2003
 *
 */

package pi.examples.tank;

import pi.executive.Terminal;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class DoubleTerminal implements Terminal {
	public double value;

	public DoubleTerminal() {
	}

	public DoubleTerminal(double value) {
		this.value = value;
	}

}
