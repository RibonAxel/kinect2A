/*
 * Created on 2 avr. 2003
 *
 */

package pi.examples.tank.receipt;

import pi.executive.State;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class ReceiptStateEnd extends State {
	private Receipt context;

	/**
	 * 
	 */
	public ReceiptStateEnd(Receipt context) {
		super();
		this.context = context;
	}

}
