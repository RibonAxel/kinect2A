/*
 * Created on 2 avr. 2003
 *
 */

package pi.examples.tank.receipt;

import pi.executive.State;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class ReceiptStateStart extends State {
	private Receipt context;

	/**
	 * 
	 */
	public ReceiptStateStart(Receipt context) {
		super();
		this.context = context;
	}

}
