/*
 * Created on 2 avr. 2003
 *
 */
 
package pi.examples.tank.receipt;

import pi.examples.tank.DoubleTerminal;
import pi.executive.DefaultDiscreteAgent;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class Receipt extends DefaultDiscreteAgent {
	protected DoubleTerminal Vspec, d;
	public final Action_f f;
	public final Action_g g;
	
	/**
	 * 
	 */
	
	public Receipt(DoubleTerminal Vspec, DoubleTerminal d, String name) {
		this.Vspec = Vspec;
		this.d = d;
		// Create activities
		ReceiptStateStart start = new ReceiptStateStart(this);
		ReceiptStateTransfert transfert = new ReceiptStateTransfert(this);
		ReceiptStateEnd end = new ReceiptStateEnd(this);
		// Create actions
		f = new Action_f(this, start, transfert, name + ".f");
		g = new Action_g(this, transfert, end, name + ".g");
		// Set initial activity
		this.adapt(start);
	}

}
