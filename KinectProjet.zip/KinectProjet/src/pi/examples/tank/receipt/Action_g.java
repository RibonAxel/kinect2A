/*
 * Created on 2 avr. 2003
 *
 */

package pi.examples.tank.receipt;

import pi.executive.DefaultDiscreteAgent;
import pi.executive.DiscreteAction;
import pi.executive.State;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class Action_g extends DiscreteAction {
	private Receipt context;
	private ReceiptStateEnd then;
	private String name;

	/**
	 * @param from
	 */
	public Action_g(
		Receipt context,
		ReceiptStateTransfert from,
		ReceiptStateEnd then,
		String name) {
		super(from);
		this.context = context;
		this.then = then;
		this.name = name;
	}

	/**
	 * @see pi.executive.Action#context()
	 */
	public DefaultDiscreteAgent context() {
		return context;
	}

	/**
	 * @see pi.executive.Action#then()
	 */
	public State then() {
		return then;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */
	public void fire() {
		super.fire();
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return name;
	}

}
