/*
 * Created on 2 avr. 2003
 *
 */

package pi.examples.tank;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.Timer;
import javax.swing.WindowConstants;

import pi.examples.tank.composite.CompositeTank;
import pi.examples.tank.composite.Exclusion;
import pi.examples.tank.composite.Filler;
import pi.examples.tank.composite.Racker;
import pi.examples.tank.receipt.Receipt;
import pi.examples.tank.tank.Tank;

import pi.executive.Action;
import pi.executive.Executive;
import pi.executive.Fireable;
import pi.executive.interaction.RendezVous;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class TankWindow extends JFrame {
	private Executive executive;
	private TankInterface t1, t2;
	private Receipt receipt;
	private double Vmax1, Vmax2;
	private DoubleTerminal Vspec1, de1, ds1, Vspec2, de2, ds2, Vspec, d;
	private TankCanvas tankCanvas;
	private Panel infoPanel;
	private JTextArea text;

	public TankWindow() {
		super("Tank");
		executive = new Executive();
		createSimpleAgents();
		//createCompositeAgents();
		this.setBounds(40, 40, 480, 320);
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		tankCanvas = new TankCanvas(t1, Vmax1, t2, Vmax2);
		this.getContentPane().add(tankCanvas, BorderLayout.CENTER);
		createInfoPanel();
		this.getContentPane().add(infoPanel, BorderLayout.EAST);
		this.setVisible(true);
		this.pack();
		executive.start();
		new Timer(500, taskPerformer).start();
	}

	private void createSimpleAgents() {
		// Shared variables
		Vmax1 = 100;
		Vspec1 = new DoubleTerminal(80);
		de1 = new DoubleTerminal(5);
		ds1 = new DoubleTerminal(4);
		Vmax2 = 100;
		Vspec2 = new DoubleTerminal(70);
		de2 = ds1;
		ds2 = new DoubleTerminal(10);
		Vspec = Vspec2;
		d = ds1;
		// Agents
		Tank tt1 = new Tank(Vspec1, de1, ds1, Vspec1.value, "tank1");
		t1 = tt1;
		executive.plugAgent(tt1);
		Tank tt2 = new Tank(Vspec2, de2, ds2, 0.0, "tank2");
		t2 = tt2;
		executive.plugAgent(tt2);
		receipt = new Receipt(Vspec, d, "receipt");
		executive.plugAgent(receipt);
		// Interactions
		RendezVous r1 = new RendezVous(new Action[] { receipt.f, tt1.c, tt2.a });
		RendezVous r2 = new RendezVous(new Action[] { receipt.g, tt1.e, tt2.b });
	}

	private void createCompositeAgents() {
		// Shared variables
		Vmax1 = 100;
		Vspec1 = new DoubleTerminal(80);
		de1 = new DoubleTerminal(5);
		ds1 = new DoubleTerminal(4);
		Vmax2 = 100;
		Vspec2 = new DoubleTerminal(70);
		de2 = ds1;
		ds2 = new DoubleTerminal(10);
		Vspec = Vspec2;
		d = ds1;
		DoubleTerminal V = new DoubleTerminal(Vspec1.value);
		DoubleTerminal nextV = new DoubleTerminal(Vspec1.value);
		// Agents
		// Create involved agents
		Filler filler = new Filler(Vspec1, de1, V, nextV, "tank1");
		Racker racker = new Racker(Vspec1, ds1, V, nextV, "tank1");
		Exclusion exclusion = new Exclusion();
		CompositeTank tt1 = new CompositeTank(filler, racker, exclusion, V, nextV, "tank1");
		t1 = tt1;
		executive.plugAgent(filler);
		executive.plugAgent(racker);
		executive.plugAgent(exclusion);
		Tank tt2 = new Tank(Vspec2, de2, ds2, 0.0, "tank2");
		t2 = tt2;
		executive.plugAgent(tt2);
		receipt = new Receipt(Vspec, d, "receipt");
		executive.plugAgent(receipt);
		// Interactions
		RendezVous r1 = new RendezVous(new Fireable[] { receipt.f, tt1.c, tt2.a });
		RendezVous r2 = new RendezVous(new Fireable[] { receipt.g, tt1.e, tt2.b });
	}

	private void createInfoPanel() {
		infoPanel = new Panel();
		text = new JTextArea();
		text.setPreferredSize(new Dimension(240, 320));
		infoPanel.add(text, BorderLayout.CENTER);
	}

	private void displayInfos() {
		String s =
			"Vspec1 = "
				+ Vspec1.value
				+ "\nde1 = "
				+ de1.value
				+ "\nds1 = "
				+ ds1.value
				+ "\nV1 = "
				+ t1.V();
		s += "\nVspec2 = "
			+ Vspec2.value
			+ "\nde2 = "
			+ de2.value
			+ "\nds2 = "
			+ ds2.value
			+ "\nV2 = "
			+ t2.V();
		s += "\nVspec = " + Vspec.value + "\nd = " + d.value;
		text.setText(s);
		tankCanvas.repaint();
	}

	ActionListener taskPerformer = new ActionListener() {
		public void actionPerformed(ActionEvent evt) {
			displayInfos();
		}
	};

}
