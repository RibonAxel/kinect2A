package pi.examples.tank;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class TankMain {

	/**
	 * 
	 */
	public TankMain() {
		super();
	}

	public static void main(String[] args) {
		TankWindow tankWindow = new TankWindow();
		tankWindow.show();
	}
}
