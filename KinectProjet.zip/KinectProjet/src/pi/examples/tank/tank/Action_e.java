/*
 * Created on 1 avr. 2003
 *
 */

package pi.examples.tank.tank;

import pi.executive.Activity;
import pi.executive.DefaultHybridAgent;
import pi.executive.HybridAction;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Action_e extends HybridAction {
	private Tank context;
	private Rest then;
	private String name;

	/**
	 * @param context
	 * @param then
	 */

	public Action_e(Tank context, Racking from, Rest then, String name) {
		super(from);
		this.context = context;
		this.then = then;
		this.name = name;
	}

	/**
	 * @see pi.executive.meta.Action#context()
	 */

	public DefaultHybridAgent context() {
		return context;
	}

	/**
	 * @see pi.executive.meta.Action#then()
	 */

	public Activity then() {
		return then;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */
	public void fire() {
		super.fire();
	}

	/**
	 * @see pi.executive.Action#isEnabled()
	 */
	/*public boolean isEnabled() {
		return context.nextV <= 0.0;
	}*/

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return name;
	}

}
