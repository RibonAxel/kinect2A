/*
 * Created on 1 avr. 2003
 *
 */

package pi.examples.tank.tank;

import pi.executive.Activity;
import pi.executive.DefaultHybridAgent;
import pi.executive.HybridAction;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Action_b extends HybridAction {
	private Tank context;
	private Rest then;
	private String name;

	/**
	 * @param context
	 * @param then
	 */

	public Action_b(Tank context, Filling from, Rest then, String name) {
		super(from);
		this.context = context;
		this.then = then;
		this.name = name;
	}

	/**
	 * Evaluate action's guard
	 * @return guard evaluation
	 */

	public boolean isEnabled() {
		return context.nextV >= context.Vspec.value;
	}

	/**
	 * @see pi.executive.Action#context()
	 */

	public DefaultHybridAgent context() {
		return context;
	}

	/**
	 * @see pi.executive.Action#then()
	 */

	public Activity then() {
		return then;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */
	public void fire() {
		super.fire();
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return name;
	}

}
