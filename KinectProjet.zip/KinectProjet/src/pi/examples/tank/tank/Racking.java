/*
 * Created on 1 avr. 2003
 *
 */
 
package pi.examples.tank.tank;

import pi.executive.Activity;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Racking extends Activity {
	private Tank context;

	/**
	 * 
	 */

	public Racking(Tank context) {
		super();
		this.context = context;
	}

	/**
	 * @see pi.executive.Activity#control()
	 */

	public void control() {
		context.V = context.nextV;
	}

	/**
	 * @see pi.executive.Activity#delta(double)
	 */

	public void delta(double dt) {
		context.nextV = context.V - context.ds.value * dt;
	}

}
