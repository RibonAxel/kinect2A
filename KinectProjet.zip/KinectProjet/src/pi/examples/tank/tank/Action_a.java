/*
 * Created on 1 avr. 2003
 *
 */

package pi.examples.tank.tank;

import pi.executive.Activity;
import pi.executive.DefaultHybridAgent;
import pi.executive.HybridAction;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Action_a extends HybridAction {
	private Tank context;
	private Filling then;
	private String name;

	public Action_a(Tank context, Rest from, Filling then, String name) {
		super(from);
		this.context = context;
		this.then = then;
		this.name = name;
	}

	/**
	 * @see pi.executive.Action#context()
	 */

	public DefaultHybridAgent context() {
		return context;
	}

	/**
	 * @see pi.executive.Action#then()
	 */

	public Activity then() {
		return then;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */
	public void fire() {
		super.fire();
	}

	/**
	 * @see pi.executive.Action#isEnabled()
	 */
	/*public boolean isEnabled() {
		return context.nextV < context.Vspec.value;
	}*/

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return name;
	}

}
