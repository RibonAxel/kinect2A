package pi.examples.tank.tank;

import pi.examples.tank.DoubleTerminal;
import pi.examples.tank.TankInterface;
import pi.executive.DefaultHybridAgent;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Tank extends DefaultHybridAgent implements TankInterface {
	public final DoubleTerminal Vspec, de, ds;
	protected double V;
	protected double nextV;
	public final Action_a a;
	public final Action_b b;
	public final Action_c c;
	public final Action_e e;

	/**
	 * 
	 */

	public Tank(DoubleTerminal Vspec, DoubleTerminal de, DoubleTerminal ds, double initialV, String name) {
		this.Vspec = Vspec;
		this.de = de;
		this.ds = ds;
		this.V = initialV;
		this.nextV = initialV;
		// Create activities
		Rest rest = new Rest(this);
		Filling filling = new Filling(this);
		Racking racking = new Racking(this);
		// Create actions
		a = new Action_a(this, rest, filling, name + ".a");
		b = new Action_b(this, filling, rest, name + ".b");
		c = new Action_c(this, rest, racking, name + ".c");
		e = new Action_e(this, racking, rest, name + ".e");
		// Set initial activity
		this.adapt(rest);
	}

	public double V() {
		return V;
	}
	
	public double Vspec() {
		return Vspec.value;
	}
}
