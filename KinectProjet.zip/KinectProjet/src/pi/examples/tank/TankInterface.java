/*
 * Created on 15 avr. 2003
 *
 */
 
package pi.examples.tank;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public interface TankInterface {

	public double V();
	public double Vspec();
}
