//  Application.java
//  Created by Bernard Thirion on 19/03/07.

package pi.application;

import pi.executive.Agent;
import pi.executive.Constraint;
import pi.executive.Executive;
import pi.container.Container;

public class Application  {
 
   private Executive executive;
   private Container container;
   
   public Application(Container container) {
      this (container, Executive.DEFAULT_PERIOD);
   }
   
   public Application(Container container, double period) {
      this (container, period, Executive.SAFE_DELAY);
   }
   
   public Application(Container container, double period, double safeDelay) {
      this.container = container;
      this.executive = new Executive(period, safeDelay);
      this.registerAgents();
      this.solveConstraints();
   }
   
   private void registerAgents() {
      for (int i = 0; i < container.agentCount(); i++) {
        Agent a = container.agent(i);
        executive.plugAgent(a);
      }
   }
   
   private void solveConstraints() {
      for (int i = 0; i < container.constraintCount(); i++) {
        Constraint c = container.constraint(i);
        executive.addConstraint(c);
      }
   }
   
   public void start() {
      executive.start();
   }

}
