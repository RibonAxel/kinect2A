package pi.endpoint;

public class AdaptaterInverserDoubleValue extends DoubleValue {

	DoubleValue source;
	
	public AdaptaterInverserDoubleValue(DoubleValue source){
		this.source = source;
	}
	
	@Override
	public double value(){
		return this.source.value;
	}
	
	@Override
	public void value(double value){
		this.source.value(1-value);
	}
}
