//  Created by BB on 06 05 11.


package pi.endpoint;

public class DMXValue implements DMXEndPoint{
	protected int value;

	public DMXValue() {
		this(0);
	}
	
	public DMXValue(int value) {
		if(value>0 && value< 255)
			this.value = value;
		else 
			this.value = 255;
	}


	public int value()           
	{ return this.value; }
	
	public void value(int value) 
	{ this.value = value;  }
   
}
