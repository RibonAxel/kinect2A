//  Created by BB on 06 05 11.


package pi.endpoint;

public interface DMXEndPoint extends DMXSource, DMXSink{

}
