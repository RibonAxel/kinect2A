//  Created by BB on 06 05 11.


package pi.endpoint;

public interface DMXSink {
	   public void value(int value);
	}
