//  Created by BB on 11 05 11.


package pi.endpoint;

public class AdaptaterDoubleSourceToDMXSource implements DMXSource{

	DoubleSource source;
	
	public AdaptaterDoubleSourceToDMXSource(DoubleSource source) 
	{
		this.source = source;
	}
	
	@Override
	public int value() {
		return (int)(source.value()* 254);
	}
	
}
