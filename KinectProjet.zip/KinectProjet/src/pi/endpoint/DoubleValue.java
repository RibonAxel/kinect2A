package pi.endpoint;

public class DoubleValue implements DoubleEndpoint {

   protected double value;

   public DoubleValue() {
      this(0.0);
   }
	
   public DoubleValue(double value) {
      this.value = value;
   }


   public double value()
   { return this.value; }
	
   public void value(double value)
   { this.value = value;  }
   
}
