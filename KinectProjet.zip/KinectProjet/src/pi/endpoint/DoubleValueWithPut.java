//  DoubleValueWithPut.java
//  Created by Bernard Thirion on 21/03/07.

package pi.endpoint;

import java.io.PrintStream;

public class DoubleValueWithPut extends DoubleValue {

   private PrintStream out;

   public DoubleValueWithPut(PrintStream out) {
      this(out, 0.0);
   }
	
   public DoubleValueWithPut(PrintStream out, double value) {
      this.out   = out;
      this.value = value;
   }
   
   public void value(double value) { 
      super.value(value);
      out.println(value);
   }   

}
