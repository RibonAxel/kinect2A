package pi.endpoint;

import autoIterator.DropBox;

public class AdaptaterDoubleValueToDropBox extends DropBox {
	
	DoubleValue source;
	
	public AdaptaterDoubleValueToDropBox(DoubleValue source)
	{
		this.source = source;
	}
	
	@Override
	public void setAmplitude(double amplitude){
		this.source.value(amplitude);
	}
	
	@Override
	public double getAmplitude(){
		return this.source.value();
	}

}
