//  Created by BB on 09 05 11.

package pi.endpoint;

import org.omg.CORBA.DoubleSeqHelper;

public class AdaptaterDoubleValueToDMXValue extends DMXValue{

	DoubleValue value;
	
	public AdaptaterDoubleValueToDMXValue(DoubleValue value) 
	{
		this.value = value;
	}
	
	@Override
	public int value() {
		return (int)(value.value()* 254);
	}



}
