package pi.endpoint;

public interface DoubleSink {
   public void value(double value);
}
