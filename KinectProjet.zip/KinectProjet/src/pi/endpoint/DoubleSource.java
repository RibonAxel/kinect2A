package pi.endpoint;

public interface DoubleSource extends Source{
   public double value();
}
