//  DoubleProbe.java
//  Created by Bernard Thirion on 22/03/07.

package pi.endpoint;

public class DoubleProbe implements DoubleSource {

   private double         gain;
   private DoubleSource source;
   
   public DoubleProbe (DoubleSource source) {
      this (source, 1.0);
   }
   
   public DoubleProbe (DoubleSource source, double gain) {
      this.source = source;
      this.gain   = gain;
   }

   public double value() {
      return gain * source.value();   
   }
   
   public void adjust(double gain) { 
      this.gain = gain;
   }

}
