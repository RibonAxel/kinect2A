//  Created by BB on 06 05 11.


package pi.endpoint;

public class DMXProbe implements DMXSource{

	   private double    gain;
	   private DMXSource source;
	   
	   public DMXProbe (DMXSource source) {
	      this (source, 1.0);
	   }
	   
	   public DMXProbe (DMXSource source, double gain) {
	      this.source = source;
	      this.gain   = gain;
	   }

	   public int value() {
		   double v = gain * source.value();
		   return (int)v;   
	   }
	   
	   public void adjust(double gain) { 
	      this.gain = gain;
	   }
}
