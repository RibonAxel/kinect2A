//  DoubleEndpoint.java
//  Created by Bernard Thirion on 22/03/07.

package pi.endpoint;

public interface DoubleEndpoint extends DoubleSource, DoubleSink {

}

