//  Created by BB on 06 05 11.


package pi.endpoint;

public interface DMXSource extends Source{
	   public int value();
}
