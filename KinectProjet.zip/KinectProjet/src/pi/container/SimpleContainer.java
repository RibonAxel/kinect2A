//  SimpleContainer.java
//  Created by Bernard Thirion on 19/03/07.
 
package pi.container;

import pi.executive.Agent;

public class SimpleContainer extends Container {

   private Agent[] agents;

   public SimpleContainer(Agent[] agents) {
      this.agents = agents;
   }
   
   public SimpleContainer(Agent agent) {
      this.agents = new Agent[] { agent };
   }
   
   public int agentCount() { 
      return agents.length; 
   }
   
   public Agent agent(int index) {
      return agents[index];
   }

}
