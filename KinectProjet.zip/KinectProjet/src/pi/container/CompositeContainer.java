//  CompositeContainer.java
//  Created by Bernard Thirion on 23/03/07.

package pi.container;

import pi.executive.Agent;
import pi.executive.Constraint;

public class CompositeContainer extends Container {

   protected Container[] members;
   
   public CompositeContainer() {
      this.members = null;
   }
   
   public void addMember(Container container) {
      this.addMembers(new Container[] { container });
   } 
   
   public void addMembers(Container[] list) {
      Container[] c;
      if (members == null) {
         c = new Container[list.length];
         System.arraycopy(list, 0, c, 0, list.length);
       } else {
         int length = members.length;
         c = new Container[length + list.length];
         System.arraycopy(members, 0, c, 0, length);
         System.arraycopy(list, 0, c, length, list.length);
      }
      members = c;
   } 
   
   public int agentCount() {
      int count = 0;
      for (int i = 0; i < members.length; i++) {
         count = count + members[i].agentCount();
      }
      return count;
   }
   
   public Agent agent(int index) { 
      int m = 0;
      while (index > (members[m].agentCount() - 1)) {
         index = index - members[m].agentCount();
         m     = m + 1;
      }
      return members[m].agent(index);
   }
   
   public int constraintCount() {
      int count = 0;
      for (int i = 0; i < members.length; i++) {
         count = count + members[i].constraintCount();
      }
      return super.constraintCount() + count;
   }
      
   public Constraint constraint(int index) {
      int length = 0;
      if (constraints != null) length = constraints.length;
      if (index < length) 
         return constraints[index];
      else {
         int m = 0; index = index - length;         
         while (index > (members[m].constraintCount() - 1)) {
            index = index - members[m].constraintCount();
            m     = m + 1;
         }
         return members[m].constraint(index);
      }
   }

  
}

