//  Container.java
//  Created by Bernard Thirion on 19/03/07.

package pi.container;

import pi.executive.Constraint;
import pi.executive.Agent;

public abstract class Container {

   protected Constraint[] constraints = null;

   public int agentCount() { 
      return 0; 
   }

   public Agent agent(int index) {  // index ranges over [0..agentCount-1]
      return null;
   }
   
   public void addConstraint(Constraint constraint) {
      this.addConstraints(new Constraint[] { constraint });
   } 
   
   public void addConstraints(Constraint[] list) {
      Constraint[] c;
      if (constraints == null) {
         c = new Constraint[list.length];
         System.arraycopy(list, 0, c, 0, list.length);
       } else {
         int length = constraints.length;
         c = new Constraint[length + list.length];
         System.arraycopy(constraints, 0, c, 0, length);
         System.arraycopy(list, 0, c, length, list.length);
      }
      constraints = c;
   } 
   
   public int constraintCount() {
      if (constraints == null) return 0; else return constraints.length;
   }
   
   public Constraint constraint(int index) {  // index ranges over [0..constraintCount-1]
      return constraints[index];
   }
   
}
