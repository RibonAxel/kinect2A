/*
 * Created on 23 avr. 2003
 *
 */

package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class State {
	protected Action[] actions; // An array is faster than a Set for react

	/**
	 * Constructor
	 */
	
	protected State() {
	}
	
	/**
	 * Do discrete reaction (zero time)
	 * Evaluates the fireability of the actions.
	 * The elected fireable actions will be fired by the kernel.
	 */

	public void react(Executive executive) {
		Action[] a = actions;
		if (a != null) {
			for (int index = a.length - 1; index >= 0; index--) {
				Action action = (Action) a[index];
				action.evaluateFireability(executive);
			}
		}
	}

	/**
	 * Adds an action that starts from the state
	 * @param action
	 */

	protected void addAction(Action action) {
		if (actions == null)
			actions = new Action[] { action };
		else {
			int length = actions.length;
			Action[] a = new Action[length + 1];
			System.arraycopy(actions, 0, a, 0, length);
			a[length] = action;
			actions = a;
		}

	}
}