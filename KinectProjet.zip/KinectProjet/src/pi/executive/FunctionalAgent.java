package pi.executive;

// META: << FAGENT >>
//
// Intended cyclic activity
//
// 	1) control()		influence various terminals 
//							   typically   Yn = g(Xn, Un)

public interface FunctionalAgent extends Agent {

	/**
	 * Influence various terminals 
	 *   typically   Yn = g(Xn, Un)
	 */

	public void control();
}
