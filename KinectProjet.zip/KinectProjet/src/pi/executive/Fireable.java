package pi.executive;

import pi.executive.collections.PoolingHashSet;
import pi.executive.collections.PoolingEnumeration;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public abstract class Fireable {
	protected PoolingHashSet parents;

	/**
	 * Return true is this object can be fired
	 * @return
	 */

	public abstract boolean isEnabled();

	/**
	 * Fire the executable object
	 */

	public abstract void fire();

	/**
	 * Signal that a child of this element is fireable
	 * @param child
	 */

	protected abstract void signalFireable(Executive executive, Fireable child);

	/**
	 * Reset the fireability state of this element
	 */

	public abstract void resetFireability();

	/**
	 * Evaluate if this object is fireable and should call executive.addFireable if true
	 * @param executive
	 */

	public void evaluateFireability(Executive executive) {
		if (isEnabled()) {
			if (parents == null) {
				executive.signalFireable(this);
			} else {
				PoolingEnumeration enumerator = parents.elements();
				while (enumerator.hasMoreElements()) {
					Fireable parent = (Fireable) enumerator.nextElement();
					parent.signalFireable(executive, this);
					parent.evaluateFireability(executive);
				}
				enumerator.release();
			}
		}
	}

	/**
	 * Add a parent
	 * @param parent
	 */

	public void addParent(Fireable parent) {
		if (parents == null)
			parents = new PoolingHashSet();
		else if (parents.contains(parent))
			return;
		parents.add(parent);
	}

	/**
	 * Remove a parent
	 * @param parent
	 */

	public void removeParent(Fireable parent) {
		if (parents != null)
			parents.remove(parent);
	}
}
