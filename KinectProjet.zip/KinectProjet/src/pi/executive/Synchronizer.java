package pi.executive;

import pi.executive.collections.*;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class Synchronizer {
	private PoolingHashSet fireableSet = new PoolingHashSet();
	private PoolingVector fireableVector = new PoolingVector();
	private PoolingHashSet fireableToReset = new PoolingHashSet();
	private DiscreteRandom random = new DiscreteRandom();

	/**
	 * 
	 */

	public Synchronizer() {
		super();
	}

	/**
	 * Start a new react cycle for discrete agents
	 */

	public void startCycle() {
		resetFireable();
	}

	/**
	 * Signal to the synchronizer that a fireable element may be fired
	 * @param fireable
	 */

	public void signalFireable(Fireable fireable) {
		if (!fireableSet.contains(fireable)) {
			fireableSet.add(fireable);
			fireableVector.add(fireable);
			fireableToReset.add(fireable);
		}
	}

	/**
	 * Adds a fireable candidate to the set of elements whose fireable state should be reset
	 * @param fireable
	 */

	protected void addFireableCandidate(Fireable fireable) {
		fireableToReset.add(fireable);
	}

	/**
	 * End a react cycle by firing a fireable object
	 */

	public void endCycle() {
		int size = fireableVector.size();
		if (size > 0) {
			random.setRange(0, size - 1);
			int r = random.next();
			/*System.out.print("<");
			for (int i = 0; i < size; i++) {
				System.out.print(fireableVector.get(i) + " ");
			}
			System.out.println("> " + fireableVector.get(r));*/
			fire((Fireable) fireableVector.get(r));
		}
	}

	/**
	 * Clear fireable candidates
	 */

	private void resetFireable() {
		PoolingEnumeration enumerator = fireableToReset.elements();
		while (enumerator.hasMoreElements()) {
			Fireable fireable = (Fireable) enumerator.nextElement();
			fireable.resetFireability();
		}
		enumerator.release();
		fireableSet.clear();
		fireableVector.clear();
		fireableToReset.clear();
	}

	/**
	 * Fire an enabled synchronization
	 * @param synchronization
	 */

	private void fire(Fireable fireable) {
		fireable.fire();
	}

}
