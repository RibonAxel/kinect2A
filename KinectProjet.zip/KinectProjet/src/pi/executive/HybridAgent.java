package pi.executive;


// Intended cyclic activity
//
// 	1) control()		influence various terminals 
//							   typically   Yn = g(Xn, Un)
//
//    2) evolve (dt)    computes next state
//							   typically Xn+1 = f(Xn, Un)
//	
//		3) react()			do discrete reaction (zero time)
// 
//		repeat 3) until period exhausted 

public interface HybridAgent extends DiscreteAgent, ContinuousAgent {
}
