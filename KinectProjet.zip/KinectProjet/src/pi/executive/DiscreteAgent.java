package pi.executive;


// META: << DAGENT >>
//
// Intended cyclic activity
//
//		react()			do discrete reaction (zero time)
// 

public interface DiscreteAgent extends Agent {

	/**
	 * Do discrete reaction (zero time)
	 */

	public void react(Executive executive);
}
