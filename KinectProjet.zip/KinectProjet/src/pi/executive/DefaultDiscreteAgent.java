package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class DefaultDiscreteAgent implements DiscreteAgent {
	protected State state;

	/**
	 * 
	 */

	public DefaultDiscreteAgent() {
		super();
	}

	/**
	 * @see pi.executive.DiscreteAgent#react()
	 */

	public void react(Executive executive) {
		if (state != null)
			state.react(executive);

	}

	/**
	 * Modify the state of the agent (Pattern State)
	 * @param state The new state of the agent
	 */

	public void adapt(State state) {
		this.state = state;
	}
}
