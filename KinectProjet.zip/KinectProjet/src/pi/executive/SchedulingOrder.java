//  SchedulingOrder.java
//  Created by Bernard Thirion on 04/04/07.

package pi.executive;

public class SchedulingOrder extends Constraint {

   private Agent firstAgent, nextAgent;
   
   public SchedulingOrder(Agent firstAgent, Agent nextAgent) {
      this.firstAgent = firstAgent;
      this.nextAgent  = nextAgent;      
   }
   
   public Agent firstAgent() { return this.firstAgent; }
   public Agent nextAgent () { return this.nextAgent;  }

}
   