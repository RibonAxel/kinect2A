package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class DefaultDiscreteFunctionalAgent
	implements DiscreteFunctionalAgent {
	protected Activity activity;

	/**
	 * 
	 */

	public DefaultDiscreteFunctionalAgent() {
		super();
	}

	/**
	 * @see pi.executive.FunctionalAgent#control()
	 */

	public void control() {
		if (activity != null)
			activity.control();
	}

	/**
	 * @see pi.executive.DiscreteAgent#react(pi.executive.Executive)
	 */

	public void react(Executive executive) {
		if (activity != null)
			activity.react(executive);
	}

	/**
	 * Modify the activity of the agent (Pattern State)
	 * @param activity An activity of the agent
	 */

	public void adapt(Activity activity) {
		this.activity = activity;
	}
}
