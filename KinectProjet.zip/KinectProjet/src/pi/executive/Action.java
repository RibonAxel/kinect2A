package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public abstract class Action extends Fireable {

	/**
	 * Construct an action 
	 * @param from The starting activity
	 */

	public Action(State from) {
		from.addAction(this);
	}

	/**
	 * Evaluate action's guard
	 * @return guard evaluation
	 */

	public abstract boolean isEnabled();

	/**
	 * @see pi.executive.Fireable#fire()
	 */

	public abstract void fire();

	/**
	 * Signal that a child of this element is fireable
	 * @param child
	 */

	protected void signalFireable(Executive executive, Fireable child) {
	}

	/**
	 * @see pi.executive.Fireable#resetFireability()
	 */

	public void resetFireability() {
	}

}
