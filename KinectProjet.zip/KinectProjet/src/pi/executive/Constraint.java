//  Constraint.java
//  Created by Bernard Thirion on 04/04/07.

package pi.executive;

public abstract class Constraint {

}
