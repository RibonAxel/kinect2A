/*
 * Created on 28 avr. 2003
 *
 */
 
package pi.executive.interaction;



/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class DisabledInteraction extends Interaction {

	/**
	 * Constructs an interaction that is always disabled
	 */
	
	public DisabledInteraction() {
		super();
	}

	/**
	 * This interaction is never enabled
	 * @see pi.executive.Fireable#isEnabled()
	 */
	
	public boolean isEnabled() {
		return false;
	}

	/**
	 * This interaction is never fired
	 * @see pi.executive.Fireable#fire()
	 */
	public void fire() {
	}

	/**
	 * @see pi.executive.Fireable#resetFireability()
	 */
	public void resetFireability() {
	}

}
