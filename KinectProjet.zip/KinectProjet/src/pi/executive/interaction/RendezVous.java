/*
 * Created on 2 avr. 2003
 *
 */

package pi.executive.interaction;

import pi.executive.Executive;
import pi.executive.Fireable;
import pi.executive.collections.PoolingEnumeration;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class RendezVous extends Interaction {
	protected int enabledFireables = 0;
	/**
	 * 
	 */

	public RendezVous() {
		super();
	}

	/**
	 * 
	 */

	public RendezVous(Fireable[] fireables) {
		super();
		addFireable(fireables);
	}

	/**
	 * @see pi.executive.Fireable#signalFireable(pi.executive.Fireable)
	 */
	protected void signalFireable(Executive executive, Fireable child) {
		super.signalFireable(executive, child);
		enabledFireables++;
	}

	/**
	 * @see pi.executive.Interaction#isEnabled()
	 */
	public boolean isEnabled() {
		return enabledFireables == children.size();
	}

	/**
	 * @see pi.executive.Fireable#resetFireability()
	 */
	public void resetFireability() {
		enabledFireables = 0;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */
	public void fire() {
		PoolingEnumeration enumerator = children.elements();
		while (enumerator.hasMoreElements()) {
			Fireable fireable = (Fireable) enumerator.nextElement();
			fireable.fire();
		}
		enumerator.release();
	}

}
