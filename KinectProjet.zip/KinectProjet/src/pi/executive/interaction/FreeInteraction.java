/*
 * Created on 28 avr. 2003
 *
 */
 
package pi.executive.interaction;

import pi.executive.Fireable;
import pi.executive.collections.PoolingEnumeration;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class FreeInteraction extends Interaction {

	/**
	 * Constructs an interaction that is always enabled
	 */
	public FreeInteraction() {
		super();
	}

	/**
	 * This interaction is always enabled
	 * @see pi.executive.Fireable#isEnabled()
	 */
	
	public boolean isEnabled() {
		return true;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */
	
	public void fire() {
		PoolingEnumeration enumerator = children.elements();
		while (enumerator.hasMoreElements()) {
			Fireable fireable = (Fireable) enumerator.nextElement();
			fireable.fire();
		}
		enumerator.release();
	}

	/**
	 * @see pi.executive.Fireable#resetFireability()
	 */
	
	public void resetFireability() {
	}

}
