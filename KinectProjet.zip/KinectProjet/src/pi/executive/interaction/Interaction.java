package pi.executive.interaction;

import pi.executive.Executive;
import pi.executive.Fireable;
import pi.executive.collections.PoolingHashSet;
import pi.executive.collections.PoolingEnumeration;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public abstract class Interaction extends Fireable {
	protected PoolingHashSet children;

	/**
	 * 
	 */

	public Interaction() {
		super();
	}

	/**
	 * Add a fireable element that participates in this interaction
	 * @param action
	 */

	public void addFireable(Fireable fireable) {
		addChild(fireable);
	}

	/**
	 * Add fireable elements that participate in this interaction
	 * @param action
	 */

	public void addFireable(Fireable[] fireables) {
		for (int index = 0; index < fireables.length; index++) {
			Fireable fireable = fireables[index];
			addChild(fireable);
		}
	}

	/**
	 * Remove all fireable children
	 */

	public void clear() {
		if (children != null) {
			PoolingEnumeration enumerator = children.elements();
			while (enumerator.hasMoreElements()) {
				Fireable child = (Fireable) enumerator.nextElement();
				child.removeParent(this);
			}
			enumerator.release();
			children.clear();
		}
	}

	/**
	 * @see pi.executive.Fireable#signalFireable(pi.executive.Fireable)
	 */

	protected void signalFireable(Executive executive, Fireable child) {
		executive.addFireableCandidate(this);
	}

	/**
	 * Add a child
	 * @param child
	 */

	protected void addChild(Fireable child) {
		if (children == null)
			children = new PoolingHashSet();
		else if (children.contains(child))
			return;
		children.add(child);
		child.addParent(this);
	}

}
