/*
 * Created on 2 avr. 2003
 *
 */
 
package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public interface Terminal {

}
