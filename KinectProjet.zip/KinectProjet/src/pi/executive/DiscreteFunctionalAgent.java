package pi.executive;



/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

//META: << DFAGENT >>
//
//Intended cyclic activity
//
//  1) control()		influence various terminals 
//							typically   Yn = g(Xn, Un)
//
//	 react()			do discrete reaction (zero time)
// 
//	

public interface DiscreteFunctionalAgent
	extends FunctionalAgent, DiscreteAgent {

}
