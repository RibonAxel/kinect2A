package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public abstract class Activity extends State {

	/**
	 * 
	 */
	public Activity() {
		super();
	}

	/**
	 * Influence various terminals 
	 *   typically   Yn = g(Xn, Un)
	 */

	public abstract void control();

	/**
	 * Computes next state
	 *   typically Xn+1 = f(Xn, Un)
	 * @param dt
	 */

	public abstract void delta(double dt);

}
