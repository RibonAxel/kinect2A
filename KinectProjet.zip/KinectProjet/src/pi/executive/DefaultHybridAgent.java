package pi.executive;


/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class DefaultHybridAgent implements HybridAgent {
	protected Activity activity;

	/**
	 * 
	 */

	public DefaultHybridAgent() {
		super();
	}

	/**
	 * @see pi.executive.DiscreteAgent#react()
	 */

	public void react(Executive executive) {
		if (activity != null)
			activity.react(executive);
	}

	/**
	 * @see pi.executive.ContinuousAgent#delta(double)
	 */

	public void delta(double dt) {
		if (activity != null)
			activity.delta(dt);
	}

	/**
	 * @see pi.executive.FunctionalAgent#control()
	 */

	public void control() {
		if (activity != null)
			activity.control();
	}

	/**
	 * Modify the activity of the agent (Pattern State)
	 * @param activity An activity of the agent
	 */

	public void adapt(Activity activity) {
		this.activity = activity;
	}
}
