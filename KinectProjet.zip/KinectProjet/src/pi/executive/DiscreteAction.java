/*
 * Created on 23 avr. 2003
 *
 */
 
package pi.executive;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public abstract class DiscreteAction extends Action {

	/**
	 * Construct an action 
	 * @param from The starting activity
	 */

	public DiscreteAction(State from) {
		super(from);
	}

	/**
	 * Evaluate action's guard
	 * @return guard evaluation
	 */

	public boolean isEnabled() {
		return true;
	}

	/**
	 * @see pi.executive.Fireable#fire()
	 */

	public void fire() {
		jump();
		context().adapt(then());
	}

	/**
	 * Calculate agent state before entering a new activity
	 */

	public void jump() {
	}

	/**
	 * Return the agent to which this action belongs
	 * @return
	 */

	public abstract DefaultDiscreteAgent context();

	/**
	 * Return the target activity
	 * @return
	 */

	public abstract State then();

}
