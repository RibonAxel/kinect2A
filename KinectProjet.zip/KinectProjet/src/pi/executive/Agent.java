package pi.executive;


/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public interface Agent {
	
}
