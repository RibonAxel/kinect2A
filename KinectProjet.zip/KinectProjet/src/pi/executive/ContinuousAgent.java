package pi.executive;


// META: << CAGENT >>
//
// Intended two phase cyclic activity
//
// 	1) control()		influence various terminals 
//							   typically   Yn = g(Xn, Un)
//
//    2) evolve (dt)    computes next state
//							   typically Xn+1 = f(Xn, Un)
//	

public interface ContinuousAgent extends FunctionalAgent {

	/**
	 * Computes next state
	 *   typically Xn+1 = f(Xn, Un)
	 * @param dt
	 */

	public void delta(double dt);
}
