//META: KERNEL
package pi.executive;
import pi.executive.collections.*;
import pi.executive.collections.DigraphAsLists;
import pi.executive.collections.Vertex;
import pi.executive.collections.Visitor;
import pi.time.DiscreteTime;
import pi.time.DiscreteRealTime;
/**
 * @author Bernard Thirion, Philippe Studer
 * 
 */
 
public class Executive implements Runnable {
	public static final double DEFAULT_PERIOD = 0.020;
	public static final double SAFE_DELAY     = 0.002;
	private volatile boolean alive = false;
	private boolean terminated = false;
	private Synchronizer synchronizer;
	private PoolingVector agents = new PoolingVector(10);
	private PoolingVector functionalAgents = new PoolingVector(10);
	private PoolingVector continuousAgents = new PoolingVector(10);
	private PoolingVector discreteAgents   = new PoolingVector(10);
	private DigraphAsLists dependencies;
	private DiscreteTime clock;
	private DiscreteRealTime realTime;
	private Thread thread = null;
	/**
	 * Constructs executive with a default simulation and real time period 
	 */
	public Executive() {
		this(DEFAULT_PERIOD, SAFE_DELAY);
	}
	/**
	 * Constructs executive with the same simulation and real time period
	 * @param period
	 */
   
	public Executive(double period, double safeDelay) {
 		this(period, period, safeDelay);
	}
	/**
	 * Constructs executive with the given simulation and real time period
	 * @param period
	 */
   public Executive(double period, double realtimeDelta, double safeDelay) {
		synchronizer = new Synchronizer();
		clock    = new DiscreteTime(period);
		realTime = new DiscreteRealTime(realtimeDelta);
		realTime.setSafeDelay(safeDelay);
		dependencies = new DigraphAsLists(10);
	}
	/**
	 * Plugs a new agent into the executive
	 * @param a
	 */
	public void plugAgent(Agent a) {
//       System.out.println ("plugging " + a);
       agents.add(a);
       dependencies.addVertex(agents.size() - 1);
       addAgent(a);
	}

    private void addSchedulingOrder(SchedulingOrder order) {
  	   setDependency(order.nextAgent(), order.firstAgent()); 
    }
	
    public void addConstraint(Constraint c) {
       if (c instanceof SchedulingOrder) 
          addSchedulingOrder ((SchedulingOrder) c);
	}

	/**
	 * @param a
	 */
	
	private void addAgent(Agent a) {
		if (a instanceof FunctionalAgent)
			functionalAgents.add(a);
		if (a instanceof ContinuousAgent)
			continuousAgents.add(a);
		if (a instanceof DiscreteAgent)
			discreteAgents.add(a);
	}
	
	/**
	 * Installs a dependency order between two agents
	 * @param dependentOnAgent1 this agent is dependent on agent1
	 * @param agent1
	 */
	
	public void setDependency(Agent dependentOnAgent1, Agent agent1) {
//        System.out.println (dependentOnAgent1 + " - - - > " + agent1);
		int index1 = agents.indexOf(agent1);
		int index2 = agents.indexOf(dependentOnAgent1);
		if (index1 >= 0 && index2 >= 0) {
			dependencies.addEdge(index2, index1);
			if (dependencies.isCyclic()) {
				dependencies.removeEdge(dependencies.getEdge(index2, index1));
				throw new RuntimeException("Cyclic dependencies");
			}
			sortAgents();
		}
	}
	
	/**
	 * Recreates all agent lists according to their dependencies
	 */
	
	private void sortAgents() {
		functionalAgents.clear();
		continuousAgents.clear();
		discreteAgents.clear();
		dependencies.topologicalOrderTraversal(new Visitor() {
			public void visit(Object obj) {
				int index = ((Vertex) obj).getNumber();
				addAgent((Agent) agents.get(index));
			}
			public boolean isDone() {
				return false;
			}
		});
	}
	
	/**
	 * Sets the estimated maximum duration of a reaction
	 * @param delay duration in seconds
	 */
	public void setSafeDelay(double delay) {
		realTime.setSafeDelay(delay);
	}
	/**
	 * Starts the executive
	 */
	public void start() {
		alive = true;
		thread = new Thread(this);
		thread.start();
	}
	/**
	 * Executive task called by start 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		clock.reset();
		realTime.reset();
		while (alive) {
			this.step();
			clock.next();
			realTime.next();
		}
	}
	/**
	 * Ends the executive
	 */
	public synchronized void shutdown() {
		alive = false;
	}
	/**
	 * Signals to the executive that a fireable element may be fired
	 * @param fireable
	 */
	public void signalFireable(Fireable fireable) {
		synchronizer.signalFireable(fireable);
	}
	
	/**
	 * Adds a fireable candidate to the set of elements whose fireable state should be reset
	 * @param fireable
	 */
	public void addFireableCandidate(Fireable fireable) {
		synchronizer.addFireableCandidate(fireable);
	}
	
	/**
	 * Executes a cycle
	 */
	protected void step() {
		this.control();
		this.delta(clock.delta());
		this.react();
		while (alive && realTime.hasEnoughTime()) {
			this.react(); 
		}
	}
	/**
	 * Control phase of funtional agents
	 */
	protected void control() {
		PoolingEnumeration enumerator = functionalAgents.elements();
		while (enumerator.hasMoreElements()) {
			FunctionalAgent agent = (FunctionalAgent) enumerator.nextElement();
			agent.control();
		}
		enumerator.release();
	}
	/**
	 * Evolution phase for continuous agents
	 * @param dt
	 */
	protected void delta(double dt) {
		PoolingEnumeration enumerator = continuousAgents.elements();
		while (enumerator.hasMoreElements()) {
			ContinuousAgent agent = (ContinuousAgent) enumerator.nextElement();
			agent.delta(dt);
		}
		enumerator.release();
	}
	/**
	 * React phase for discrete agents
	 */
	protected void react() {
		synchronizer.startCycle();
		PoolingEnumeration enumerator = discreteAgents.elements();
		while (enumerator.hasMoreElements()) {
			DiscreteAgent agent = (DiscreteAgent) enumerator.nextElement();
			agent.react(this);
		}
		enumerator.release();
		synchronizer.endCycle();
	}
}
