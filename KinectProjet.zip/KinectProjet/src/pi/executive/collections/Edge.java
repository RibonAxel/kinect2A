package pi.executive.collections;


public interface Edge
    extends Comparable
{

    public abstract Vertex getV0();

    public abstract Vertex getV1();

    public abstract Object getWeight();

    public abstract boolean isDirected();

    public abstract Vertex getMate(Vertex vertex);

}
