package pi.executive.collections;


public class LinkedList
{
    public final class Element
    {

        public Object getDatum()
        {
            return datum;
        }

        public Element getNext()
        {
            return next;
        }

        public void insertAfter(Object obj)
        {
            next = new Element(obj, next);
            if(tail == this)
                tail = next;
        }

        public void insertBefore(Object obj)
        {
            Element element = new Element(obj, this);
            if(this == head)
            {
                head = element;
            } else
            {
                Element element1;
                for(element1 = head; element1 != null && element1.next != this; element1 = element1.next);
                element1.next = element;
            }
        }

        public void extract()
        {
            Element element = null;
            if(head == this)
            {
                head = next;
            } else
            {
                for(element = head; element != null && element.next != this; element = element.next);
                if(element == null)
                    throw new InvalidOperationException();
                element.next = next;
            }
            if(tail == this)
                tail = element;
        }

        Object datum;
        Element next;

        Element(Object obj, Element element)
        {
            datum = obj;
            next = element;
        }
    }


    public LinkedList()
    {
    }

    public void purge()
    {
        head = null;
        tail = null;
    }

    public Element getHead()
    {
        return head;
    }

    public Element getTail()
    {
        return tail;
    }

    public boolean isEmpty()
    {
        return head == null;
    }

    public Object getFirst()
    {
        if(head == null)
            throw new ContainerEmptyException();
        else
            return head.datum;
    }

    public Object getLast()
    {
        if(tail == null)
            throw new ContainerEmptyException();
        else
            return tail.datum;
    }

    public void prepend(Object obj)
    {
        Element element = new Element(obj, head);
        if(head == null)
            tail = element;
        head = element;
    }

    public void append(Object obj)
    {
        Element element = new Element(obj, null);
        if(head == null)
            head = element;
        else
            tail.next = element;
        tail = element;
    }

    public void assign(LinkedList linkedlist)
    {
        if(linkedlist != this)
        {
            purge();
            for(Element element = linkedlist.head; element != null; element = element.next)
                append(element.datum);

        }
    }

    public void extract(Object obj)
    {
        Element element = head;
        Element element1 = null;
        for(; element != null && element.datum != obj; element = element.next)
            element1 = element;

        if(element == null)
            throw new IllegalArgumentException("item not found");
        if(element == head)
            head = element.next;
        else
            element1.next = element.next;
        if(element == tail)
            tail = element1;
    }

    protected Element head;
    protected Element tail;
}
