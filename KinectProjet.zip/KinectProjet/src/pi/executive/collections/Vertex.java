package pi.executive.collections;

import java.util.Enumeration;


public interface Vertex
    extends Comparable
{

    public abstract int getNumber();

    public abstract Object getWeight();

    public abstract Enumeration getIncidentEdges();

    public abstract Enumeration getEmanatingEdges();

    public abstract Enumeration getPredecessors();

    public abstract Enumeration getSuccessors();

}
