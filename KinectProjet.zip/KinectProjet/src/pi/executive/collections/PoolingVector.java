/*
 * Created on 7 avr. 2003
 *
 */

package pi.executive.collections;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class PoolingVector {
	int size;
	Object[] elements;
	Enumeration freeEnumerations;

	/**
	 * Constructs an empty vector so that its internal data array 
	 * has size 10 and its standard capacity increment is zero
	 */

	public PoolingVector() {
		super();
		elements = new Object[10];
	}

	/**
	 * Constructs an empty vector with the specified initial 
	 * capacity and with its capacity increment equal to zero
	 */

	public PoolingVector(int initialCapacity) {
		super();
		elements = new Object[initialCapacity];
	}

	/**
	 * Returns the number of elements in the vector
	 * @return
	 */

	public int size() {
		return size;
	}

	/**
	 * Tests if this vector has no components
	 * @return
	 */
	
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * Tests if the specified object is a component in this vector
	 * @param obj
	 * @return
	 */
	
	public boolean contains(Object obj) {
		return indexOf(obj) >= 0;
	}

	/**
	 * Searches for the first occurence of the given argument,
	 * testing for equality using the equals method
	 * @param obj
	 * @return
	 */
	
	public int indexOf(Object obj) {
		if (obj == null) {
			for (int i = 0; i < size; i++)
				if (elements[i] == null)
					return i;

		} else {
			for (int j = 0; j < size; j++)
				if (obj.equals(elements[j]))
					return j;

		}
		return -1;
	}

	/**
	 * Returns the element at the specified position in this Vector
	 * @param i
	 * @return
	 */
	
	public Object get(int i) {
		return elements[i];
	}

	/**
	 * Replaces the element at the specified position in this Vector 
	 * with the specified element
	 * @param i
	 * @param obj
	 * @return
	 */
	
	public Object set(int i, Object obj) {
		Object old = elements[i];
		elements[i] = obj;
		return old;
	}

	/**
	 * Appends the specified element to the end of this Vector
	 * @param obj
	 * @return
	 */
	
	public boolean add(Object obj) {
		ensureCapacity(size + 1);
		elements[size++] = obj;
		return true;
	}

	/**
	 * Inserts the specified element at the specified position in this Vector
	 * @param i
	 * @param obj
	 */
	
	public void add(int i, Object obj) {
		if (i > size || i < 0) {
			throw new IndexOutOfBoundsException(
				"Index: " + i + ", Size: " + size);
		} else {
			ensureCapacity(size + 1);
			System.arraycopy(elements, i, elements, i + 1, size - i);
			elements[i] = obj;
			size++;
			return;
		}
	}

	/**
	 * Removes the element at the specified position in this Vector
	 * @param i
	 * @return
	 */
	
	public Object remove(int i) {
		Object obj = elements[i];
		int j = size - i - 1;
		if (j > 0)
			System.arraycopy(elements, i + 1, elements, i, j);
		elements[--size] = null;
		return obj;
	}

	/**
	 * Removes all of the elements from this Vector
	 */
	
	public void clear() {
		for (int i = 0; i < size; i++)
			elements[i] = null;

		size = 0;
	}

	/**
	 * Returns an enumeration of the components of this vector
	 * @return
	 */
	
	public PoolingEnumeration elements() {
		return newEnumeration();
	}

	/**
	 * Adapts the size of the vector to the new capacity
	 * @param capacity
	 */
	
	private void ensureCapacity(int capacity) {
		int length = elements.length;
		if (capacity > length) {
			Object oldelements[] = elements;
			int newcapacity = (length * 3) / 2 + 1;
			if (newcapacity < capacity)
				newcapacity = capacity;
			elements = new Object[newcapacity];
			System.arraycopy(oldelements, 0, elements, 0, size);
		}
	}

	/**
	 * Creates a new enumerator from the pool
	 * @return
	 */
	
	private Enumeration newEnumeration() {
		Enumeration e = freeEnumerations;
		if (e != null) {
			freeEnumerations = e.next;
			e.initialize();
		} else
			e = new Enumeration();

		return e;
	}

	/**
	 * Enters an enuerator in the pool
	 * @param e
	 */
	
	private void releaseEnumeration(Enumeration e) {
		e.next = freeEnumerations;
		freeEnumerations = e;
	}

	/**
	 * A vector enumerator
	 * 
	 * @author Bernard Thirion, Philippe Studer
	 *
	 * 
	 */
	
	public class Enumeration implements PoolingEnumeration {
		private Enumeration next;
		private int cursor;

		/**
		 * Constructs a new enumerator
		 */
		
		private Enumeration() {
			initialize();
		}

		/**
		 * @see java.util.Enumeration#hasMoreElements()
		 */

		public final boolean hasMoreElements() {
			return cursor < size;
		}

		/**
		 * @see java.util.Enumeration#nextElement()
		 */

		public final Object nextElement() {
			Object object = null;
			if (cursor < size) {
				object = elements[cursor];
				cursor++;
			}
			return object;
		}

		/**
		 * Indicates that this enumerator is no more used
		 */

		public final void release() {
			releaseEnumeration(this);
		}

		/**
		 * Initializes the enumerator
		 */
		
		private final void initialize() {
			cursor = 0;
		}

	}
}
