package pi.executive.collections;


public class MethodNotImplemented extends RuntimeException
{

    public MethodNotImplemented()
    {
    }

}
