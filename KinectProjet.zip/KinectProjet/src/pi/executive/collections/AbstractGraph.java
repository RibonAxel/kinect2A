package pi.executive.collections;

import java.util.Enumeration;
import java.util.NoSuchElementException;


public abstract class AbstractGraph extends AbstractContainer
    implements Graph
{
    protected static final class Counter
    {

        int value;

        protected Counter()
        {
            value = 0;
        }
    }

    protected final class GraphEdge extends AbstractObject
        implements Edge
    {

        public Vertex getV0()
        {
            return vertex[v0];
        }

        public Vertex getV1()
        {
            return vertex[v1];
        }

        public Object getWeight()
        {
            return weight;
        }

        public Vertex getMate(Vertex vertex1)
        {
            if(vertex1.getNumber() == v0)
                return vertex[v1];
            if(vertex1.getNumber() == v1)
                return vertex[v0];
            else
                throw new IllegalArgumentException("invalid vertex");
        }

        public boolean isDirected()
        {
            return AbstractGraph.this.isDirected();
        }

        protected int compareTo(Comparable comparable)
        {
            throw new MethodNotImplemented();
        }

        public int hashCode()
        {
            int i = v0 * numberOfVertices + v1;
            if(weight != null)
                i += weight.hashCode();
            return i;
        }

        public String toString()
        {
            StringBuffer stringbuffer = new StringBuffer();
            stringbuffer.append("Edge {" + v0);
            if(isDirected())
                stringbuffer.append("->" + v1);
            else
                stringbuffer.append("--" + v1);
            if(weight != null)
                stringbuffer.append(", weight = " + weight);
            stringbuffer.append("}");
            return stringbuffer.toString();
        }

        protected int v0;
        protected int v1;
        protected Object weight;

        public GraphEdge(int i, int j, Object obj)
        {
            v0 = i;
            v1 = j;
            weight = obj;
        }
    }

    protected final class GraphVertex extends AbstractObject
        implements Vertex
    {

        public int getNumber()
        {
            return number;
        }

        public Object getWeight()
        {
            return weight;
        }

        protected int compareTo(Comparable comparable)
        {
            throw new MethodNotImplemented();
        }

        public int hashCode()
        {
            int i = number;
            if(weight != null)
                i += weight.hashCode();
            return i;
        }

        public String toString()
        {
            StringBuffer stringbuffer = new StringBuffer();
            stringbuffer.append("Vertex {" + number);
            if(weight != null)
                stringbuffer.append(", weight = " + weight);
            stringbuffer.append("}");
            return stringbuffer.toString();
        }

        public Enumeration getIncidentEdges()
        {
            return AbstractGraph.this.getIncidentEdges(number);
        }

        public Enumeration getEmanatingEdges()
        {
            return AbstractGraph.this.getEmanatingEdges(number);
        }

        public Enumeration getPredecessors()
        {
            return new Enumeration() {

                public boolean hasMoreElements()
                {
                    return edges.hasMoreElements();
                }

                public Object nextElement()
                {
                    Edge edge = (Edge)edges.nextElement();
                    return edge.getMate(GraphVertex.this);
                }

                Enumeration edges;

                
                {
                    edges = getIncidentEdges();
                }
            };
        }

        public Enumeration getSuccessors()
        {
            return new Enumeration() {

                public boolean hasMoreElements()
                {
                    return edges.hasMoreElements();
                }

                public Object nextElement()
                {
                    Edge edge = (Edge)edges.nextElement();
                    return edge.getMate(GraphVertex.this);
                }

                Enumeration edges;

                
                {
                    edges = getEmanatingEdges();
                }
            };
        }

        protected int number;
        protected Object weight;

        public GraphVertex(int i, Object obj)
        {
            number = i;
            weight = obj;
        }
    }


    public void purge()
    {
        for(int i = 0; i < numberOfVertices; i++)
            vertex[i] = null;

        numberOfVertices = 0;
        numberOfEdges = 0;
    }

    protected void addVertex(Vertex vertex1)
    {
        if(numberOfVertices == vertex.length) {
        	Vertex[] v = new Vertex[vertex.length * 2 + 1];
        	System.arraycopy(vertex, 0, v, 0, vertex.length);
        	vertex = v;
        }
        if(vertex1.getNumber() != numberOfVertices)
        {
            throw new IllegalArgumentException("invalid vertex number");
        } else
        {
            vertex[numberOfVertices] = vertex1;
            numberOfVertices++;
            return;
        }
    }

    public final void addVertex(int i, Object obj)
    {
        addVertex(((Vertex) (new GraphVertex(i, obj))));
    }

    public final void addVertex(int i)
    {
        addVertex(i, null);
    }

    public Vertex getVertex(int i)
    {
        Bounds.check(i, 0, numberOfVertices);
        return vertex[i];
    }

    public Enumeration getVertices()
    {
        return new Enumeration() {

            public boolean hasMoreElements()
            {
                return v < numberOfVertices;
            }

            public Object nextElement()
            {
                if(v >= numberOfVertices)
                    throw new NoSuchElementException();
                else
                    return vertex[v++];
            }

            protected int v;

            
            {
                v = 0;
            }
        };
    }

    public AbstractGraph(int i)
    {
        vertex = new Vertex[i];
    }

    protected abstract Enumeration getIncidentEdges(int i);

    protected abstract Enumeration getEmanatingEdges(int i);

    protected abstract void addEdge(Edge edge);
    
    public abstract void removeEdge(Edge edge);

    public boolean isDirected()
    {
        return this instanceof Digraph;
    }

    public final void addEdge(int i, int j, Object obj)
    {
        addEdge(((Edge) (new GraphEdge(i, j, obj))));
    }

    public final void addEdge(int i, int j)
    {
        addEdge(i, j, null);
    }

    public int getNumberOfVertices()
    {
        return numberOfVertices;
    }

    public int getNumberOfEdges()
    {
        return numberOfEdges;
    }

    public void accept(Visitor visitor)
    {
        for(int i = 0; i < numberOfVertices; i++)
        {
            if(visitor.isDone())
                break;
            visitor.visit(vertex[i]);
        }

    }

    public void depthFirstTraversal(PrePostVisitor prepostvisitor, int i)
    {
        boolean aflag[] = new boolean[numberOfVertices];
        for(int j = 0; j < numberOfVertices; j++)
            aflag[j] = false;

        depthFirstTraversal(prepostvisitor, vertex[i], aflag);
    }

    private void depthFirstTraversal(PrePostVisitor prepostvisitor, Vertex vertex1, boolean aflag[])
    {
        if(prepostvisitor.isDone())
            return;
        prepostvisitor.preVisit(vertex1);
        aflag[vertex1.getNumber()] = true;
        for(Enumeration enumeration = vertex1.getSuccessors(); enumeration.hasMoreElements();)
        {
            Vertex vertex2 = (Vertex)enumeration.nextElement();
            if(!aflag[vertex2.getNumber()])
                depthFirstTraversal(prepostvisitor, vertex2, aflag);
        }

        prepostvisitor.postVisit(vertex1);
    }

    public void breadthFirstTraversal(Visitor visitor, int i)
    {
        boolean aflag[] = new boolean[numberOfVertices];
        for(int j = 0; j < numberOfVertices; j++)
            aflag[j] = false;

        QueueAsLinkedList queueaslinkedlist = new QueueAsLinkedList();
        aflag[i] = true;
        queueaslinkedlist.enqueue(vertex[i]);
        while(!queueaslinkedlist.isEmpty() && !visitor.isDone()) 
        {
            Vertex vertex1 = (Vertex)queueaslinkedlist.dequeue();
            visitor.visit(vertex1);
            for(Enumeration enumeration = vertex1.getSuccessors(); enumeration.hasMoreElements();)
            {
                Vertex vertex2 = (Vertex)enumeration.nextElement();
                if(!aflag[vertex2.getNumber()])
                {
                    aflag[vertex2.getNumber()] = true;
                    queueaslinkedlist.enqueue(vertex2);
                }
            }

        }
    }

    public void topologicalOrderTraversal(Visitor visitor)
    {
        int ai[] = new int[numberOfVertices];
        for(int i = 0; i < numberOfVertices; i++)
            ai[i] = 0;

        for(Enumeration enumeration = getEdges(); enumeration.hasMoreElements();)
        {
            Edge edge = (Edge)enumeration.nextElement();
            Vertex vertex1 = edge.getV1();
            ai[vertex1.getNumber()]++;
        }

        QueueAsLinkedList queueaslinkedlist = new QueueAsLinkedList();
        for(int j = 0; j < numberOfVertices; j++)
            if(ai[j] == 0)
                queueaslinkedlist.enqueue(vertex[j]);

        while(!queueaslinkedlist.isEmpty() && !visitor.isDone()) 
        {
            Vertex vertex2 = (Vertex)queueaslinkedlist.dequeue();
            visitor.visit(vertex2);
            for(Enumeration enumeration1 = vertex2.getSuccessors(); enumeration1.hasMoreElements();)
            {
                Vertex vertex3 = (Vertex)enumeration1.nextElement();
                if(--ai[vertex3.getNumber()] == 0)
                    queueaslinkedlist.enqueue(vertex3);
            }

        }
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer();
        AbstractVisitor abstractvisitor = new AbstractVisitor() {

            public void visit(Object obj)
            {
                Vertex vertex1 = (Vertex)obj;
                buffer.append(vertex1 + "\n");
                Edge edge;
                for(Enumeration enumeration = vertex1.getEmanatingEdges(); enumeration.hasMoreElements(); buffer.append("    " + edge + "\n"))
                    edge = (Edge)enumeration.nextElement();

            }

        };
        accept(abstractvisitor);
        return getClass().getName() + " {\n" + buffer + "}";
    }

    public boolean isConnected()
    {
        final Counter counter = new Counter();
        AbstractPrePostVisitor abstractprepostvisitor = new AbstractPrePostVisitor() {

            public void visit(Object obj)
            {
                counter.value++;
            }

        };
        depthFirstTraversal(abstractprepostvisitor, 0);
        return counter.value == numberOfVertices;
    }

    public boolean isStronglyConnected()
    {
        final Counter counter = new Counter();
        for(int i = 0; i < numberOfVertices; i++)
        {
            counter.value = 0;
            AbstractPrePostVisitor abstractprepostvisitor = new AbstractPrePostVisitor() {

                public void visit(Object obj)
                {
                    counter.value++;
                }

            };
            depthFirstTraversal(abstractprepostvisitor, i);
            if(counter.value != numberOfVertices)
                return false;
        }

        return true;
    }

    public boolean isCyclic()
    {
        final Counter counter = new Counter();
        AbstractVisitor abstractvisitor = new AbstractVisitor() {

            public void visit(Object obj)
            {
                counter.value++;
            }

        };
        topologicalOrderTraversal(abstractvisitor);
        return counter.value != numberOfVertices;
    }

    public Enumeration getEnumeration()
    {
        return getVertices();
    }

    public abstract Enumeration getEdges();

    public abstract boolean isEdge(int i, int j);

    public abstract Edge getEdge(int i, int j);

    protected int numberOfVertices;
    protected int numberOfEdges;
    protected Vertex vertex[];
}
