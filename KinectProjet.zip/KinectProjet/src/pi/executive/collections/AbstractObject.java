package pi.executive.collections;


public abstract class AbstractObject
    implements Comparable
{

    public AbstractObject()
    {
    }

    protected abstract int compareTo(Comparable comparable);

    public final int compare(Comparable comparable)
    {
        if(getClass() == comparable.getClass())
            return compareTo(comparable);
        else
            return getClass().getName().compareTo(comparable.getClass().getName());
    }

    public final boolean isLT(Comparable comparable)
    {
        return compare(comparable) < 0;
    }

    public final boolean isLE(Comparable comparable)
    {
        return compare(comparable) <= 0;
    }

    public final boolean isGT(Comparable comparable)
    {
        return compare(comparable) > 0;
    }

    public final boolean isGE(Comparable comparable)
    {
        return compare(comparable) >= 0;
    }

    public final boolean isEQ(Comparable comparable)
    {
        return compare(comparable) == 0;
    }

    public final boolean isNE(Comparable comparable)
    {
        return compare(comparable) != 0;
    }

    public final boolean equals(Object obj)
    {
        if(obj instanceof Comparable)
            return isEQ((Comparable)obj);
        else
            return false;
    }

}
