package pi.executive.collections;

import java.util.Enumeration;


public interface Container
    extends Comparable
{

    public abstract int getCount();

    public abstract boolean isEmpty();

    public abstract boolean isFull();

    public abstract void purge();

    public abstract void accept(Visitor visitor);

    public abstract Enumeration getEnumeration();

}
