package pi.executive.collections;

import java.util.Enumeration;


public interface Graph
    extends Container
{

    public abstract int getNumberOfEdges();

    public abstract int getNumberOfVertices();

    public abstract boolean isDirected();

    public abstract void addVertex(int i);

    public abstract void addVertex(int i, Object obj);

    public abstract Vertex getVertex(int i);

    public abstract void addEdge(int i, int j);

    public abstract void addEdge(int i, int j, Object obj);

    public abstract Edge getEdge(int i, int j);

    public abstract boolean isEdge(int i, int j);

    public abstract boolean isConnected();

    public abstract boolean isCyclic();

    public abstract Enumeration getVertices();

    public abstract Enumeration getEdges();

    public abstract void depthFirstTraversal(PrePostVisitor prepostvisitor, int i);

    public abstract void breadthFirstTraversal(Visitor visitor, int i);

}
