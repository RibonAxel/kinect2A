package pi.executive.collections;


public class ContainerEmptyException extends DomainException
{

    public ContainerEmptyException()
    {
    }

}
