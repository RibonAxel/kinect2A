package pi.executive.collections;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;


public class GraphAsLists extends AbstractGraph
{

    public GraphAsLists(int i)
    {
        super(i);
        adjacencyList = new LinkedList[i];
        for(int j = 0; j < i; j++)
            adjacencyList[j] = new LinkedList();

    }

    public void purge()
    {
        for(int i = 0; i < super.numberOfVertices; i++)
            adjacencyList[i].clear();

        super.purge();
    }

    protected void addEdge(Edge edge)
    {
        int i = edge.getV0().getNumber();
        adjacencyList[i].add(edge);
        super.numberOfEdges++;
    }

	public void removeEdge(Edge edge) {
		int i = edge.getV0().getNumber();
		adjacencyList[i].remove(edge);
		super.numberOfEdges--;
	}
	
    public Edge getEdge(int i, int j)
    {
        Bounds.check(i, 0, super.numberOfVertices);
        Bounds.check(j, 0, super.numberOfVertices);
        Iterator iter = adjacencyList[i].iterator();
        while (iter.hasNext()) {
			Edge edge = (Edge)iter.next();
			if(edge.getV1().getNumber() == j)
				return edge;
        }

        throw new IllegalArgumentException("edge not found");
    }

    public boolean isEdge(int i, int j)
    {
        Bounds.check(i, 0, super.numberOfVertices);
        Bounds.check(j, 0, super.numberOfVertices);
		Iterator iter = adjacencyList[i].iterator();
		while (iter.hasNext()) {
			Edge edge = (Edge)iter.next();
            if(edge.getV1().getNumber() == j)
                return true;
        }

        return false;
    }

    protected Enumeration getIncidentEdges(int i)
    {
        throw new MethodNotImplemented();
    }

    public Enumeration getEdges()
    {
        return new Enumeration() {

            public boolean hasMoreElements()
            {
                return iter != null && iter.hasNext();
            }

            public Object nextElement()
            {
                if(iter == null)
                    throw new NoSuchElementException();
                Object obj = iter.next();
                if(! iter.hasNext())
                    for(v++; v < numberOfVertices; v++)
                    {
                        iter = adjacencyList[v].iterator();
                        if(iter.hasNext())
                            break;
                    }

                return obj;
            }

            protected int v;
            Iterator iter;

            
            {
                iter = null;
                for(v = 0; v < numberOfVertices; v++)
                {
                    iter = adjacencyList[v].iterator();
                    if(iter.hasNext())
                        break;
                }

            }
        };
    }

    protected Enumeration getEmanatingEdges(int i)
    {
        final Vertex arg = getVertex(i);
        return new Enumeration() {

            public boolean hasMoreElements()
            {
                return iter.hasNext();
            }

            public Object nextElement()
            {
                    Object obj = iter.next();
                    return obj;
            }

            protected int v;
            protected Iterator iter;

            
            {
                v = arg.getNumber();
                iter = adjacencyList[v].iterator();
            }
        };
    }

    protected int compareTo(Comparable comparable)
    {
        throw new MethodNotImplemented();
    }

    protected LinkedList adjacencyList[];
}
