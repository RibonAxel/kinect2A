package pi.executive.collections;

import java.util.Enumeration;
import java.util.NoSuchElementException;

public class QueueAsLinkedList extends AbstractContainer
    implements Queue
{

    public QueueAsLinkedList()
    {
        list = new LinkedList();
    }

    public void purge()
    {
        list.purge();
        super.count = 0;
    }

    public Object getHead()
    {
        if(super.count == 0)
            throw new ContainerEmptyException();
        else
            return list.getFirst();
    }

    public void enqueue(Object obj)
    {
        list.append(obj);
        super.count++;
    }

    public Object dequeue()
    {
        if(super.count == 0)
        {
            throw new ContainerEmptyException();
        } else
        {
            Object obj = list.getFirst();
            list.extract(obj);
            super.count--;
            return obj;
        }
    }

    public void accept(Visitor visitor)
    {
        for(LinkedList.Element element = list.getHead(); element != null; element = element.getNext())
        {
            visitor.visit(element.getDatum());
            if(visitor.isDone())
                return;
        }

    }

    public Enumeration getEnumeration()
    {
        return new Enumeration() {

            public boolean hasMoreElements()
            {
                return position != null;
            }

            public Object nextElement()
            {
                if(position == null)
                {
                    throw new NoSuchElementException();
                } else
                {
                    Object obj = position.getDatum();
                    position = position.getNext();
                    return obj;
                }
            }

            LinkedList.Element position;

            
            {
                position = list.getHead();
            }
        };
    }

    protected int compareTo(Comparable comparable)
    {
        throw new MethodNotImplemented();
    }

    protected LinkedList list;
}
