/*
 * Created on 8 avr. 2003
 *
 */

package pi.executive.collections;

import java.util.NoSuchElementException;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public class PoolingHashMap {
	private final float loadFactor;
	private int threshold;
	private int size;
	private Entry[] table;
	private Entry freeEntries;
	private Enumeration freeEnumerations;

	/**
	 * Constructs an empty HashMap with the default initial capacity (16) and the default load factor (0.75)
	 */

	public PoolingHashMap() {
		loadFactor = 0.75F;
		threshold = 16;
		table = new Entry[16];
	}

	/**
	 * Constructs an empty HashMap with the specified initial capacity and load factor
	 * @param i
	 * @param f
	 */
	
	public PoolingHashMap(int i, float f) {
		if (i < 0)
			throw new IllegalArgumentException(
				"Illegal initial capacity: " + i);
		if (i > 0x40000000)
			i = 0x40000000;
		if (f <= 0.0F || Float.isNaN(f))
			throw new IllegalArgumentException("Illegal load factor: " + f);
		int j;
		for (j = 1; j < i; j <<= 1);
		loadFactor = f;
		threshold = (int) ((float) j * f);
		table = new Entry[j];
	}

	/**
	 * Constructs an empty HashMap with the specified initial capacity and the default load factor (0.75)
	 * @param i
	 */
	
	public PoolingHashMap(int i) {
		this(i, 0.75F);
	}

	/**
	 * Returns the number of key-value mappings in this map
	 * @return
	 */
	
	public int size() {
		return size;
	}

	/**
	 * Returns true if this map contains no key-value mappings
	 * @return
	 */
	
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * Returns the value to which the specified key is mapped in 
	 * this identity hash map, or null if the map contains no mapping for this key
	 * @param obj
	 * @return
	 */
	
	public Object get(Object obj) {
		int i = hash(obj);
		int j = indexFor(i, table.length);
		Entry entry = table[j];
		do {
			if (entry == null)
				return entry;
			if (entry.hash == i && eq(obj, entry.key))
				return entry.value;
			entry = entry.next;
		} while (true);
	}

	/**
	 * Returns true if this map contains a mapping for the specified key
	 * @param obj
	 * @return
	 */
	
	public boolean containsKey(Object obj) {
		int i = hash(obj);
		int j = indexFor(i, table.length);
		for (Entry entry = table[j]; entry != null; entry = entry.next)
			if (entry.hash == i && eq(obj, entry.key))
				return true;

		return false;
	}

	/**
	 * Return the entry corresponding to the key object or null
	 * @param obj
	 * @return
	 */
	
	private Entry getEntry(Object obj) {
		int i = hash(obj);
		int j = indexFor(i, table.length);
		Entry entry;
		for (entry = table[j];
			entry != null && (entry.hash != i || !eq(obj, entry.key));
			entry = entry.next);
		return entry;
	}

	/**
	 * Associates the specified value with the specified key in this map
	 * @param obj
	 * @param obj1
	 * @return
	 */
	
	public Object put(Object obj, Object obj1) {
		int i = hash(obj);
		int j = indexFor(i, table.length);
		for (Entry entry = table[j]; entry != null; entry = entry.next)
			if (entry.hash == i && eq(obj, entry.key)) {
				Object obj3 = entry.value;
				entry.value = obj1;
				return obj3;
			}
		addEntry(i, obj, obj1, j);
		return null;
	}

	/**
	 * Removes the mapping for this key from this map if present
	 * @param obj
	 * @return
	 */
	
	public Object remove(Object obj) {
		Entry entry = removeEntryForKey(obj);
		if (entry != null) {
			freeEntry(entry);
			return entry.value;
		}
		return null;
	}

	/**
	 * Removes the entry corresponding to the key object
	 * @param obj
	 * @return
	 */
	
	private Entry removeEntryForKey(Object obj) {
		int i = hash(obj);
		int j = indexFor(i, table.length);
		Entry entry = table[j];
		Entry entry1;
		Entry entry2;
		for (entry1 = entry; entry1 != null; entry1 = entry2) {
			entry2 = entry1.next;
			if (entry1.hash == i && eq(obj, entry1.key)) {
				size--;
				if (entry == entry1)
					table[j] = entry2;
				else
					entry.next = entry2;
				return entry1;
			}
			entry = entry1;
		}

		return entry1;
	}

	/**
	 * Removes all mappings from this map
	 */
	
	public void clear() {
		Entry aentry[] = table;
		for (int i = 0; i < aentry.length; i++) {
			Entry entry = aentry[i];
			while (entry != null) {
				aentry[i] = entry.next;
				freeEntry(entry);
				entry = aentry[i];
			}
		}

		size = 0;
	}

	/**
	 * Returns an enumerator over the keys in this map
	 * @return
	 */
	
	public PoolingEnumeration keys() {
		return newEnumeration();
	}

	/**
	 * Returns true if this map maps one or more keys to the specified value
	 * @param obj
	 * @return
	 */
	
	public boolean containsValue(Object obj) {
		if (obj == null)
			return containsNullValue();
		Entry aentry[] = table;
		for (int i = 0; i < aentry.length; i++) {
			for (Entry entry = aentry[i]; entry != null; entry = entry.next)
				if (obj.equals(entry.value))
					return true;

		}

		return false;
	}

	/**
	 * Returns true if this map maps one or more keys to null
	 * @return
	 */
	
	private boolean containsNullValue() {
		Entry aentry[] = table;
		for (int i = 0; i < aentry.length; i++) {
			for (Entry entry = aentry[i]; entry != null; entry = entry.next)
				if (entry.value == null)
					return true;

		}

		return false;
	}

	/**
	 * Calculates a hashing value for an object
	 * @param obj
	 * @return
	 */
	
	static private int hash(Object obj) {
		int i = obj.hashCode();
		i += i << 4;
		return i;
	}

	/**
	 * Returns true if objects are equal through references or content
	 * @param obj
	 * @param obj1
	 * @return
	 */
	
	static boolean eq(Object obj, Object obj1) {
		return obj == obj1 || obj.equals(obj1);
	}

	/**
	 * Returns an index modulo j - 1
	 * @param i index to map
	 * @param j a power of 2
	 * @return
	 */
	
	static int indexFor(int i, int j) {
		return i & j - 1;
	}

	/**
	 * Adds a new entry
	 * @param hash
	 * @param key
	 * @param value
	 * @param j
	 */
	
	private void addEntry(int hash, Object key, Object value, int j) {
		table[j] = newEntry(hash, key, value, table[j]);
		if (size++ >= threshold)
			resize(2 * table.length);
	}

	/**
	 * Resizes the entry table
	 * @param i
	 */
	
	private void resize(int i) {
		Entry aentry[] = table;
		int j = aentry.length;
		if (size < threshold || j > i) {
			return;
		} else {
			Entry aentry1[] = new Entry[i];
			transfer(aentry1);
			table = aentry1;
			threshold = (int) ((float) i * loadFactor);
			return;
		}
	}

	/**
	 * Transfers entry from the current table to the given table
	 * @param aentry
	 */
	
	private void transfer(Entry aentry[]) {
		Entry aentry1[] = table;
		int i = aentry.length;
		for (int j = 0; j < aentry1.length; j++) {
			Entry entry = aentry1[j];
			if (entry != null) {
				aentry1[j] = null;
				do {
					Entry entry1 = entry.next;
					int k = indexFor(entry.hash, i);
					entry.next = aentry[k];
					aentry[k] = entry;
					entry = entry1;
				} while (entry != null);
			}
		}

	}

	/**
	 * Creates a new entry from the pool
	 * @param hash
	 * @param key
	 * @param value
	 * @param next
	 * @return
	 */
	
	private Entry newEntry(int hash, Object key, Object value, Entry next) {
		Entry entry = freeEntries;
		if (entry == null)
			entry = new Entry(hash, key, value, next);
		else {
			freeEntries = entry.next;
			entry.initialize(hash, key, value, next);
		}
		return entry;
	}

	/**
	 * Enters the entry in the pool
	 * @param entry
	 */
	
	private void freeEntry(Entry entry) {
		entry.next = freeEntries;
		freeEntries = entry;
	}

	/**
	 * Creates a new enumeration from the pool
	 * @return
	 */
	
	private Enumeration newEnumeration() {
		Enumeration e = freeEnumerations;
		if (e == null)
			e = new Enumeration();
		else {
			freeEnumerations = e.succ;
			e.initialize();
		}
		return e;
	}

	/**
	 * Enters the enumeration to the pool
	 * @param e
	 */
	
	private void releaseEnumeration(Enumeration e) {
		e.succ = freeEnumerations;
		freeEnumerations = e;
	}

	/**
	 * Enumerates keys in the map
	 * The method free should be called when the enumerator use has ended
	 * 
	 * @author Bernard Thirion, Philippe Studer
	 *
	 * 
	 */
	
	public class Enumeration implements PoolingEnumeration {
		private Entry next;
		private int index;
		private Enumeration succ;

		/**
		 * Constructs an enumerator
		 */
		
		Enumeration() {
			super();
			initialize();
		}

		/**
		 * Initializes the enumerator
		 */
		
		void initialize() {
			Entry aentry[] = table;
			int i = aentry.length;
			Entry entry = null;
			if (size != 0)
				while (i > 0 && (entry = aentry[--i]) == null);
			next = entry;
			index = i;
		}

		/**
		 * @see java.util.Enumeration#hasMoreElements()
		 */

		public boolean hasMoreElements() {
			return next != null;
		}

		/**
		 * @see java.util.Enumeration#nextElement()
		 */
		public Object nextElement() {
			Entry entry = next;
			if (entry == null)
				throw new NoSuchElementException();
			Entry entry1 = entry.next;
			Entry aentry[] = table;
			int i;
			for (i = index; entry1 == null && i > 0; entry1 = aentry[--i]);
			index = i;
			next = entry1;
			return entry.key;
		}

		/**
		 * Frees the enumerator
		 */
		
		public void release() {
			releaseEnumeration(this);
		}

	}

	/**
	 * An hashmap entry
	 * 
	 * @author Bernard Thirion, Philippe Studer
	 *
	 * 
	 */
	
	private class Entry {
		Object key;
		Object value;
		int hash;
		Entry next;

		/**
		 * Constructs an entry
		 * @param hash
		 * @param key
		 * @param value
		 * @param next
		 */
		
		private Entry(int hash, Object key, Object value, Entry next) {
			this.key = key;
			this.value = value;
			this.next = next;
			this.hash = hash;
		}

		/**
		 * Initializes an entry
		 * @param hash
		 * @param key
		 * @param value
		 * @param next
		 */
		
		public void initialize(
			int hash,
			Object key,
			Object value,
			Entry next) {
			this.key = key;
			this.value = value;
			this.next = next;
			this.hash = hash;
		}

		/**
		 * Returns the key associated to this entry
		 * @return
		 */
		
		public Object getKey() {
			return key;
		}

		/**
		 * Returns the value associated to this entry
		 * @return
		 */
		
		public Object getValue() {
			return value;
		}

		/**
		 * Replaces the value associated to this entry
		 * @param value
		 * @return old value
		 */
		
		public Object setValue(Object value) {
			Object old = this.value;
			this.value = value;
			return old;
		}

		/**
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		
		public boolean equals(Object obj) {
			if (!(obj instanceof Entry))
				return false;
			Entry entry = (Entry) obj;
			Object obj1 = getKey();
			Object obj2 = entry.getKey();
			if (obj1 == obj2 || obj1 != null && obj1.equals(obj2)) {
				Object obj3 = getValue();
				Object obj4 = entry.getValue();
				if (obj3 == obj4 || obj3 != null && obj3.equals(obj4))
					return true;
			}
			return false;
		}

		/**
		 * @see java.lang.Object#toString()
		 */
		
		public String toString() {
			return getKey() + "=" + getValue();
		}

	}

}
