/*
 * Created on 9 avr. 2003
 *
 */

package pi.executive.collections;


/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */
public class PoolingHashSet {
	private PoolingHashMap map;

	/**
	 * Constructs a new, empty set
	 */

	public PoolingHashSet() {
		super();
		map = new PoolingHashMap();
	}

	/**
	 * Constructs a new, empty set; the backing HashMap instance has 
	 * the specified initial capacity and default load factor, which is 0.75
	 * @param i
	 */

	public PoolingHashSet(int i) {
		super();
		map = new PoolingHashMap();
	}

	/**
	 * Returns true if this set contains the specified element
	 * @param object
	 * @return
	 */

	public boolean contains(Object object) {
		return map.containsKey(object);
	}

	/**
	 * Adds the specified element to this set if it is not already present
	 * @param object
	 */

	public void add(Object object) {
		map.put(object, null);
	}

	/**
	 * Removes the specified element from this set if it is present
	 * @param object
	 */

	public void remove(Object object) {
		map.remove(object);
	}

	/**
	 * Removes all of the elements from this set
	 */

	public void clear() {
		map.clear();
	}

	/**
	 * Returns the number of elements in this set (its cardinality)
	 * @return
	 */

	public int size() {
		return map.size();
	}

	/**
	 * Returns an enumerator over the elements in this set
	 * @return
	 */

	public PoolingEnumeration elements() {
		return map.keys();
	}
}
