package pi.executive.collections;


public abstract class AbstractVisitor
    implements Visitor
{

    public AbstractVisitor()
    {
    }

    public void visit(Object obj)
    {
    }

    public boolean isDone()
    {
        return false;
    }

}
