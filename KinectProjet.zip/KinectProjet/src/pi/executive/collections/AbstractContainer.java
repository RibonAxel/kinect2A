package pi.executive.collections;

import java.util.Enumeration;


public abstract class AbstractContainer extends AbstractObject
    implements Container
{

    public AbstractContainer()
    {
    }

    public int getCount()
    {
        return count;
    }

    public boolean isEmpty()
    {
        return getCount() == 0;
    }

    public boolean isFull()
    {
        return false;
    }

    public void accept(Visitor visitor)
    {
        for(Enumeration enumeration = getEnumeration(); enumeration.hasMoreElements() && !visitor.isDone(); visitor.visit(enumeration.nextElement()));
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer();
        AbstractVisitor abstractvisitor = new AbstractVisitor() {

            public void visit(Object obj)
            {
                if(comma)
                    buffer.append(", ");
                buffer.append(obj);
                comma = true;
            }

            private boolean comma;

        };
        accept(abstractvisitor);
        return getClass().getName() + " {" + buffer + "}";
    }

    public int hashCode()
    {
        AbstractVisitor abstractvisitor = new AbstractVisitor() {

            public void visit(Object obj)
            {
                value += obj.hashCode();
            }

            public int hashCode()
            {
                return value;
            }

            private int value;

        };
        accept(abstractvisitor);
        return getClass().hashCode() + abstractvisitor.hashCode();
    }

    public abstract Enumeration getEnumeration();

    public abstract void purge();

    protected int count;
}
