package pi.executive.collections;


public interface Comparable
{

    public abstract boolean isLT(Comparable comparable);

    public abstract boolean isLE(Comparable comparable);

    public abstract boolean isGT(Comparable comparable);

    public abstract boolean isGE(Comparable comparable);

    public abstract boolean isEQ(Comparable comparable);

    public abstract boolean isNE(Comparable comparable);

    public abstract int compare(Comparable comparable);

}
