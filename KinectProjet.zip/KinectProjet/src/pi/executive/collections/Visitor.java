package pi.executive.collections;


public interface Visitor
{

    public abstract void visit(Object obj);

    public abstract boolean isDone();

}
