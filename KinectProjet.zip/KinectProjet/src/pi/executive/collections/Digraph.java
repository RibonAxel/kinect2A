package pi.executive.collections;


public interface Digraph
    extends Graph
{

    public abstract boolean isStronglyConnected();

    public abstract void topologicalOrderTraversal(Visitor visitor);

}
