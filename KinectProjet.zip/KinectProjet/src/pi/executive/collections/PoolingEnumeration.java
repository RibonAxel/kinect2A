/*
 * Created on 30 avr. 2003
 *
 */
 
package pi.executive.collections;

import java.util.Enumeration;

/**
 * @author Bernard Thirion, Philippe Studer
 *
 * 
 */

public interface PoolingEnumeration extends Enumeration {

	public void release();
}
