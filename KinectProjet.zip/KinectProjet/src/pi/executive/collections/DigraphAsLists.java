package pi.executive.collections;


public class DigraphAsLists extends GraphAsLists
    implements Digraph
{

    public DigraphAsLists(int i)
    {
        super(i);
    }

}
