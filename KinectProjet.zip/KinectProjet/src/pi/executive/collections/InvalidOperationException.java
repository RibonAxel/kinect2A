package pi.executive.collections;


public class InvalidOperationException extends DomainException
{

    public InvalidOperationException()
    {
    }

}
