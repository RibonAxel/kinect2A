//  Created by Bernard Thirion on Fri Feb 13 2004.

// Compound agent, control and delta is done using agents appending order

package pi.executive;

public class CompoundContinuousAgent implements ContinuousAgent {

	protected FunctionalAgent[] functionalChildren;
	protected ContinuousAgent[] continuousChildren;
   
   private void addFunctionalAgent(FunctionalAgent agent) {
		if (functionalChildren == null)
			functionalChildren = new FunctionalAgent[] { agent };
		else {
			int length = functionalChildren.length;
			FunctionalAgent[] c = new FunctionalAgent[length + 1];
			System.arraycopy(functionalChildren, 0, c, 0, length);
			c[length] = agent;
			functionalChildren = c;
		}
	}
   
   private void addContinuousAgent(ContinuousAgent agent) {
		if (continuousChildren == null)
			continuousChildren = new ContinuousAgent[] { agent };
		else {
			int length = continuousChildren.length;
			ContinuousAgent[] c = new ContinuousAgent[length + 1];
			System.arraycopy(continuousChildren, 0, c, 0, length);
			c[length] = agent;
			continuousChildren = c;
		}
	}
   
	public void addAgent(FunctionalAgent a) {
		if (a instanceof FunctionalAgent)
			addFunctionalAgent(a);
		if (a instanceof ContinuousAgent)
			addContinuousAgent((ContinuousAgent) a);
	}

	public void control() {
      int length = functionalChildren.length;
      for (int i = 0; i < length; i++) {
         functionalChildren[i].control();
      }   
   }
   
	public void delta(double dt) {
      int length = continuousChildren.length;
      for (int i = 0; i < length; i++) {
         continuousChildren[i].delta(dt);
      }
   }
   
}

