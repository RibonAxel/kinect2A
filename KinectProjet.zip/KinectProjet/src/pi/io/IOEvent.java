//  Event.java
//  Created by Bernard Thirion on 21/03/07.

package pi.io;

public class IOEvent {

	private boolean present = false;

	public synchronized boolean isPresent() {
		return present;
	}

	public void read() {
        present = false;
	}

   public synchronized void present() {
      present = true;	
   }
   
   public synchronized void absent () {
      present = false;	
   }

}
