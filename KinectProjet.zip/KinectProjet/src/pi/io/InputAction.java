//  InputAction.java
//  Created by Bernard Thirion on Fri May 21 2004.

package pi.io;

import pi.executive.DiscreteAction;
import pi.executive.State;
import pi.io.IOEvent;

public abstract class InputAction extends DiscreteAction {

   private IOEvent event;

   public InputAction(IOEvent event, State from) {
      super(from);
      this.event = event;
   }

   public synchronized boolean isEnabled() {
      return event.isPresent();
   }

   public synchronized void fire() {
      super.fire();
      event.read();
   }

}
