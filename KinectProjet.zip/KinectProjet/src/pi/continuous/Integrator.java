package pi.continuous;

import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleSink;
import pi.executive.ContinuousAgent;

public class Integrator implements ContinuousAgent {

   private double       x;
   private DoubleSource u;
   private DoubleSink   y;

   public Integrator (DoubleSource u, DoubleSink y) {
      this (u, y, 0.0);
   }

   public Integrator (DoubleSource u, DoubleSink y, double x0) {
      this.u = u;
      this.y = y;
      this.x = x0;
   }

   public void control() {
      y.value(x);
   }
	
   public void delta(double dt) {
      x = x + u.value() * dt;
   }
	
}
