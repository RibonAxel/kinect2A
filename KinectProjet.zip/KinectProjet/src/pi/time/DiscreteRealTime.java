package pi.time;

/**
 * Real time clock
 */

public class DiscreteRealTime extends DiscreteTime {
	private long    tick0     = System.currentTimeMillis();
	private double  safeDelay = 0.0;
	private boolean derive    = false;

	public DiscreteRealTime(double period) {
		super(period);
		this.reset();
	}

	/**
	 * Sets a duration substracted to the time of the next tick
	 * @param delay in seconds
	 */
	
	public void setSafeDelay(double delay) {
		if (delay >= 0.0)
			this.safeDelay = delay;
	}
	
	public void reset() {
		super.reset();
		tick0 = System.currentTimeMillis();
	}

	public void next() {
		super.next();

		long done = tick0 + (long) (1000.0 * time);
		derive = System.currentTimeMillis() > done;
		// Give time to the UI thread
		try {
			Thread.sleep((long) 1);
		} catch (InterruptedException ex) {
		}
		// 
		while (System.currentTimeMillis() < done)
			Thread.yield();
			try {
				Thread.sleep((long) 1);
			} catch (InterruptedException ex) {
			}
	}
	
	/**
	 * Returns true if there is more than safe delay seconds until the next tick
	 * @return
	 */
	
	public boolean hasEnoughTime() {
		return System.currentTimeMillis() <= tick0 + (long)(1000.0 * (nextValue() - safeDelay));
	}

	public boolean derive() {
		return derive;
	}
}
