package pi.time;

/*
 * logical clock
 */

public class DiscreteTime {
	protected double delta = 0.0; // seconds
	protected double time  = 0.0; // seconds
	protected int step = 0;

	public DiscreteTime(double period) {
		this.delta = period;
		this.reset();
	}

	public double delta() {
		return this.delta;
	}

	public double value() {
		return this.time;
	}

	public int steps() {
		return this.step;
	}

	public void setPeriod(double period) {
		this.delta = period;
	}

	public void reset() {
		time = 0.0;
		step = 0;
	}

	public void next() {
		time = time + delta;
		step++;
	}
	
	protected double nextValue() {
		return time + delta;
	}
}
