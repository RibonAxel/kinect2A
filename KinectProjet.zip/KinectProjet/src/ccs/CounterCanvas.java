package ccs;

import java.lang.Math;
import java.awt.Canvas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;

import pi.endpoint.DoubleValue;

public class CounterCanvas extends Canvas {
	
    public static final int WIDTH  = 380;
    public static final int HEIGHT = 380;
    private static final int XC     = WIDTH /2;
    private static final int YC     = HEIGHT/2;

    private static final int COUNTER_SIZE = 300;
    private static final int DOT_SIZE     =  12;
    private static final int DOT_RHO      =  COUNTER_SIZE / 2 - 10 ;
    private static final int NEEDLE_SIZE  =  COUNTER_SIZE / 2 - 20;
    private static final int NEEDLE_ROTOR =  15;
    private static final int LABEL_RHO    =  COUNTER_SIZE / 2 + 10;

	private static final double THETA     = Math.PI / 18.0;
	private static final double TWO_PI    = 2.0 * Math.PI;

	private static RenderingHints HINTS   = new RenderingHints(RenderingHints.KEY_ANTIALIASING, 
                                                               RenderingHints.VALUE_ANTIALIAS_ON);

    private static final BasicStroke NEEDLE_STROKE = new BasicStroke(3);
    private static final BasicStroke FRAME_STROKE  = new BasicStroke(2);

    private static final Color BG_COLOR            = new Color( 57,  57,  57);
    private static final Color COUNTER_COLOR       = new Color(115, 115, 115);
    private static final Color GREEN_ON_COLOR      = new Color(127, 255,   0);
    private static final Color GREEN_OFF_COLOR     = new Color( 80, 160,   0);
    private static final Color RED_ON_COLOR        = new Color(255,  29,   0);
    private static final Color RED_OFF_COLOR       = new Color(127,  14,   1);
    private static final Color STANDBY_COLOR       = new Color(255,  29,   0);
    
    private static Image CC_ON   = Toolkit.getDefaultToolkit().getImage ("images/cc_on.jpg" );
    private static Image CC_OFF  = Toolkit.getDefaultToolkit().getImage ("images/cc_off.jpg");
    private static Image CC_STBY = Toolkit.getDefaultToolkit().getImage ("images/cc_standby.jpg");

	private double  speed;
	private double  targetSpeed;
    private boolean engineOn = false;
    private int     ccStatus = ControllerStatus.DISABLED;
    
	private Image offscreenImage = null;
	
	public CounterCanvas(int X0, int Y0) {
		speed = 0.0;
		setBounds    (X0, Y0, WIDTH, HEIGHT);
		setBackground(BG_COLOR);		        
 	}

    public void setSpeed(double speed) {
       this.speed = speed;
    }
    
    public void setTargetSpeed(double targetSpeed) {
       this.targetSpeed = targetSpeed;
    }
    
    public void setControllerStatus(int status) {
       this.ccStatus = status;
    }
    
    public void engineOn() {
       this.engineOn = true;
    }

    public void engineOff() {
       this.engineOn = false;
    }

    private double angle(double speed) {
       double delta = (Math.PI / 6.0) / 20.0;
       return - (4.0 * Math.PI/6.0 + speed * delta);
    }
    
    private int dotX (double speed) {
       return XC + (int) (DOT_RHO * Math.cos(angle(speed)));      
    }
    
    private int dotY (double speed) {
       return YC - (int) (DOT_RHO * Math.sin(angle(speed)));      
    }
    
    private Color greenColor () {
       if (engineOn) return GREEN_ON_COLOR; else return GREEN_OFF_COLOR;
    }
    
    private Color redColor () {
       if (engineOn) return RED_ON_COLOR; else return RED_OFF_COLOR;
    }
    
 	private void drawFrame(Graphics2D g) {
        g.setColor(BG_COLOR); 
        g.fillRect(0,0, WIDTH, HEIGHT);
        int x0 = XC - COUNTER_SIZE / 2;
        int y0 = YC - COUNTER_SIZE / 2;        
 		g.setStroke(FRAME_STROKE);
 		g.setColor(COUNTER_COLOR);        
		g.fillOval(x0, y0, COUNTER_SIZE, COUNTER_SIZE);	        
		g.setColor(greenColor());        
		g.drawOval(x0, y0, COUNTER_SIZE, COUNTER_SIZE);	    
    }
    
   private int labelX (int speed) {
      int x = XC + (int) (LABEL_RHO * Math.cos(angle(speed))); 
      switch (speed) {
         case   0: x = x - 15; break;
         case  20: x = x - 18; break;
         case  40: x = x - 15; break;
         case  60: x = x - 15; break;
         case  80: x = x - 13; break;
         case 100: x = x - 12; break;
         case 120: x = x; break;
         case 140: x = x; break;
         case 160: x = x - 3; break;
         case 180: x = x; break;
         case 200: x = x + 2; break;
      }
      return x;     
   }
    
   private int labelY (int speed) {
      int    y = YC - (int) (LABEL_RHO * Math.sin(angle(speed)));
      switch (speed) {
         case   0: y = y + 5; break;
         case  20: y = y; break;
         case  40: y = y + 5; break;
         case  60: y = y; break;
         case  80: y = y; break;
         case 100: y = y + 3; break;
         case 120: y = y + 3; break;
         case 140: y = y + 5; break;
         case 160: y = y + 5; break;
         case 180: y = y + 5; break;
         case 200: y = y + 5; break;
      }
      return y;     
   }
        
    private void drawNeedle(Graphics2D g) {
        double theta = angle (speed);
        int x_end = XC + (int) (NEEDLE_SIZE * Math.cos(theta));      
        int y_end = XC - (int) (NEEDLE_SIZE * Math.sin(theta));      
		g.setColor (redColor());
		g.setStroke(NEEDLE_STROKE);
		g.drawLine (XC, YC , x_end, y_end);    
 		g.setColor (BG_COLOR);        
		g.fillOval (XC - NEEDLE_ROTOR, YC - NEEDLE_ROTOR, 2 * NEEDLE_ROTOR, 2 * NEEDLE_ROTOR);	        
    }
    
   private void drawLabels(Graphics2D g) {
        for (int i = 0; i <= 10; i ++) {
           int    speed = 20 * i;
           double theta = angle (speed);
           String label = String.valueOf(speed);
 		   g.setColor  (greenColor());        
           g.drawString(label, labelX(speed), labelY(speed));
        }
        g.drawString("km/h", XC - 13, YC - 80);
    }
    
    private void drawDot(Graphics2D g, int x, int y, Color color) {
        int x0 = x - DOT_SIZE / 2;
        int y0 = y - DOT_SIZE / 2;        
 		g.setColor(color);        
		g.fillOval(x0, y0, DOT_SIZE, DOT_SIZE);	        
    }
    
    private void drawDots(Graphics2D g) {
        for (int i = 0; i <= 10; i ++) {
           double speed = 20.0 * i;
           drawDot(g, dotX(speed), dotY(speed), greenColor());
        }
        drawDot(g, dotX( 50.0), dotY( 50.0), redColor());
        drawDot(g, dotX( 90.0), dotY( 90.0), redColor());
        drawDot(g, dotX(130.0), dotY(130.0), redColor());    
    }
 
  	private void drawCCStatus(Graphics2D g) {
        switch (ccStatus) {
           case ControllerStatus.DISABLED: 
              g.drawImage(CC_OFF, 10, HEIGHT - 40, this);
 		      g.setColor(greenColor());        
              g.drawString("Off", 45, HEIGHT - 20);
              break;
           case ControllerStatus.ENABLED:
              g.drawImage(CC_ON,  10, HEIGHT - 40, this);
 		      g.setColor(greenColor());        
              g.drawString("On " + String.valueOf((int)targetSpeed) + " km/h", 45, HEIGHT - 20);
              break;           
           case ControllerStatus.STANDBY:       
              g.drawImage(CC_STBY, 10, HEIGHT - 40, this);
 		      g.setColor(STANDBY_COLOR);        
              g.drawString("Standby", 45, HEIGHT - 20);
              break;
        }
    }
 
  	private void draw(Graphics g) {
 		Graphics2D g2d = (Graphics2D) g;
 		g2d.setRenderingHints(HINTS); 
        drawFrame   (g2d);
        drawLabels  (g2d);
        drawDots    (g2d);
        drawNeedle  (g2d);
        drawCCStatus(g2d);
    }
   	
   public void paint(Graphics g) {	
      if (offscreenImage == null) offscreenImage = createImage(WIDTH, HEIGHT);
      Graphics image = offscreenImage.getGraphics();
      this.draw(image);
      g.drawImage(offscreenImage, 0, 0, this);
   }

   public synchronized void update () {
      paint(this.getGraphics());
   }
	

}
