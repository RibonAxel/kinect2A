package ccs;

// Simple first order car model with following Tranfer Function
// 
// First Order Transfer function:   V(S)   = (MAX_SPEED/(1+TAU*S)) * (A(S) + Pertubation(S))
// Discretized equation:            speed' = (1-alpha)*speed + alpha * MAX_SPEED * (A + perturbation)

import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleSink;
import pi.executive.ContinuousAgent;

public class CarSimulation implements ContinuousAgent {

    private static final double SENSIBILITY    =  0.01; 
    private static final double MAX_SPEED      = 200.0; 
    private static final double       TAU      =   8.0;
    
	private DoubleSource A;    // A = 1.0 for MAX_SPEED
	private DoubleSource P;    // Perturbation
	private DoubleSink   S;

	private double speed        = 0.0;    
    private double perturbation = 0.0;
	
	public CarSimulation(DoubleSource A, DoubleSource P, DoubleSink S) {
		this.A = A;
		this.P = P;
		this.S = S;
	}
	
   public void control() {
      S.value(speed);
   }

   private void evaluatePerturbation(double dt) {
      if (A.value() != 0) 
         perturbation = SENSIBILITY * P.value();
      else perturbation = 0.0;  // avoid perturbation while at rest
   }

   public void evaluateSpeed(double dt) {
      double alpha = dt/TAU;
      speed = speed * (1.0 - alpha) + alpha * MAX_SPEED * (A.value() + perturbation);
   }
	
   public void delta(double dt) {
      this.evaluatePerturbation(dt);
      this.evaluateSpeed(dt);
   }
   
}
