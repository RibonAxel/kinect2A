//  SpeedControllerStatus.java
//  Created by Bernard Thirion on 02/04/07.

package ccs;

public class ControllerStatus {

   public static final int DISABLED = 0;
   public static final int ENABLED   = 1;
   public static final int STANDBY   = 2;
   
   private int state = DISABLED;
   
   public int  state() { return this.state; }
   
   public void setState (int state) { 
      this.state = state;
   }
   
}
