//  CruiseController.java
//  Created by Bernard Thirion on 3/04/07.

package ccs;

import pi.executive.Fireable;
import pi.executive.interaction.RendezVous;
import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleSink;
import pi.endpoint.DoubleEndpoint;
import pi.endpoint.DoubleValue;

import pi.executive.Agent;
import pi.container.Container;

public class CruiseController extends Container {

   public static final double DELTA = SpeedController.DELTA;  // sampling rate

   public  SpeedController controller;
   
   public  DoubleValue accelerator, targetSpeed;
   public  ControllerStatus ccStatus;
   
   public  Fireable engineOn, engineOff, on, off, resume, brake, accelerate;

   private Supervisor      supervisor;

   private RendezVous record, enable, disable;
      
   public CruiseController (DoubleSource speed, DoubleEndpoint throttle) {
      accelerator      = new DoubleValue();
      targetSpeed      = new DoubleValue();
      ccStatus         = new ControllerStatus();
      supervisor       = new Supervisor     (ccStatus, throttle, accelerator);
      controller       = new SpeedController(accelerator, speed, targetSpeed, throttle);
      this.buildInteractions();
      this.exportActions    ();
   }

   private void buildInteractions() {
      record  = new RendezVous(new Fireable[] {supervisor.record,  controller.record });
      enable  = new RendezVous(new Fireable[] {supervisor.enable , controller.enable });
      disable = new RendezVous(new Fireable[] {supervisor.disable, controller.disable});
   }
   
   private void exportActions() {
      engineOn   = supervisor.engineOn;
      engineOff  = supervisor.engineOff;
      on         = supervisor.on; 
      off        = supervisor.off;
      resume     = supervisor.resume;
      brake      = supervisor.brake;
      accelerate = supervisor.accelerate;
   }

   public int agentCount() { return 2; }
   
   public Agent agent(int index) {
      switch (index) {
         case   0: return controller;
         case   1: return supervisor;
         default : return null;
      }
   }

}
