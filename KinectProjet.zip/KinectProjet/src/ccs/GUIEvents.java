package ccs;

import pi.io.IOEvent;

public class GUIEvents {
 
   public IOEvent on         = new IOEvent();
   public IOEvent off        = new IOEvent();
   public IOEvent resume     = new IOEvent();
   public IOEvent accelerate = new IOEvent();
   public IOEvent brake      = new IOEvent();
   public IOEvent engineOn   = new IOEvent();
   public IOEvent engineOff  = new IOEvent();
    
}
