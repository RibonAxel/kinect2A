// uses an adaptive PID controller, and a saturation. 
// the control variable is normalized between 0 and 1.0
// the speed varies from 0.0 to 200.0
// PID control equation: control            = Kp * error + Ki * integral_error + Kd * differential_error
//                       error              = speed - targetSpeed
//                       integral_error     = sigma of error
//                       differential_error = error - previousError
// The equation is rewritten in order to use the basic control/delta cycle of an agent.
// The equation becomes  control = ie + (Kp + Ki + Kd) * error - Kd * previousError
// where                 ie      = sigma of Ki * error, calculated in delta preceding methods
// For more information have a look at Patrick Alliot PhD, pp. 63, 64
// 
// The coefficient Ki is adjusted following a non linear map


package ccs;

import pi.executive.Fireable;
import pi.executive.Activity;
import pi.executive.HybridAction;
import pi.executive.DefaultHybridAgent;
import pi.executive.interaction.OrInteraction;

import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleSink;
import pi.endpoint.DoubleEndpoint;

public class SpeedController extends DefaultHybridAgent {

   public static final double DELTA = 0.01;       // The controller is calibrated for this sampling rate

   private static final double KP = 0.04;
   private static final double KI = 0.00075;
   private static final double KD = 0.1;
   
   public  Fireable enable, disable, record;
   private Fireable recordWhenDisabled, recordWhenEnabled; 
   private Disabled disabled;
   private Enabled  enabled;

   private double      error          = 0.0;
   private double      previousError  = 0.0;
   private double      ie             = 0.0;
   
   private DoubleSink     throttle;   
   private DoubleSource   speed, accelerator;
   private DoubleEndpoint targetSpeed;
   
   private double Kp() { 
      return KP;
   }

   private double Ki() {
      double ae = Math.abs(error);
      return KI / (1.0 + 1.2*ae);
   }

   private double Kd() { 
      return KD ;
   }
   
   private static double saturation (double x) {
      x = Math.max (0.0,   x);
      x = Math.min (x,    1.0);
      return x;
   }
   
   private abstract class SCActivity extends Activity {
      public SpeedController controller;		
      public SCActivity(SpeedController controller) {
         super();
         this.controller = controller;
      }

      public void control( )         { }

      public void delta (double dt) { }
            
   }
	
   private class Disabled extends SCActivity {

      public Disabled(SpeedController controller) {
         super(controller);
      }
      
      public void control() { 
         double acceleration = accelerator.value();  // pass through
         throttle.value(acceleration);
      }
      
	}
    
    private class Enabled extends SCActivity {
   
      public Enabled(SpeedController controller) {
         super(controller);
      }
      
      public void control() { 
         error               = targetSpeed.value() - speed.value();
         double command      = saturation(ie + (Kp() + Ki() + Kd()) * error - Kd() * previousError);
         throttle.value(command);
      }
      
      public void delta(double dt) { 
         ie            = ie + Ki() * error; 
         previousError = error;
      }

	}
    
   private class BasicAction extends HybridAction {
   
		private SpeedController controller;
		private SCActivity      then;
		private String          name;
        
		public BasicAction(SpeedController controller, SCActivity from, SCActivity then, String name) {
			super(from);
			this.controller = controller;
            this.then       = then;
            this.name       = name;
		}
		
		public DefaultHybridAgent context() {
			return controller;
		}
        
        public Activity then() {
			return then;
		}
        
	}
  
    private class Enable extends BasicAction {
				
		public Enable (SpeedController controller, SCActivity from, SCActivity then, String name) {
			super(controller, from, then, name);
		}
				
		public void jump() {
            super.jump();
            previousError   = 0.0;
            ie              = (speed.value() / 200.0) ; // estimate integrator initial condition
		}	
        	
	}
    
    private class Disable extends BasicAction {
				
		public Disable (SpeedController controller, SCActivity from, SCActivity then, String name) {
			super(controller, from, then, name);
		}
				
		public void jump() {
            super.jump();
		}	
        	
	}
  
	private class Record extends BasicAction {
				
		public Record (SpeedController controller, SCActivity from, SCActivity then, String name) {
			super(controller, from, then, name);
		}
				
		public void jump() {
            super.jump();
			targetSpeed.value(speed.value());
		}	
        	
	}
	    
   public SpeedController(DoubleSource accelerator, DoubleSource speed, DoubleEndpoint targetSpeed, DoubleSink throttle){
      this.accelerator = accelerator;
      this.speed       = speed;
      this.targetSpeed = targetSpeed;
      this.throttle    = throttle;
        
      this.buildBehavior();
    
   }
    
   private void buildBehavior() {
        
      disabled = new Disabled(this);
      enabled  = new Enabled(this);
        
      disable            = new Disable       (this, enabled,  disabled, "controller disable"             );
      enable             = new Enable        (this, disabled, enabled , "controller enable"              );
      recordWhenDisabled = new Record        (this, disabled, disabled, "controller record when disabled");
      recordWhenEnabled  = new Record        (this, enabled,  enabled , "controller record when enabled" );
      record             = new OrInteraction (new Fireable[] {recordWhenDisabled, recordWhenEnabled}     );
	
      this.adapt(disabled);
    }
	
}
