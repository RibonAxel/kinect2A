package ccs;

import pi.executive.Fireable;
import pi.executive.interaction.OrInteraction;
import pi.executive.Activity;
import pi.executive.HybridAction;
import pi.executive.DefaultHybridAgent;
import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleSink;

public class Supervisor extends DefaultHybridAgent {

	public  Fireable           engineOn, engineOff, on, off, resume, brake, accelerate, record, enable, disable;

	private SupervisorActivity inactive, active, tmp1, tmp2, tmp3, tmp4, tmp5, standby, controlling;
	private SupervisorAction   engineOff_1, engineOff_2, engineOff_3;
    private SupervisorAction   on_1, on_2, on_3, record_1, record_2, disable_1, disable_2;
    private SupervisorAction   accelerate_1, accelerate_2, accelerate_3;
    private SupervisorAction   brake_1, brake_2, brake_3;
    
    private ControllerStatus   ccStatus;
    private DoubleSource       throttle;
    private DoubleSink         accelerator;  // the supervisor retro-controls accelerator when controller is enabled

   private class SupervisorActivity extends Activity {
   
      private int status = ControllerStatus.DISABLED; // visible status (DISABLED | ENABLED | STANDBY)
      
      public SupervisorActivity(int status) {
         super();
         this.status = status;
      }

      public void control( )  {
         ccStatus.setState(status);
         if (status == ControllerStatus.ENABLED) {
            double current_setting = throttle.value();
            accelerator.value(current_setting);         // "retro"-control accelerator
         }
      }

      public void delta (double dt) { }
            
   }

   private class SupervisorAction extends HybridAction {
   
      private Supervisor          supervisor;
      private SupervisorActivity  then;
      private String              name;
        
      public SupervisorAction(Supervisor supervisor, SupervisorActivity from, SupervisorActivity then, String name) {
			super(from);
			this.supervisor = supervisor;
			this.then       = then;
            this.name       = name;
      }
        
      public DefaultHybridAgent context() { return supervisor;           }
      public Activity then()              { return then;                 }
      
	}

    public Supervisor(ControllerStatus ccStatus, DoubleSource throttle, DoubleSink accelerator) {
       super();
       this.ccStatus    = ccStatus;
       this.throttle    = throttle;
       this.accelerator = accelerator;
       this.buildBehavior();
    }

	public void buildStates () {
		inactive    = new SupervisorActivity(ControllerStatus.DISABLED);
		active      = new SupervisorActivity(ControllerStatus.DISABLED);
		tmp1        = new SupervisorActivity(ControllerStatus.ENABLED);
		tmp2        = new SupervisorActivity(ControllerStatus.ENABLED);
		tmp3        = new SupervisorActivity(ControllerStatus.STANDBY);
		tmp4        = new SupervisorActivity(ControllerStatus.DISABLED);
		tmp5        = new SupervisorActivity(ControllerStatus.ENABLED);
		standby     = new SupervisorActivity(ControllerStatus.STANDBY);
		controlling = new SupervisorActivity(ControllerStatus.ENABLED);
	}
    
	public void buildTransitions() {		
    
		engineOn    = new SupervisorAction(this, inactive,    active,      "supervisor engine on"   );
		engineOff_1 = new SupervisorAction(this, active,      inactive,    "supervisor engine off 1");
		accelerate_1= new SupervisorAction(this, active,      active,      "supervisor accelerate 1");
		brake_1     = new SupervisorAction(this, active,      active,      "supervisor brake 1"     );
		on_1        = new SupervisorAction(this, active,      tmp1,        "supervisor on 1"        );
		record_1    = new SupervisorAction(this, tmp1,        tmp2,        "supervisor record 1"    );
		enable      = new SupervisorAction(this, tmp2,        controlling, "supervisor enable"      );
        
		off         = new SupervisorAction(this, controlling, tmp3,        "supervisor off"         );
		accelerate_2= new SupervisorAction(this, controlling, tmp3,        "supervisor accelerate 2");
		brake_2     = new SupervisorAction(this, controlling, tmp3,        "supervisor brake 2"     );
		engineOff_2 = new SupervisorAction(this, controlling, tmp4,        "supervisor engine off 2");
		on_2        = new SupervisorAction(this, controlling, tmp5,        "supervisor on 2"        );
		record_2    = new SupervisorAction(this, tmp5,        controlling, "supervisor record 2"    );

		disable_2   = new SupervisorAction(this, tmp3,       standby,      "supervisor disable 2"   );        
		accelerate_3= new SupervisorAction(this, standby,    standby,      "supervisor accelerate 3");
		brake_3     = new SupervisorAction(this, standby,    standby,      "supervisor brake 3"     );
		on_3        = new SupervisorAction(this, standby,    tmp1,         "supervisor on 3"        );
		resume      = new SupervisorAction(this, standby,    tmp2,         "supervisor resume"      );
		engineOff_3 = new SupervisorAction(this, standby,    inactive,     "supervisor engine off 3");

		disable_1   = new SupervisorAction(this, tmp4,       inactive,     "supervisor disable_1"   );
		
		engineOff   = new OrInteraction(new Fireable[] {engineOff_1, engineOff_2, engineOff_3    });
		on          = new OrInteraction(new Fireable[] {on_1, on_2, on_3                         });
		record      = new OrInteraction(new Fireable[] {record_1, record_2                       });
		disable     = new OrInteraction(new Fireable[] {disable_1, disable_2                     });
		accelerate  = new OrInteraction(new Fireable[] {accelerate_1, accelerate_2, accelerate_3 });
		brake       = new OrInteraction(new Fireable[] {brake_1, brake_2, brake_3                });
	}
    
    public void buildBehavior() {
       buildStates();
       buildTransitions();
       adapt(inactive);
    }

}
