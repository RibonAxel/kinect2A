//  User.java
//  Created by Bernard Thirion on Fri May 21 2004.

package ccs;

import java.io.PrintStream;

import pi.executive.Fireable;
import pi.executive.DefaultDiscreteAgent;
import pi.executive.State;
import pi.io.InputAction;
import pi.io.IOEvent;
import pi.endpoint.DoubleSink;

public class User extends DefaultDiscreteAgent {

   private DoubleSink  accelerator;
   
   private class UserState extends State { }
   public class UserAction extends InputAction {
      private User   context;
      private State  then;
      private String name; // for debugging
      
      public UserAction (User context, IOEvent event, State from, State then, String name) {
         super(event, from);
         this.context = context;
         this.then    = then;
         this.name    = name;
      }
   
      public DefaultDiscreteAgent context() { return context;          }
      public State then()                   { return then;             }      
      public void jump()                    {                          }

   }
 
   private class Brake extends UserAction {      
      public Brake (User context, IOEvent event, State from, State then, String name) {
         super(context, event, from, then, name);
      }
      
      public void jump() {
         super.jump();
         accelerator.value(0);
      }
   }
   
   private class EngineOff extends UserAction {      
      public EngineOff (User context, IOEvent event, State from, State then, String name) {
         super(context, event, from, then, name);
      }
      
      public void jump() {
         super.jump();
         accelerator.value(0);
      }
   }

   public Fireable  on, off, resume, accelerate, brake, engineOn, engineOff;
   
   private UserState state;
   
   public User (GUIEvents guiEvents, DoubleSink accelerator) {
      this.accelerator = accelerator;
      state            = new UserState();
      on               = new UserAction (this, guiEvents.on,         state, state, "user on"        ); 
      off              = new UserAction (this, guiEvents.off,        state, state, "user off"       ); 
      resume           = new UserAction (this, guiEvents.resume,     state, state, "user resume"    ); 
      accelerate       = new UserAction (this, guiEvents.accelerate, state, state, "user accelerate"); 
      brake            = new Brake      (this, guiEvents.brake,      state, state, "user brake"     ); 
      engineOn         = new UserAction (this, guiEvents.engineOn,   state, state, "user engine on" ); 
      engineOff        = new EngineOff  (this, guiEvents.engineOff,  state, state, "user engine off"); 
      this.adapt(state);
   }
      
}
