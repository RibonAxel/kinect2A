package ccs;

import pi.executive.Fireable;
import pi.executive.interaction.RendezVous;
import pi.executive.SchedulingOrder;
import pi.container.Container;
import pi.container.CompositeContainer;
import pi.application.Application;

public class TestCCS {

   public static void test() {
     
      Simulator        simulator = new Simulator ();        
      CruiseController cc        = new CruiseController(simulator.speed, simulator.throttle);
      UserInterface    itf       = new UserInterface(simulator.speed, cc.targetSpeed, cc.accelerator, cc.ccStatus);

      Fireable engineOn          = new RendezVous(new Fireable[] {itf.engineOn,   cc.engineOn  });
      Fireable engineOff         = new RendezVous(new Fireable[] {itf.engineOff,  cc.engineOff });
      Fireable on                = new RendezVous(new Fireable[] {itf.on,         cc.on        });
      Fireable off               = new RendezVous(new Fireable[] {itf.off,        cc.off       });
      Fireable resume            = new RendezVous(new Fireable[] {itf.resume,     cc.resume    });
      Fireable brake             = new RendezVous(new Fireable[] {itf.brake,      cc.brake     });
      Fireable accelerate        = new RendezVous(new Fireable[] {itf.accelerate, cc.accelerate});

      CompositeContainer C       = new CompositeContainer(); 
           
      C.addMembers    (new Container[] {simulator, cc, itf});
      C.addConstraint (new SchedulingOrder(simulator.car, cc.controller));
      
      Application A = new Application(C, cc.DELTA, 0.002);
      
      A.start();        
	}
}
