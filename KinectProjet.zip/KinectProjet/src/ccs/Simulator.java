//  Simulator.java
//  Created by Bernard Thirion on 3/04/07.

package ccs;

import pi.executive.Fireable;
import pi.executive.interaction.RendezVous;
import pi.endpoint.DoubleValue;

import pi.executive.Agent;
import pi.executive.Constraint;
import pi.container.Container;

import vanderpol.VanderpolGenerator;

public class Simulator extends Container {

   public CarSimulation car;
   public DoubleValue   throttle, speed;
   
   private VanderpolGenerator perturbationGenerator;
  
   public Simulator () {
      throttle                 = new DoubleValue();
      speed                    = new DoubleValue();
      DoubleValue perturbation = new DoubleValue();
      perturbationGenerator    = new VanderpolGenerator(perturbation, 0.3, 1.0, 3.0);
      car                      = new CarSimulation(throttle, perturbation, speed);
   }

   public int agentCount() { return 1 + perturbationGenerator.agentCount(); }
   
   public Agent agent(int index) {
      switch (index) {
         case   0: return car;
         default   : return perturbationGenerator.agent(index - 1);
      }
   }
   
   public int constraintCount() {
      return perturbationGenerator.constraintCount();
   }
   
   public Constraint constraint(int index) {
      return perturbationGenerator.constraint(index);
   }


}
