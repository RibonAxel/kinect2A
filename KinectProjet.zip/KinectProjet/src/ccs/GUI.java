package ccs;

import java.awt.Frame;
import java.awt.Frame;
import java.awt.Button;
import java.awt.event.*;
import java.awt.CheckboxGroup;
import java.awt.Checkbox;
import java.awt.Scrollbar;
import pi.executive.Executive;
import pi.executive.ContinuousAgent;
import pi.io.IOEvent;
import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleEndpoint;

public class GUI extends Frame implements ContinuousAgent {

   private static final int    WIDTH      = CounterCanvas.WIDTH + 15;
   private static final int    HEIGHT     = CounterCanvas.HEIGHT + 100;
   private static final double FRAME_TIME = 0.05;
   
   private double  time       = 0;
   private boolean refresh    = true;
   private boolean engineIsOn = false;

   private Button onButton, offButton, resumeButton, brakeButton;
   private Checkbox engineOnBox, engineOffBox;
   private ButtonListener           buttonListener = new ButtonListener();
   private ItemListener             engineListener = new EngineListener();
   private AcceleratorListener acceleratorListener = new AcceleratorListener();

   private Scrollbar acceleratorBar;

   private CounterCanvas counter;

   private DoubleSource     speed, targetSpeed;
   private DoubleEndpoint   accelerator;
   private ControllerStatus ccStatus;      
   private GUIEvents        guiEvents;
   
   public GUI(GUIEvents guiEvents, DoubleSource speed, DoubleSource targetSpeed, DoubleEndpoint accelerator, ControllerStatus ccStatus) {
      this.guiEvents    = guiEvents;	
      this.speed        = speed;	
      this.targetSpeed  = targetSpeed;	
      this.accelerator  = accelerator;	
      this.ccStatus     = ccStatus;	
      counter = new CounterCanvas(0, 20); add(counter);
      setLayout(null);
      setTitle ("Cruise Controller");
      setSize(WIDTH, HEIGHT);
      setResizable(false);
      addControllerButtons();
      addEngineButtons    ();
      addPedalWidgets     ();
      addQuitButton       ();
      this.setVisible     (true);
   }
      
   private void addQuitButton () {
      Button B = new Button ();
      B.setLabel ("done");
      B.setBounds(290,445,80,23);
      B.addActionListener(new Quit());
      add(B); 	
   }

   private class Quit implements ActionListener {
      public void actionPerformed (ActionEvent e) {
         System.exit(0);
      }          
   }
   
   private void addControllerButtons () {
      offButton = new Button ();
      offButton.setLabel("off");
      offButton.setBounds(50,410,40,23);
      offButton.addMouseListener(buttonListener);
      add(offButton); 	
      onButton = new Button ();
      onButton.setLabel("on");
      onButton.setBounds(5,410,40,23);
      onButton.addMouseListener(buttonListener);
      add(onButton); 	
      resumeButton = new Button ();
      resumeButton.setLabel("resume");
      resumeButton.setBounds(95,410,60,23);
      resumeButton.addMouseListener(buttonListener);
      add(resumeButton); 	
   }
   
   private void addPedalWidgets () {
      brakeButton = new Button ();
      brakeButton.setLabel ("brake");
      brakeButton.setBounds(290,410,80,23);
      brakeButton.addMouseListener(buttonListener);
      add(brakeButton); 	
      acceleratorBar = new Scrollbar(Scrollbar.VERTICAL, 0, 1, 0, 1001);   
      acceleratorBar.setBounds(CounterCanvas.WIDTH, 20, 15, CounterCanvas.HEIGHT);
      add(acceleratorBar);
      acceleratorBar.addAdjustmentListener(acceleratorListener);
   }
   
   private void addEngineButtons () {
      CheckboxGroup buttons = new CheckboxGroup();
      engineOffBox = new Checkbox("engine off", buttons, true);
      engineOffBox.setBounds(15,445,100,23);
      engineOffBox.addItemListener(engineListener);
      add(engineOffBox); 
      engineOnBox = new Checkbox("engine on", buttons, false);
      engineOnBox.setBounds(115,445,100,23);
      engineOnBox.addItemListener(engineListener);
      add(engineOnBox); 
   }
   
   private class ButtonListener extends MouseAdapter  {
      public void mousePressed (MouseEvent e) {
         if (e.getSource() == onButton        ) guiEvents.on.present(); 
	   	 if (e.getSource() == offButton       ) guiEvents.off.present(); 
	   	 if (e.getSource() == resumeButton    ) guiEvents.resume.present();
	   	 if (e.getSource() == brakeButton     ) guiEvents.brake.present();
      }    
            
      public void mouseReleased (MouseEvent e) {
         if (e.getSource() == onButton        ) guiEvents.on.absent();
	   	 if (e.getSource() == offButton       ) guiEvents.off.absent();
	   	 if (e.getSource() == resumeButton    ) guiEvents.resume.absent();
	   	 if (e.getSource() == brakeButton     ) guiEvents.brake.absent();
      }                  
   }
   
   private class EngineListener implements ItemListener {
      public void itemStateChanged (ItemEvent e) { 
      
         if (!engineIsOn &&(e.getSource() == engineOnBox)) {
            guiEvents.engineOff.absent();
            guiEvents.engineOn.present();
            counter.engineOn();
            engineIsOn = true;
         }
         
         if (engineIsOn && (e.getSource() == engineOffBox)) {
             guiEvents.engineOn.absent();
             guiEvents.engineOff.present();
             counter.engineOff();
             engineIsOn = false;                    
         }
          
      }  
   }
   
   private class AcceleratorListener implements AdjustmentListener {
    	public void adjustmentValueChanged (AdjustmentEvent e) {
            if (engineIsOn) {
	  		   double a = (1000.0 - acceleratorBar.getValue()) / 1000.0;
               guiEvents.accelerate.present();
               accelerator.value(a); 
            }           
		}        
   }
   
   private synchronized void refresh () {
      counter.setSpeed(speed.value());
      counter.setTargetSpeed(targetSpeed.value());
      counter.setControllerStatus(ccStatus.state());
      counter.update();
      acceleratorBar.setValue(1000 - (int)(accelerator.value()*1000));
   }

   public void control () { 
      if (refresh) {
         this.refresh();
         refresh = false;
      }
   }
   
   public void delta (double dt) {
      time = time + dt;
      if (time >= FRAME_TIME) {
         refresh = true;
         while (time >= FRAME_TIME) time = time - FRAME_TIME;
      }
    }
    
}
