//  IO.java
//  Created by Bernard Thirion on 3/04/07.

package ccs;

import pi.executive.Fireable;
import pi.endpoint.DoubleSource;
import pi.endpoint.DoubleEndpoint;

import pi.executive.Agent;
import pi.executive.SchedulingOrder;
import pi.container.Container;

public class UserInterface extends Container {
   
   public Fireable  engineOn, engineOff, on, off, resume, brake, accelerate;

   private  GUI       gui;
   private  User      user;
     
   public UserInterface (DoubleSource speed, DoubleSource targetSpeed, DoubleEndpoint accelerator, ControllerStatus ccStatus) {
      GUIEvents guiEvents = new GUIEvents();
      gui                 = new GUI (guiEvents, speed, targetSpeed, accelerator, ccStatus);
      user                = new User(guiEvents, accelerator);
      this.exportActions();
   }

   private void exportActions() {
      engineOn   = user.engineOn;
      engineOff  = user.engineOff;
      on         = user.on; 
      off        = user.off;
      resume     = user.resume;
      brake      = user.brake;
      accelerate = user.accelerate;
   }

   public int agentCount() { return 2; }
   
   public Agent agent(int index) {
      switch (index) {
         case   0: return user;
         case   1: return gui;
         default : return null;
      }
   }

}

