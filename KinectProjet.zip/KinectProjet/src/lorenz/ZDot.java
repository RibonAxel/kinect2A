//  YDot.java
//  Created by Bernard Thirion on 21/03/07.

//  z' = xy -bz
 
package lorenz;

import pi.endpoint.DoubleSource;

public class ZDot implements DoubleSource {

   private DoubleSource X, Y, Z;
   private double b;

   public ZDot(DoubleSource X, DoubleSource Y, DoubleSource Z, double b) {
      this.X  = X; 
      this.Y  = Y; 
      this.Z  = Z; 
      this.b  = b;
   }

   public double value() {
      return X.value() * Y.value() - b * Z.value();
   }

}
