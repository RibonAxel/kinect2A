//  LorenzGenerator.java
//  Created by Bernard Thirion on 23/03/07.
//
//  x' = a(y-x)
//  y' = x(c-z) - y
//  z' = xy -bz
//

package lorenz;

import pi.endpoint.DoubleEndpoint;
import pi.endpoint.DoubleValue;
import pi.continuous.Integrator;

import pi.executive.Agent;
import pi.container.Container;

public class LorenzGenerator extends Container {

   private Integrator  IX, IY, IZ;
   private XDot        XD;
   private YDot        YD;
   private ZDot        ZD;
   
   public LorenzGenerator (DoubleEndpoint X, DoubleEndpoint Y, DoubleEndpoint Z,
                              double a, double b, double c) {
       XD = new XDot(X, Y, a); 
       YD = new YDot(X, Y, Z, c); 
       ZD = new ZDot(X, Y, Z, b);
       IX = new Integrator(XD, X ,  10.0);   
       IY = new Integrator(YD, Y , -10.0);   
       IZ = new Integrator(ZD, Z ,  10.0);   
   }

   public int agentCount() { return 3; }
   
   public Agent agent(int index) {
      switch (index) {
         case   0: return IX;
         case   1: return IY;
         case   2: return IZ;
         default : return null;
      }
   }

}
