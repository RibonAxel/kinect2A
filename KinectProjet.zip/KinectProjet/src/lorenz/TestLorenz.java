//  TestLorenz.java
//  Created by Bernard Thirion on 23/03/07.

package lorenz;

import pi.endpoint.DoubleValue;
import pi.endpoint.DoubleValueWithPut;

import pi.container.Container;
import pi.container.SimpleContainer;
import pi.container.CompositeContainer;
import pi.application.Application;

import oscillo.Oscilloscope;

public class TestLorenz {
   
   public static void test() {
      DoubleValue       X = new DoubleValue();           
      DoubleValue       Y = new DoubleValue();           
      DoubleValue       Z = new DoubleValue();           
      LorenzGenerator   L = new LorenzGenerator(X, Y, Z, 10.0, 8.0/3.0, 25.0);

      SimpleContainer   OY = new SimpleContainer(new Oscilloscope(Y, "Lorenz Y"));
      SimpleContainer   OZ = new SimpleContainer(new Oscilloscope(Z, "Lorenz Z"));
      
      CompositeContainer C = new CompositeContainer();
      
      C.addMembers (new Container[] {L, OY, OZ});
      
      Application              A = new Application(C, 0.02, 0.001);
      
      A.start();        
    }
   
}