//  XDot.java
//  Created by Bernard Thirion on 23/03/07.

//  x' = a(y-x)
 
package lorenz;

import pi.endpoint.DoubleSource;

public class XDot implements DoubleSource {

   private DoubleSource X, Y;
   private double a;

   public XDot(DoubleSource X, DoubleSource Y, double a) {
      this.X  = X; 
      this.Y  = Y; 
      this.a  = a;
   }

   public double value() {
      return a * (Y.value() - X.value());
   }

}
