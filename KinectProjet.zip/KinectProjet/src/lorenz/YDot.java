//  YDot.java
//  Created by Bernard Thirion on 21/03/07.

//  y' = x(c-z) - y
 
package lorenz;

import pi.endpoint.DoubleSource;

public class YDot implements DoubleSource {

   private DoubleSource X, Y, Z;
   private double c;

   public YDot(DoubleSource X, DoubleSource Y, DoubleSource Z, double c) {
      this.X  = X; 
      this.Y  = Y; 
      this.Z  = Z; 
      this.c  = c;
   }

   public double value() {
      return X.value() * (c - Z.value())  - Y.value();
   }

}
