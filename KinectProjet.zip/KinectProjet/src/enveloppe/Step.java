// Created by BB on 11/05/11

package enveloppe;

public class Step extends Enveloppe {

	

	
	public Step(double startTime, double endTime, double value) {
		super(startTime, endTime, value);
	}

	public void open() {}
	
	@Override
	protected void majValue(double dt) {}

}
