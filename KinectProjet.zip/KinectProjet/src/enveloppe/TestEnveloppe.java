// Created by BB on 11/05/11

package enveloppe;

import generators.SignalGenerator;
import oscillo.DMXOscilloscope;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.AdaptaterDoubleValueToDMXValue;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;

public class TestEnveloppe {

	public static void test() {
		
		 try 
		 {
			 DoubleValue Stst = new DoubleValue();
		     SignalGenerator Gtst = new SignalGenerator(new Step(5, 10, 0.5), Stst);
		     DMXOscilloscope Otst = new DMXOscilloscope(new AdaptaterDoubleValueToDMXValue(Stst));
			
		     SimpleContainer instrument  = new SimpleContainer(new Agent[] {Gtst, Otst});
		     Application     application = new Application(instrument, 0.025, 0.005);
		  
		   
		   
		     application.start();
		}
		catch (Exception e) { e.printStackTrace();	}
	} 
}