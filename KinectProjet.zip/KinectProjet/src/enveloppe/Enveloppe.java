// Created by BB on 11/05/11

package enveloppe;

import generators.signal.Signal;

public abstract class Enveloppe extends Signal {

	private double keepValue = 0;
	private double startTime=0;
	private double time =0;
	private double endTime=0;
	private boolean run = false;
	private boolean atEnd = false;
	
	
	public Enveloppe(double startTime, double endTime, double value)
	{
		this.value = 0;
		this.keepValue = value;
		this.startTime = startTime;
		this.endTime = endTime;
		if(this.startTime==0)
		{
			start();
		}
	}
	
	public void start()
	{
		this.run = true;
		this.value = this.keepValue;
	}
	public void stop()
	{
		this.run = false;
		this.atEnd = true;
		this.value =0;
	}
	
	public boolean run()
	{
		return run;
	}
	

	public void delta(double dt) {
		tick(dt);	
		majValue(dt);
		
	}
	
	protected abstract void majValue(double dt);
	
	protected void tick(double dt) {
		if(this.endTime>0)	
		{
			this.time+= dt;
			if(this.time < this.endTime && this.time > this.startTime && !this.run() )
			{
				this.start();
			}
			if(this.run() && this.time > this.endTime)
			{
				this.stop();
			}
		}
		else
		{
			this.start();
		}
	}

	public boolean atEnd() 
	{
		return this.atEnd;
	}
}
