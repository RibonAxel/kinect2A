package graphics.shapes;

import graphics.shapes.attributes.Attributes; //Pour utiliser la fonction getAttributes
import java.awt.Point;  //Importe tous pour pouvoir faire appel aux fonctions de ces classes
import java.awt.Rectangle;
import java.util.Map;
import java.util.TreeMap;

public abstract class Shape 
{
	public static boolean isSelected = false;
	private Map attributes = new TreeMap();
	
	public void addAttributes(Attributes attributes)
	{
		this.attributes.put(attributes.getID(),attributes); 
		//On met dans la map des attributs(couleur, contour existe ...)
	}
	
	public Attributes getAttributes(String id)
	{
		return (Attributes) this.attributes.get(id);	
	}
	
	public abstract Point getLoc();
	
	public abstract void setLoc(Point point);
	
	public abstract void translate (int dx, int dy);
	
	public abstract Rectangle getBounds();
	
	public abstract void accept(ShapesVisitor SV);

	public abstract void resize(int dx, int dy);
	
}
