package graphics.shapes;


public interface ShapesVisitor {

	public void visitRectangle(SRectangle sRectangle);

	public void visitCollection(SCollection sCollection);
	
	public void visitCircle(SCircle sCircle);

	public void visitText(SText sText);
	
}
