package graphics.shapes;

//import graphics.shapes.attributes.ColorAttributes;

//import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;

public class SRectangle extends Shape {
	
	private Rectangle rect;
	
	public SRectangle(Point point,int width, int height)
	{
		this.rect = new Rectangle(point.x, point.y, width,height);
	}
	
	public Rectangle getRect()
	{
		return this.rect;
	}

	public Point getLoc()
	{
		return this.rect.getLocation();
	}
	
	public void setLoc(Point point)
	{
		this.rect.setLocation(point);
		
	}
	
	public Rectangle getBounds()
	{
		return this.rect; //(Rectangle)rect.clone();
	}
	
	public void accept(ShapesVisitor v)
	{
		v.visitRectangle(this);
	}

	public void translate(int dx, int dy) 
	{
		this.rect.translate(dx, dy);
	}

	 public void resize(int dx, int dy)
	 {
		 if(rect.width>=10 && rect.height>=10)
			 this.rect.setSize(rect.width+dx, rect.height+dy);
		 else this.rect.setSize(10, 10);
	 }
}
