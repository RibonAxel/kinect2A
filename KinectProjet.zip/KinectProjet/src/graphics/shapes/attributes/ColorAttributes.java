package graphics.shapes.attributes;

import java.awt.Color;

public class ColorAttributes extends Attributes
{

	public static final String ID="colors";
	
	public boolean filled;
	public boolean stroked;
	public Color filledColor;
	public Color strokedColor;
	
	public ColorAttributes() //Constructeur par d�faut
	{
		this.stroked = true; //Initialement le contour existe
		this.filled = false; //Initialement la forme est vide
		this.strokedColor = Color.BLACK;  //Initialement le contour est noir
		this.filledColor = Color.BLACK;  //Initialement, la couleur est noir
	}
	
	public ColorAttributes(boolean filled, boolean stroked, Color filledColor, Color strokedColor) //Constructeur 
	{
		this.filled=filled;
		this.stroked=stroked;
		this.filledColor=filledColor;
		this.strokedColor=strokedColor;
	}
	
	public String getID()
	{
		return ID;
	}

	public void setFilled (boolean filled) //On choisit de cr�er ou non la forme
	{
		this.filled = filled;
	}
	
	public void setFilledColor(Color filledColor)  //Couleur de l'int�rieur
	{
		this.filledColor = filledColor;
	}
	
	public void setStroked (boolean stroked) //Choisit de construire ou non le contour
	{
		this.stroked = stroked;
	}
	
	public void setStrokedColor(Color strokedColor) //couleur du contour
	{
		this.strokedColor = strokedColor;
	}
	
	//Pas de GetStroked/GetFilled car on voit si le contour/Int�rieur existe
}
