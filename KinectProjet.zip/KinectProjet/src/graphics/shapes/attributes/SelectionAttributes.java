package graphics.shapes.attributes;

public class SelectionAttributes extends Attributes 
{

	public static final String ID="selection"; //Donn�e Membre
	
	private boolean selected = false; //De base non s�lectionn�
	
	public String getID() //Retorune selection
	{
		return ID;
	}
	
	public boolean isSelected() //retourne boolean
	{
		return selected;
	}
	
	public void select()  //On selectionne le shape
	{
		this.selected = true;
	}
	
	public void unselect()  //On d�s�lectionne le shape
	{
		this.selected = false;
	}
	
	public void toggleSelection() //activer/d�sactiver la s�lection
	{ 
		this.selected = !selected;
	}
}
