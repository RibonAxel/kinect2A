package graphics.shapes.attributes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;

public class FontAttributes extends Attributes 
{
	//Toutes les donn�es membre
	public static final String ID="font"; //ID=font
	public Font font; 
	public static final Graphics2D DEFAULT_GRAPHICS = (Graphics2D) new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB).getGraphics();  //Cr�e graphisme par d�faut image de taile 1*1 et d�fini par 
	public Color fontColor;
	int taille=10;  //Taille initiale des mots
	
	public FontAttributes() //Constructeur par d�faut 
	{
		this.fontColor = Color.BLACK; //Couleur du texte initialement noire
		this.font = new Font("test", Font.PLAIN, taille);//Le style par d�faut
	}
	
	public String getID()
	{
		return ID; //renverra font
	}
	
	public Rectangle getBounds(String text)
	{
		FontRenderContext frc = DEFAULT_GRAPHICS.getFontRenderContext(); //Permet mesurer le texte
		return getFont().getStringBounds(text, frc).getBounds(); //Permet retourner getBound rectangle autour du texte "text"
	}
	
	public Font getFont()
	{
		return this.font;
	}
	
	public void setFont(float texte) //Cr�e le texte souhait�
	{
		this.font = new Font("texte",Font.PLAIN,taille);
	}
	
	public Color getColor()
	{
		return this.fontColor;
	}

	public void setAttributes(int i) //Cr�e � la taille souhait�
	{
		this.font = new Font("",Font.PLAIN,i);
	}	
} 
