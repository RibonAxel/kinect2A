package graphics.shapes.ui;

import graphics.shapes.SCircle;
import graphics.shapes.SCollection;
import graphics.shapes.SRectangle;
import graphics.shapes.SText;
import graphics.shapes.Shape;
import graphics.shapes.ShapesVisitor;
import graphics.shapes.attributes.ColorAttributes;
import graphics.shapes.attributes.FontAttributes;
import graphics.shapes.attributes.SelectionAttributes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.Iterator;

public class ShapesDraftman implements ShapesVisitor{
	
	private Graphics2D g;
	public static final ColorAttributes DEFAULT_COLOR_ATTRIBUTES = new ColorAttributes();
	public static final FontAttributes DEFAULT_FONT_ATTRIBUTES = new FontAttributes();
	public static final  int HANDLER_SIZE = 2000000;
	
	void setGraphics(Graphics2D g)
	{
		this.g = g;
	}
	
	 public void selectedShape(Shape e)
	 {
		 SelectionAttributes s = (SelectionAttributes)e.getAttributes("selection");
		 if (s.isSelected())
		 {
			 g.setColor(Color.BLACK);
			 g.drawRect(e.getBounds().x - 4, e.getBounds().y - 4, 4, 4);
			 g.drawRect(e.getBounds().x + e.getBounds().width, e.getBounds().y +
					 e.getBounds().height, 4, 4);
		 }
	 }
	
	public void visitRectangle(SRectangle srectangle) 
	{
		System.out.println("I'm drawing a Rectangle");
		Rectangle rect = srectangle.getBounds();
		
		ColorAttributes ca = (ColorAttributes)srectangle.getAttributes(ColorAttributes.ID);
		SelectionAttributes sa = (SelectionAttributes)srectangle.getAttributes(SelectionAttributes.ID);
		
		if(ca== null) //Si Couleur n'existe pas(blanc)
		{
			ca = DEFAULT_COLOR_ATTRIBUTES;
		}
		
		if(ca.filled)//Couleur de l'int�rieur
		{
			g.setColor(ca.filledColor);
			g.fillRect(rect.x, rect.y, rect.width, rect.height);
		}
		if(ca.stroked)//Couleur du contour
		{
			g.setColor(ca.strokedColor);
			g.drawRect(rect.x, rect.y, rect.width, rect.height);
		}
		
		if(((SelectionAttributes)srectangle.getAttributes("selection")).isSelected())
		{
			selectedShape(srectangle);
		}
		
	}

	public void visitCollection(SCollection scollection) 
	//accept une � une les formes de la collection
	{
		for(Iterator<Shape> iterator = scollection.list().iterator(); iterator.hasNext();){
			iterator.next().accept(this);
		}
		
		if(((SelectionAttributes)scollection.getAttributes("selection")).isSelected()){
			selectedShape(scollection);
		}
			
		
	}

	public void visitCircle(SCircle scircle) 
	{
		System.out.println("I'm drawing a Circle");
		Rectangle rect = scircle.getBounds();
		
		ColorAttributes ca = (ColorAttributes)scircle.getAttributes(ColorAttributes.ID);
		if(ca== null)
		{
			ca = DEFAULT_COLOR_ATTRIBUTES;
		}
		
		if(ca.filled)
		{
			g.setColor(ca.filledColor);
			g.fillOval(rect.x, rect.y, rect.width, rect.height);
		}
		if(ca.stroked)
		{
			g.setColor(ca.strokedColor);
			g.drawOval(rect.x, rect.y, rect.width, rect.height);
		}
		
		if(((SelectionAttributes)scircle.getAttributes("selection")).isSelected())
		{
			selectedShape(scircle);
		}
	}

	public void visitText(SText stext) 
	{
		System.out.println("I'm writting a Text");
		Rectangle rect = stext.getBounds();
		
		ColorAttributes ca= (ColorAttributes)stext.getAttributes(ColorAttributes.ID);
		
		if(ca==null)
		{
			ca = DEFAULT_COLOR_ATTRIBUTES;
		}
		
		if(ca.filled)
		{
			g.setColor(ca.filledColor);
			g.fillRect(rect.x, rect.y, rect.width, rect.height);
		}
		
		if(ca.stroked){
			g.setColor(ca.strokedColor);
			g.drawRect(rect.x,  rect.y,  rect.width,  rect.height); 
			//Dessine le rectangle
		}
		
		FontAttributes fa=(FontAttributes)stext.getAttributes(FontAttributes.ID);
		if(fa==null)
			//Cas o� il n'y a pas de police de caract�re d�fini
		{
			fa = DEFAULT_FONT_ATTRIBUTES;
		}
		else
		{
			g.setColor(fa.fontColor);
			g.setFont(fa.getFont());
			g.drawString(stext.getText(),  stext.getLoc().x,  stext.getLoc().y);
		}
		
		//Sert a afficher le contour
		if(((SelectionAttributes)stext.getAttributes("selection")).isSelected())
		{
			selectedShape(stext);
		}
	}
	
}
