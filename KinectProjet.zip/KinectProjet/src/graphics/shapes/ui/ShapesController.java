package graphics.shapes.ui;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.util.Iterator;
import java.util.Scanner;

import graphics.shapes.SCircle;
import graphics.shapes.SCollection;
import graphics.shapes.SRectangle;
import graphics.shapes.Shape;
import graphics.shapes.attributes.ColorAttributes;
import graphics.shapes.attributes.SelectionAttributes;
import graphics.ui.Controller;

public class ShapesController extends Controller {
	
	private int lastClickX;
	private int lastClickY;
	
	SCollection col = (SCollection) this.getModel();

	public ShapesController(Object newModel) 
	{
		super(newModel);
	}

	public void mousePressed(MouseEvent e)
	{
		this.lastClickX=e.getX();
	 	this.lastClickY=e.getY();
	 	 
	 	 if (e.getButton() == 1) //Si on presse le bouton 1(gauche)
	 			 {
	 		 for (Iterator it= col.iterator();it.hasNext();)
	 			 //v�rifie si la collection a une forme suivante
	 		 	{
	 	 	 Shape s = (Shape) it.next();
	 	 	 SelectionAttributes sa = (SelectionAttributes) s.getAttributes("selection");
	 	 	 if (s.getBounds().contains(e.getX(), e.getY())) 
	 	 	 {
	 	 	 	 if (e.isShiftDown()) sa.toggleSelection();
	 	 	 	 //Active la s�lection
	 	 	 	 else
	 	 	 	 	 sa.select();
	 	 	 	 	 System.out.println("selection");
	 	 	 }
	 	 	 else
	 	 	 {
	 	 	 	 if (!e.isShiftDown())
	 	 	 	 	 sa.unselect();
	 	 	 	 	 System.out.println("deselection");
	 	 	 }
	 		 	}
	 	 	 	 super.getView().repaint();
	 			 }	
	 }
	
	public void mouseReleased(MouseEvent e)
	{
		System.out.println("mouse released");
		
	}

	public void mouseClicked(MouseEvent e)
	{
		Point point = e.getPoint();
		
		if(!shiftDown()) unselectAll();
	}
	
	public void mouseEntered(MouseEvent e)
	{
		super.getView().requestFocus();
	}

	public void mouseExited(MouseEvent e)
	{
	}
	
	public void mouseMoved(MouseEvent e)
	{
		
	}
	
	public void mouseDragged(MouseEvent e)
	{
		
		int x = e.getX();
		int y = e.getY();
		
		int dx = x-lastClickX;
		int dy = y-lastClickY;
		 
	 	 if(e.isControlDown()) //Si la touche ctrl est selectionn�
	 	 {
	 	 	 for (Iterator it= col.iterator();it.hasNext();) 
	 	 	 {
	 	 	 	 Shape s = (Shape) it.next();
	 	 	 	 if(((SelectionAttributes) s.getAttributes("selection")).isSelected())
	 	 	 	 {
	 	 	 		 s.resize(dx,dy); 
	 	 	 		 //Si ctrl est enfonc� et que la forme est s�lectionn� on appelle la fonction resize 
	 	 	 	 }
	 	 	 }
	 	 }
	 	 else{
	 	 	 for (Iterator it= col.iterator();it.hasNext();) 
	 	 	 {
	 	 	 	 Shape s = (Shape) it.next();
	 	 	 	 if(((SelectionAttributes) s.getAttributes("selection")).isSelected())
	 	 	 	 s.translate(dx,dy);
	 	 	 }
	 	 }
	 	 
	 	 this.lastClickX = x;
	 	 this.lastClickY = y;
	 	 
	 	 super.getView().repaint(); //On 'repeint' la forme
	}
	
	public void keyTyped(KeyEvent evt)
	{
		//Fonction pour changer rapidement de couleur
		System.out.println("key typed");
		for (Iterator it= col.iterator();it.hasNext();) 
		{
	 	 	 Shape s = (Shape) it.next();
	 	 	 if (((SelectionAttributes) s.getAttributes("selection")).isSelected())
	 	 	 {
				 if (evt.getKeyChar() == 'r')
				 {
					 s.addAttributes(new ColorAttributes(true,false,Color.RED,Color.RED));
				 }
				 else if (evt.getKeyChar() == 'b')
				 {
					 s.addAttributes(new ColorAttributes(true,false,Color.BLUE,Color.BLUE));
				 }
				 else if (evt.getKeyChar() == 'v')
				 {
					 s.addAttributes(new ColorAttributes(true,false,Color.GREEN,Color.GREEN));
				 }
				 else if (evt.getKeyChar() == 'j')
				 {
					 s.addAttributes(new ColorAttributes(true,false,Color.YELLOW,Color.YELLOW));
				 }
				 else if (evt.getKeyChar() == 'o')
				 {
					 s.addAttributes(new ColorAttributes(true,false,Color.ORANGE,Color.ORANGE));
				 }
			 
	 	 	 }
	 	 	 super.getView().repaint();
		}
	}

	public void keyPressed(KeyEvent evt)
	{
		System.out.println("key pressed");
	}

	public void keyReleased(KeyEvent evt)
	{
		System.out.println("key released");
	}
}
