package graphics.shapes.ui;

import graphics.shapes.attributes.ColorAttributes;
import graphics.shapes.attributes.FontAttributes;
import graphics.shapes.attributes.SelectionAttributes;
import graphics.shapes.SCircle;
import graphics.shapes.SCollection;
import graphics.shapes.SRectangle;
import graphics.shapes.SText;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.JFrame;

public class Editor extends JFrame 
{

    private static final long serialVersionUID = 1L;

    ShapesView sview;
	public static SCollection model;

    public Editor() 
    {
        super("Shapes Editor");

        this.addWindowListener(new java.awt.event.WindowAdapter() 
        {
            public void windowClosing(java.awt.event.WindowEvent evt) 
            {
                System.exit(0);
            }
        });

        this.buildModel();

        this.sview = new ShapesView(Editor.model);
        this.sview.setPreferredSize(new Dimension(700, 720));
        this.getContentPane().add(this.sview, BorderLayout.CENTER);
    }

	private void buildModel() 
    {
        Editor.model = new SCollection();
        Editor.model.addAttributes(new SelectionAttributes());
    }

	public static void buildRectangle() {
        SRectangle r1 = new SRectangle(new Point(10, 10), 20, 30);
        r1.addAttributes(new ColorAttributes(true, true, Color.BLUE, Color.BLACK));
        r1.addAttributes(new SelectionAttributes());
        Editor.model.add(r1);
	}

	public static void buildCircle() {
        SCircle c = new SCircle(new Point(200, 200), 10);
        c.addAttributes(new ColorAttributes(false, true, Color.BLUE, Color.BLUE));
        c.addAttributes(new SelectionAttributes());
        Editor.model.add(c);
        
	}
}
