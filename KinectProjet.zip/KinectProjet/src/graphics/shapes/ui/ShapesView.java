package graphics.shapes.ui;

import java.awt.Graphics;
import java.awt.Graphics2D;
import graphics.shapes.Shape;
import graphics.ui.Controller;
import graphics.ui.View;

public class ShapesView extends View 
{
	private ShapesDraftman draftman;
	
	public ShapesView(Object model)
	{
		super(model);
		this.draftman = new ShapesDraftman();
	}

	protected void paintComponent(Graphics g) //Sert a tracer
	{
		super.paintComponent(g); //appelle la fonction paintComponent
		System.out.println("I'm printing");
		this.draftman.setGraphics((Graphics2D) g);
		Shape model = (Shape)this.getModel();
		if(model == null) return;
		
		model.accept(this.draftman);
	}

	public Controller defaultController(Object model) 
	{
		return new ShapesController(model);
	}
	
}
