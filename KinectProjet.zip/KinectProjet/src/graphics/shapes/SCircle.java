package graphics.shapes;

import java.awt.Point;
import java.awt.Rectangle;

public class SCircle extends Shape{
	
	private int radius;
	private Point loc;
	
	public SCircle(Point loc, int radius)
	{
		this.radius = radius;
		this.loc = loc;
	}
	
	public int getRadius()
	{
		return this.radius;
	}
	
	public void setRadius(int radius)
	{
		this.radius = radius;
	}
	
	public Point getLoc()
	{
		return this.loc;
	}
	
	public void setLoc(Point loc)
	{
		this.loc = loc;
	}
	
	public void translate(int dx, int dy)
	{
		this.loc.x = loc.x + dx;
		this.loc.y = loc.y + dy;
	}
	
	public Rectangle getBounds()
	{
		return new Rectangle(loc.x, loc.y, radius, radius);
	}

	public void accept(ShapesVisitor v) 
	{
		v.visitCircle(this);
	}

	public void resize(int x, int y) 
	{
		if(radius>=10) radius+=(x+y)/2;
		else radius=10;
	}
}
