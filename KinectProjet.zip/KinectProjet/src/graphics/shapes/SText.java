package graphics.shapes;

import graphics.shapes.attributes.FontAttributes;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.font.FontRenderContext;

public class SText extends Shape
{
	
	private Font font;
	private String text;
	private Point loc;
	
	public SText(Point loc, String text)
	{
		this.text = text;
		this.loc = loc;
	}
	
	public String getText()
	{
		return this.text;
	}
	
	public void setText(String text)
	{
		this.text = text;
	}
	
	public Point getLoc()
	{
		return this.loc;
	}
	
	public void setLoc(Point loc)
	{
		this.loc = loc;
	}
	
	public void translate(int dx, int dy)
	{
		this.loc.x = loc.x + dx;
		this.loc.y = loc.y + dy;
	}
	
	public Rectangle getBounds()
	{
		FontAttributes fa = (FontAttributes) this.getAttributes("font"); //Obtient la police de caract�res
		int width = (int) fa.getBounds(getText()).getWidth(); //Obtient taille et largeur du texte
		int height = (int) fa.getBounds(getText()).getHeight();
		return new Rectangle(new Point(loc.x, loc.y-(height*2/3)), new Dimension(width, (height*2)/3)); //Cr�e un nouveau rectangle autour du texte
	}
	
	public void accept(ShapesVisitor v)
	{
		v.visitText(this);
	}

	public void resize(int dx, int dy) 
	{
		FontAttributes fa = (FontAttributes) this.getAttributes("font");
	 	fa.setAttributes((dx+dy)/2);
	}
}
