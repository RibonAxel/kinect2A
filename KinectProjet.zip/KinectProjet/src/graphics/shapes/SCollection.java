package graphics.shapes;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;

public class SCollection extends Shape 
{
	
	private Iterator iterator;
	private ArrayList<Shape> list;
	private Point point;
	
	public SCollection()
	{
		list = new ArrayList<Shape>();
		iterator = list.iterator();
	}
	
	public Iterator<Shape> iterator()
	{
	 	 return list.iterator();
	 }
	
	public ArrayList<Shape> list()
	{
		return this.list;
	}
	
	public Point getLoc()
	{
		return this.point;
	}
	
	public void setLoc(Point point)
	{
		this.point = point;
	}
	
	public void translate(int dx, int dy)
	{
		for(Shape s:list)
		{
	 	 	 s.translate(dx, dy);
	 	 }
	 	 
	}
	
	public Rectangle getBounds()
	{		
		 Rectangle r = null; //instanciation rectangle
	 	 for(Shape s:list)
	 	 {
	 	 	 if(r == null)
	 	 	 {
	 	 	 	 r = new Rectangle(s.getBounds());
	 	 	 }
	 	 	 else
	 	 	 {
	 	 	 	 r = r.union(s.getBounds());
	 	 	 }
	 	 }
	 	 return r;
	}
	
	public void accept(ShapesVisitor v)
	{
		v.visitCollection(this);
	}

	public void add(Shape shape) 
	{
		list.add(shape);
	}
	
	public void clear()
	{
		list.removeAll(list);
	}
	
	public void delete(Shape s)
	{
		list.remove(s);
	}
	
	public void resize(int x, int y) 
	{
		for(Shape s:list)
		{
	 	 	 s.resize(x, y);
	 	 }
	}
}
