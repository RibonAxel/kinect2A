package graphics.ui;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;

import graphics.shapes.Shape;

public class Controller implements MouseListener, MouseMotionListener, KeyListener
{
	
	protected Object model;
	private View view;
	private Shape target;
	
	public Controller(Object newModel)
	{
		model = newModel;
	}
	
	public void setView(View view)
	{
		this.view = view;
	}
	
	final public View getView()
	{
		return this.view;
	}
	
	public void setModel(Object model)
	{
		this.model = model;
	}
	
	public Object getModel()
	{
		return this.model;
	}
	
	public void unselectAll() 
	{
		
	}
	
	public boolean shiftDown() //True si presse shift
	{
		return false;
	}
	
	
	public void mousePressed(MouseEvent e)
	{
		
	}
	
	public void mousewheel(MouseWheelEvent e)
	{
		
	}

	public void mouseReleased(MouseEvent e)
	{
		
	}

	public void mouseClicked(MouseEvent e)
	{
		
	}
	
	public void mouseEntered(MouseEvent e)
	{
		
	}

	public void mouseExited(MouseEvent e)
	{
		
	}
	
	public void mouseMoved(MouseEvent evt)
	{
		
	}
	
	public void mouseDragged(MouseEvent evt)
	{
		
	}
	
	public void keyTyped(KeyEvent evt)
	{
		
	}
	
	public void keyPressed(KeyEvent evt)
	{
		
	}

	public void keyReleased(KeyEvent evt)
	{
		
	}

}
