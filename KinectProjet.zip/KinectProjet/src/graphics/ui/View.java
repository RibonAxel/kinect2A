package graphics.ui;

//import graphics.shapes.Shape;

//import java.awt.Graphics;

import javax.swing.JPanel;


public abstract class View extends JPanel
{

	private Object model;
	private Controller controller;

	public View(Object model) //Constructeur
	{
		this.model = model;
		this.controller = defaultController(model);
		this.controller.setView(this);
		this.addMouseListener(this.controller);
		this.addMouseMotionListener(this.controller);
		this.addKeyListener(this.controller);
	}
	
	public Controller defaultController(Object model)
	{
		return new Controller(model);
	}
	
	public Controller getController()
	{
		return this.controller;
	}
	
	public void setModel(Object model)
	{
		this.model = model;
		this.controller.setModel(model);
	}
	
	public Object getModel()
	{
		return this.model;
	}
	


}


