package auto;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.startStop.StartStopValue;

import java.awt.Dimension;


public class RectangleMoove extends AutoController{

	public Interpolation iPan, iTilt;
	public StartStopValue ssBoxPan= new StartStopValue(), ssBoxTilt = new StartStopValue();
	public PolymorphValue pBoxPan = new PolymorphValue(), pBoxTilt  = new PolymorphValue();
	
	public double width, height, panStart, tiltStart;
	public double traceTime, elapsedTime;
	public boolean invertPan=false, invertTilt=false;
	
	
	public RectangleMoove(double panStart, double tiltStart, double border, double traceTime){
		this(panStart, tiltStart, border, border, traceTime);
	}
	
	public RectangleMoove(double panStart, double tiltStart, double width, double height, double traceTime)
	{
		this.width = width;
		this.height = height;
		this.traceTime = traceTime;
		this.elapsedTime = 0;
		this.panStart = panStart;
		this.tiltStart = tiltStart;
		
		iPan = new Interpolation(panStart, panStart+width, traceTime/4, pBoxPan, ssBoxPan);
		iTilt = new Interpolation(tiltStart, tiltStart+height, traceTime/4, pBoxTilt, ssBoxTilt);
	}
	
	public StartStopValue getssBoxPan(){
		return this.ssBoxPan;
	}
	public PolymorphValue getpBoxPan(){
		return this.pBoxPan;
	}
	public StartStopValue getssBoxTilt(){
		return this.ssBoxTilt;
	}
	public PolymorphValue getpBoxTilt(){
		return this.pBoxTilt;
	}
	public void setpBoxPan(PolymorphValue pBoxPan){
		this.pBoxPan = pBoxPan;
	}
	public void setssBoxPan(StartStopValue ssBoxPan){
		this.ssBoxPan = ssBoxPan;
	}
	public void setpBoxTilt(PolymorphValue pBoxTilt){
		this.pBoxTilt = pBoxTilt;
	}
	public void setssBoxTilt(StartStopValue ssBoxTilt){
		this.ssBoxTilt = ssBoxTilt;
	}
	

	@Override
	public void restartMove(){
		this.elapsedTime = 0;
		this.iPan.initMove(panStart, panStart+width, traceTime/4);
		this.iTilt.initMove(tiltStart, tiltStart+height, traceTime/4);
		invertPan = false;
		invertTilt = false;
		
	}
	
	
	@Override
	public void execute(double dt) {
		
		if(this.elapsedTime< this.traceTime/4)
		{
			this.elapsedTime++;
			iPan.execute(dt);
		}
		else if(this.elapsedTime< this.traceTime/2)
		{
			if(!invertPan)
			{
				invertPan = true;
				iPan.resetElapsedTime();
				iPan.setTarget(panStart);
			}
			this.elapsedTime++;
			iTilt.execute(dt);
		}
		else if(this.elapsedTime < (this.traceTime/2+this.traceTime/4))
		{
			if(!invertTilt)
			{
				invertTilt = true;
				iTilt.resetElapsedTime();
				iTilt.setTarget(tiltStart);
			}
			this.elapsedTime++;
			iPan.execute(dt);
		}
		else if(this.elapsedTime < this.traceTime)
		{
			this.elapsedTime++;
			iTilt.execute(dt);
		}
		else this.restartMove();
		
		
		
	}
	
	@Override
	public void delta(double dt)
	{
		this.execute(dt);
	}

	@Override
	public void control() {
		this.iPan.control();
		this.iTilt.control();
		
	}

	@Override
	public void invertMove() {
		// TODO Auto-generated method stub
		
	}

}
