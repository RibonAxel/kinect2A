package auto;

import generators.GlobalGenerator;
import generators.signal.Constant;
import generators.signal.Sinewave;
import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;
import generators.signal.startStop.StartStopController;
import generators.signal.startStop.StartStopGenerator;
import generators.signal.startStop.StartStopValue;
import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import universe.DMXUniverse;
import universe.Patch;

public class TestInterpolation {

	public static void test() {
		   
		try 
		 {
			 
			PolymorphWave c1 = new PolymorphWave(ShapeEnum.RAND);
			DoubleValue      S1 = new DoubleValue();     
			StartStopValue   TValue1 = new StartStopValue();
			PolymorphValue   PValue1 = new PolymorphValue();
			Interpolation IT1 = new Interpolation(1, 0.3, 200, PValue1, TValue1);
			GlobalGenerator  G1 = new GlobalGenerator(c1, PValue1, TValue1, S1); 
			
			
			DMXUniverse universe = new DMXUniverse();
			Patch p1 = new Patch(S1);  p1.add(255);
			
			universe.add(p1);       
			
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, IT1, L1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		 }
		catch (Exception e) { e.printStackTrace();	}	 
   }
        
}
