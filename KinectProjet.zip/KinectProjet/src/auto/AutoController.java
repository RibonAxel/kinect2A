//created by BB on 18 05 11

package auto;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.startStop.StartStopValue;
import pi.executive.ContinuousAgent;

public abstract class AutoController implements ContinuousAgent{

	protected PolymorphValue polyBox;
	protected StartStopValue startStopBox;
	
	public abstract void execute(double dt);
	public abstract void restartMove();
	public abstract void invertMove();
	
	@Override
	public abstract void control();

	@Override
	public void delta(double dt)
	{
		this.execute(dt);
	}

	
}
