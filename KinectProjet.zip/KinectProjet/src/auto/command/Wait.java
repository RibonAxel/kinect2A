//created by BB on 19 05 11

package auto.command;


public class Wait extends TimedCommand{

  
   public Wait(CommandTime commandTime) {
	   super(commandTime);
   }
   
	@Override
	protected void specifiedRewind() {
		this.leftTime = this.executionTime;
		finished = false;
	}

	@Override
	public void reverse() {
		this.rewind();
	}

	@Override
	protected void specifiedExecute(double dt) {
	}

	   
	  
	   
	 
	   
}

