//created by BB on 23 05 11

package auto.command;

public abstract class TimedCommand extends Command {

	public TimedCommand(CommandTime commandTime){
		this.executionTime = commandTime.getTimeValue();
		this.leftTime = commandTime.getTimeValue();
	}

}
