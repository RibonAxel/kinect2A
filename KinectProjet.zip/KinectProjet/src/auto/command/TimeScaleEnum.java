package auto.command;

public enum TimeScaleEnum {
	
	ECLAT, TECHNO, SEC, MIN, SONG, SHOW

}
