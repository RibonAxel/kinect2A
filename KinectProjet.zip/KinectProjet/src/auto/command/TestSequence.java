package auto.command;

import generators.GlobalSequenceGenerator;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;

import java.net.InetAddress;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.Sequenceur;
import autoIterator.DropBox;

public class TestSequence {

	
	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS);
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
			DmxPacket packet = new DmxPacket();
			
			Sequenceur sequenceur= new Sequenceur();
			double[] targets1= {1.0,1.0};
			double[] targets2= {0.3,0.3};
			DropBox[] boxs= {sequenceur.getpanBox(), sequenceur.gettiltBox()};
			
			Wait wait2s = new Wait(new CommandTime(2, TimeScaleEnum.SEC));
			Wait wait3s = new Wait(new CommandTime(3, TimeScaleEnum.SEC));
			Wait wait4s = new Wait(new CommandTime(4, TimeScaleEnum.SEC));
			MultiAxisGoto goto1 = new MultiAxisGoto(targets1, boxs);
			MultiAxisGoto goto2 = new MultiAxisGoto(targets2, boxs);
			UniAxisInterpolation interpol1 = new UniAxisInterpolation(1.0, 0.5, new CommandTime(3, TimeScaleEnum.SEC), sequenceur.gettiltBox());
			UniAxisInterpolation interpol2 = new UniAxisInterpolation(0.5, 0.0, new CommandTime(400, TimeScaleEnum.ECLAT), sequenceur.gettiltBox());
			Sequence sequence = new Sequence();
			sequence.addCommand(goto1);
			sequence.addCommand(wait2s);
			sequence.addCommand(interpol1);
			sequence.addCommand(wait3s);
			sequence.addCommand(interpol2);
			sequence.addCommand(wait4s);
			sequence.addCommand(goto2);
			sequenceur.setCommand(sequence);
			
			DoubleValue      sTilt = new DoubleValue(); 
			DoubleValue      sPan = new DoubleValue(); 
			PolymorphWave pwPan = new PolymorphWave(ShapeEnum.CONST);
			PolymorphWave pwTilt= new PolymorphWave(ShapeEnum.CONST);
			
			GlobalSequenceGenerator  gPan = new GlobalSequenceGenerator(pwPan, sequenceur.getpanV(), sequenceur.getGlobalssV(), sPan); 
			GlobalSequenceGenerator  gTilt = new GlobalSequenceGenerator(pwTilt, sequenceur.gettiltV(), sequenceur.getGlobalssV(), sTilt);
			
			DMXUniverse universe = new DMXUniverse();
			Patch pTilt = new Patch(sTilt);  pTilt.add(MULTFIXTURETILT); pTilt.add(255);
			Patch pPan  = new Patch(sPan); pPan.add(MULTFIXTUREPAN);  pPan.add(200);
			
			universe.add(pPan); universe.add(pTilt);       
			
			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {gPan, gTilt, sequenceur, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
   }
        
}
