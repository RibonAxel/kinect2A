package auto.command;

import generators.signal.polymorph.PolymorphValue;
import autoIterator.DropBox;

public abstract class Interpolation extends TimedCommand{

	public Interpolation(CommandTime commandTime){
		super(commandTime);
	}
	
	protected abstract void majIncrement();
	protected abstract void incValues();
	
	@Override
	public void specifiedExecute(double dt) {
		this.incValues();	
	}
	
}
