package auto.command;

public abstract class Goto extends Command{
	
	
	public void execute(double dt){
			this.specifiedExecute(dt);
			finished=true;
	}

	
	public void rewind(){
		this.finished= false;
	}
	protected void specifiedRewind(){};
	
	public void reverse(){ this.rewind();}
		
}
