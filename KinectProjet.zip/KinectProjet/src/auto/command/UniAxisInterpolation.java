package auto.command;

import autoIterator.DropBox;

public class UniAxisInterpolation extends Interpolation{

	
	private double target;
	private double increment;
	private double value;
	private double startValue;
	private DropBox Box;
	
	public UniAxisInterpolation(double startValue, double target, CommandTime commandTime, DropBox Box){
		super(commandTime);
		this.target = target;

		this.value = startValue;
		this.startValue = startValue;
		this.majIncrement();
		
		this.Box = Box;
	}
	
	@Override
	protected void majIncrement(){
		this.increment=((this.target-this.startValue)/this.executionTime);
	}
	@Override
	protected void incValues() {
		this.Box.setAmplitude(this.value += this.increment);
	   }

	@Override
	public void specifiedRewind() {
		this.leftTime = this.executionTime;
		this.value = this.startValue;
		this.majIncrement();
	}

	@Override
	public void reverse() {
		double tmp = this.startValue;
		this.startValue = this.target;
		this.target = tmp;
		
		this.rewind();  //inherited method
	}

	
	
}
