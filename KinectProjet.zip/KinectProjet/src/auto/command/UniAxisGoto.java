package auto.command;

import autoIterator.DropBox;

public class UniAxisGoto extends Goto {

	private double target;
	private DropBox box;
	
	public UniAxisGoto(double target, DropBox axisBox){
		this.box = axisBox;
		this.target = target;
	}
	
	@Override
	protected void specifiedExecute(double dt) {
		this.box.setAmplitude(target);

	}

}
