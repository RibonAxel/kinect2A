//created by BB on 19 05 11

package auto.command;

public abstract class Command {

	protected boolean finished = false;
	protected long executionTime;
	protected long leftTime;
	
	
	
	public boolean getFinished(){ return this.finished; }
	
	public void execute(double dt){
		if(leftTime>0)
		{
			this.leftTime--;
			this.specifiedExecute(dt);
		}
		else if(!finished)
			finished=true;

	}
	protected abstract void specifiedExecute(double dt);
	
	public void rewind(){
		this.leftTime = this.executionTime;
		this.finished= false;
		this.specifiedRewind();
	}
	protected abstract void specifiedRewind();
	
	public abstract void reverse();
}
