package auto.command;

public class CommandTime {

	private long timeValue;
	
	public CommandTime(long timeValue, TimeScaleEnum timeScale){
		switch(timeScale)
		{
			case ECLAT:  this.timeValue=timeValue; break;
			case TECHNO: this.timeValue= timeValue*20; break;
			case SEC:    this.timeValue= timeValue*40; break;
			case MIN:    this.timeValue= timeValue* 2400; break;
			case SONG:   this.timeValue= timeValue*12000; break;
			default: try {
							throw new Exception("Time scale error");
						 } catch (Exception e) {e.printStackTrace();}
		}
	}
	
	public long getTimeValue(){
		return this.timeValue;
	}
}
