package auto.command;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Sequence extends Command {

	private LinkedList<Command> commands = new LinkedList<Command>();
	private Iterator<Command> itCommands;
	private Command currentCommand = null;
	private boolean reverted = false;
	
	public Sequence(){
		itCommands = commands.iterator();
	}
	
	public void addCommand(Command command){
		this.commands.add(command);
		this.rewind();
	}
	public void addCommands(ArrayList<Command> commands){
		for(Command command : commands)
			this.commands.add(command);
		this.rewind();
	}
	
	
	@Override
	public void execute(double dt){
		this.specifiedExecute(dt);
	}
	
	@Override
	protected void specifiedExecute(double dt) {
		if(currentCommand == null)
		{	
			if(itCommands.hasNext())
			{
				currentCommand = itCommands.next();
			}
			else
				this.reverse();
				//this.finished = true;
		}
		if(currentCommand != null && currentCommand.finished)
			currentCommand = null;
		else if(currentCommand != null)
		{
			currentCommand.execute(dt);
		}
			

	}

	@Override
	protected void specifiedRewind() {
		for (Command command : commands){
			command.rewind();
		}
		itCommands = commands.iterator();
		this.currentCommand = null;
	}

	@Override
	public void reverse() {
		reverted = !reverted;
		for(Command command : commands){
			command.reverse();
		}
		if(reverted)
			itCommands = commands.descendingIterator();
		else
			itCommands = commands.iterator();
	}

}
