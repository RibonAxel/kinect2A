package auto.command;

import autoIterator.DropBox;

public class MultiAxisGoto extends Goto {

	private double[] targets;
	private DropBox[] boxs;
	
	public MultiAxisGoto(double[] targets, DropBox[] boxs)
	{
		this.targets = targets;
		this.boxs = boxs;
	}
	
	@Override
	protected void specifiedExecute(double dt) {
		for(int i=0; i<boxs.length; i++)
		{
			if(i< targets.length)
				this.boxs[i].setAmplitude( this.targets[i]);
				
		}
	}

}
