package auto;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.startStop.StartStopValue;
import auto.command.Command;
import autoIterator.DropBox;
import pi.executive.ContinuousAgent;

public class Sequenceur implements ContinuousAgent{

	private DropBox tiltBox = new DropBox(), panBox = new DropBox();
	private DropBox panValue = new DropBox(), tiltValue = new DropBox();
	private StartStopValue globalStartStopValue = new StartStopValue();
	
	private Command command;
	
	public Sequenceur(){
		this.globalStartStopValue.run(true);
	}
	
	public void setCommand(Command command){
		this.command = command;
	}
	
	@Override
	public void control() {
		this.panValue.copyVal(panBox);
		this.tiltValue.copyVal(tiltBox);
	}
	@Override
	public void delta(double dt) {
		this.command.execute(dt);	
	}
	
	public DropBox getpanBox()  { return this.panBox;}
	public DropBox gettiltBox() { return this.tiltBox;}
	public DropBox getpanV()    { return this.panValue;}
	public DropBox gettiltV()   { return this.tiltValue;}
	public StartStopValue getGlobalssV() { return this.globalStartStopValue;}
}
