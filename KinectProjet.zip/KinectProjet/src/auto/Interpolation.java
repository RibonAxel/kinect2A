//created by BB on 18 05 11

package auto;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.ShapeEnum;
import generators.signal.startStop.StartStopValue;

public class Interpolation extends AutoController{

	   
	   protected double target;
	   protected double executionTime;
	   protected double elapsedTime;
	   protected double increment;
	   protected double value;
	   protected double startValue;
	   

	   public Interpolation (double startValue, double target, double executionTime, PolymorphValue polyBox, StartStopValue startStopBox) {
	      this.target= target;
	      this.executionTime	 = executionTime;
	      this.elapsedTime = executionTime;
	      this.value = startValue;
	      this.startValue = startValue;
	      majIncrement();
	      
	      //initBoxs
	      this.polyBox = polyBox;
	      this.startStopBox = startStopBox;
	      this.polyBox.waveShape(ShapeEnum.CONST);
	      this.startStopBox.run(true);
	   }

	   public void initMove(double startValue, double target, double executionTime){
		   this.target= target;
		   this.executionTime	 = executionTime;
		   this.elapsedTime = executionTime;
		   this.value = startValue;
		   this.startValue = startValue;
		   majIncrement();
	   }
	   

	   
	   public void setTarget(double target) { 
	      this.target=target;
	      majIncrement();
	   }
	   
	   public void setStartValue(double startValue) { 
	      this.value=startValue;
	      this.startValue=startValue;
	      majIncrement();
	   }
	   
	   public void setExecutionTime(double executionTime) { 
	      this.executionTime=executionTime; 
	      this.elapsedTime = executionTime;
	      majIncrement();
	   }
	   
	   public void resetElapsedTime(){
		   this.elapsedTime = this.executionTime;
	   }
	   
	   @Override
	   public void restartMove(){
		   this.resetElapsedTime();
		   this.value = this.startValue;
		   this.setTarget(target);
	   }
	   @Override
	   public void invertMove(){
		   
	   }
	   public void majIncrement(){
		   this.increment=((this.target-this.value)/this.executionTime);
	   }
	   
	   private double incValues() {
	     return this.value += this.increment;
	   }

	@Override
	public void execute(double dt) {
		if(elapsedTime>0)
		{
			this.elapsedTime--;
			this.incValues();	
		}
		else
		{
			//this.startStopBox.run(false);
		}
	}

	@Override
	public void control() {
		this.polyBox.amplitude(this.value);		
	}


	   
	 
	   
	}

