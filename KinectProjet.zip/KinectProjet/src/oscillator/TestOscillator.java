//  Created by BB on 13 05 11.

package oscillator;


import oscillo.Oscilloscope;
import generators.SignalGenerator;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;
import pi.executive.Agent;
import pi.endpoint.DoubleValue;
import pi.container.Container;
import pi.container.SimpleContainer;
import pi.container.CompositeContainer;
import pi.application.Application;

import vanderpol.VanderpolGenerator;

public class TestOscillator {
   
   public static void test() {
   
      DoubleValue        S1 = new DoubleValue();
      
     PolymorphWave pw= new PolymorphWave(ShapeEnum.RAND);
      
     
      SignalGenerator G1 = new SignalGenerator(pw,S1);
      
      Oscillator     O1 = new Oscillator(S1, "polymorph",pw);
      
  
      
      SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, O1});

      
      Application	A  = new Application(instrument, 0.015, 0.001);
      
      A.start();   
   }
        
}
