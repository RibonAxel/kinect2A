package algo;

import java.awt.Point;
import java.util.ArrayList;

import javafx.geometry.BoundingBox;

public class Utils {

	
	public static Point getMin(ArrayList<Point> list){
		Point min=list.get(0);
		for(int i=1;i<list.size();i++){
			if (list.get(i).getY()<min.getY())
				min=list.get(i);
		}
		return min;
	}
	
	public static Point getMax(ArrayList<Point> list){
		Point max=list.get(0);
		for(int i=1;i<list.size();i++){
			if (list.get(i).getY()>max.getY())
				max=list.get(i);
		}
		return max;
	}
	
	
	public static double distance(Point p1,Point p2){
		double dx = p2.getX() - p1.getX();
		double dy = p2.getY() - p1.getY();
		return Math.sqrt(dx * dx + dy * dy);
		
	}
	
	public static Point centroid(ArrayList<Point> knots)  {
		double centroidX = 0, centroidY = 0;

			for(Point knot : knots) {
				centroidX += knot.getX();
				centroidY += knot.getY();
			}
    return new Point((int)(centroidX/knots.size()),(int)( centroidY/knots.size()));
}
	
	
	public static BoundingBox Bounding_Box(ArrayList<Point> points){
		BoundingBox B=new BoundingBox(points.get(0).getX(),Utils.getMax(points).getY(),points.size(),Utils.getMax(points).getY()-Utils.getMin(points).getY());
		return B;
	}
	
}
