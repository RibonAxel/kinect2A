package algo;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Map;

public class Template extends ArrayList<Point> {

	private String name="empty";
	
	
	public Template(ArrayList<Point> template, String name) {
		this.name = name;
		for (Point point : template) {
			this.add(point);
			
		}
	}

	
	
	public Template getTemplate(){
		return this;
	}
	
	
	



	public String getName() {
		return this.name;
	}
	

}
