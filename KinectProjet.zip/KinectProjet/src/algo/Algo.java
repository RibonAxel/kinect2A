package algo;

import java.awt.Point;
import java.util.ArrayList;

import javafx.geometry.BoundingBox;


public class Algo{
	
	
	public static Template formalizeTemplate(Template t) {
		ArrayList<Point> list = new ArrayList<Point>(t);
		list= Algo.resample(list, 64);
		list= Algo.rotate_By(list, Algo.indicative_Angle(list));
		list= Algo.scale_To(list, list.size());
		list=Algo.translate_to(list,new Point(0,0));
		
		return new Template(list, t.getName());
		
	}
	
	public static ArrayList<Point> resample(ArrayList<Point> points, int n)
	{		
		double I = path_lenght(points) / (n - 1); // interval length
		double D = 0.0;
		
		ArrayList<Point> srcPts = new ArrayList<Point> (points.size());
		for (int i = 0; i < points.size(); i++){
			srcPts.add(points.get(i));
		}

		ArrayList<Point> dstPts = new ArrayList<Point>(n);
		dstPts.add(srcPts.get(0));	//assumes that srcPts.size() > 0
		
		for (int i = 1; i < srcPts.size(); i++)
		{
			Point pt1 = (Point) srcPts.get(i - 1);
			Point pt2 = (Point) srcPts.get(i);
			
			double d = Utils.distance(pt1, pt2);
			if ((D + d) >= I)
			{
				double qx = pt1.getX() + ((I - D) / d) * (pt2.getX() - pt1.getX());
				double qy = pt1.getY() + ((I - D) / d) * (pt2.getY() - pt1.getY());
				Point q = new Point((int) qx,(int) qy);
				dstPts.add(q); // append new point 'q'
				srcPts.add(i, q); // insert 'q' at position i in points s.t. 'q' will be the next i
				D = 0.0;
			}
			else
			{
				D += d;
			}
		}
		
		if (dstPts.size() == n - 1)
		{
			dstPts.add(srcPts.get(srcPts.size() - 1));
		}
		
		
		//souvent on a pas le bon nombre de points
		while (dstPts.size() >= n + 1)
		{
			dstPts.remove(dstPts.size()-1);
		}
		
		return dstPts;
	}

	
	
	public static double path_lenght(ArrayList<Point> A){
		
		double d=0;
		
		for (int i=1;i<A.size();i++){
			d+=Utils.distance(A.get(i),A.get(i-1));
		}
		return d;
		
	}
	
	
	public static double indicative_Angle(ArrayList<Point> points){
		Point c=Utils.centroid(points);
		return Math.atan2(c.getY()-points.get(0).getY(),c.getX()-points.get(0).getX());
	}
	
	public static ArrayList<Point> scale_To(ArrayList<Point> points, int size){
		BoundingBox B=Utils.Bounding_Box(points);
		
		ArrayList<Point> newPoints=new ArrayList<Point>();
		for(Point p:points){
			double qx=p.getX()*size/points.size();
			double qy=p.getY()*size/(Utils.getMax(points).getY()-Utils.getMin(points).getY());
			newPoints.add(new Point((int)qx,(int)qy));
		}
		return newPoints;
	}

	public static ArrayList<Point> translate_to(ArrayList<Point> points, Point k){
		Point c=Utils.centroid(points);
		ArrayList<Point> newPoints=new ArrayList<Point>();
		for(Point p:points){
			double qx=p.getX()+k.getX()-c.getX();
			double qy=p.getY()+k.getY()-c.getY();
			newPoints.add(new Point((int)qx,(int)qy ));
		}
		return newPoints;
	}

	
	public static Template Trecognize(ArrayList<Point> points, ArrayList<Template> template){
		double b=100000;
		Template T2 =null;
		//System.out.println(template.size());
		for (Template t: template){
			double d=distance_at_best_angle(points,t,Math.toRadians(-45),Math.toRadians(+45),Math.toRadians(2));
			if(d<b){
				b=d;
				T2=t;

			}
			
		}
	return T2;
	}
	
	
	
	public static double Drecognize(ArrayList<Point> points, ArrayList<Template> template){
		double b=1000000;
		Template T2 =null;
		for (int i=0;i<template.size();i++){
			double d=distance_at_best_angle(points,template.get(i),Math.toRadians(-45),Math.toRadians(+45),Math.toRadians(2));
			if(d<b){
				b=d;
				T2=template.get(i);
			}
			
		}
		//double score= 1-b/(0.5*Math.sqrt(Math.pow(points.size(), 2)+Math.pow(points.size(), 2)));
		double score= 1-(b/(0.5* Math.sqrt(250.0 * 250.0 + 250.0 * 250.0)));
		System.out.println("score");
	return score;
	}
	
	
	public static double distance_at_best_angle (ArrayList<Point> points, Template T, double tetaA,double tetaB,double tetaD){
		
		
		double fi=Math.sqrt(-1+Math.sqrt(5));
		
		double x1=fi*tetaA+(1-fi)*tetaB;
		double f1=distance_at_angle(points,T,x1);
		double x2=(1-fi)*tetaA+fi*tetaB;
		double f2=distance_at_angle(points,T,x2);
		
		while(Math.abs(Math.abs(tetaB)-Math.abs(tetaA))>tetaD){
		
			if(f1<f2){
				tetaB=x2;
				x2=x1;
				f2=f1;
				x1=fi*tetaA+(1-fi)*tetaB;
				f1=distance_at_angle(points,T,x1);
			
			}else{
				tetaA=x1;
				x1=x2;
				f1=f2;
				x2=(1-fi)*tetaA+fi*tetaB;
				f2=distance_at_angle(points,T,x2);
				
			
			}
		}
		return Math.min(f1,f2);
		
		
	}
	
	
	public static double distance_at_angle(ArrayList<Point> points,Template T,double teta){
			ArrayList<Point> newPoints=new ArrayList<Point>();
			newPoints=rotate_By(points,teta);
			return path_distance(newPoints,T);
		
	}

	
	



	public static double path_distance(ArrayList<Point> A, ArrayList<Point> B){
		double d=0;
		for (int i=0; i<A.size();i++){
			d += Utils.distance( A.get(i), B.get(i));
		}
		return d/A.size();
	}
	
	public static ArrayList<Point> rotate_By(ArrayList<Point> points, double angle){
		
		ArrayList<Point> newPoints = new ArrayList<Point>(points.size());
		Point c = Utils.centroid(points);

		double _cos = Math.cos(angle);
		double _sin = Math.sin(angle);

		double cx = c.getX();
		double cy = c.getY();

		for (int i = 0; i < points.size(); i++)
		{
			Point p = (Point) points.get(i);

			double dx = p.getX() - cx;
			double dy = p.getY() - cy;
			newPoints.add(new Point((int)(dx*_cos-dy*_sin+cx),(int)(dx*_sin+dy*_cos+cy)));
		}
		return newPoints;
	}
	
	
}

