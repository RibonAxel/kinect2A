//  Created by BB on 06 05 11.

package DMXTransfer;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import generators.DMXSignalGenerator;
import generators.SignalGenerator;
import generators.signal.DMXSineWave;
import generators.signal.Sinewave;
import oscillo.DMXOscilloscope;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.AdaptaterDoubleValueToDMXValue;
import pi.endpoint.DMXValue;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;

public class TestDMXTransfer {

	private static final String ADDRESS = "255.255.255.255";

	//private static final String ADDRESS  = "10.59.14.101";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	
	
	public static void test() {
		
		 try 
		 {
			 
	         InetAddress address = InetAddress.getByName(ADDRESS);
	         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
	         DmxPacket packet = new DmxPacket();
	         
	         
	         DoubleValue      S1 = new DoubleValue();     
	         SignalGenerator  G1 = new SignalGenerator(new Sinewave(120, 1), S1); 
	         DMXTransfer   T1 = new DMXTransfer(new AdaptaterDoubleValueToDMXValue(S1), sink, packet, FIXTUREBLUE);
	         DMXOscilloscope     O1 = new DMXOscilloscope(new AdaptaterDoubleValueToDMXValue(S1), "blue");
	   
	         DMXValue      S2 = new DMXValue();
	         DMXSignalGenerator  G2 = new DMXSignalGenerator(new DMXSineWave(120, 0.1), S2); 
	         DMXTransfer   T2 = new DMXTransfer(S2, sink, packet, FIXTURETILT);
	         DMXOscilloscope     O2 = new DMXOscilloscope(S2, "tilt");
	         
	         DMXValue      S3 = new DMXValue();
	         DMXSignalGenerator  G3 = new DMXSignalGenerator(new DMXSineWave(120, 3), S3); 
	         DMXTransfer   T3 = new DMXTransfer(S3, sink, packet, FIXTUREDIMMER);
	         DMXOscilloscope     O3 = new DMXOscilloscope(S3, "Dimmer");
	         
	         DMXValue      S4 = new DMXValue();
	         DMXSignalGenerator  G4 = new DMXSignalGenerator(new DMXSineWave(254, 0.1), S4); 
	         DMXTransfer   T4 = new DMXTransfer(S4, sink, packet, FIXTURERED);
	         DMXOscilloscope     O4 = new DMXOscilloscope(S4, "red");
	         
	         DMXTransfer   Ttest = new DMXTransfer(S4, sink, packet, 17);
	         
	         SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, T1, O1, T1, G2, T2, O2, T2, G3, T3, O3, T3, G4, T4, O4, T4, G4, Ttest});
	         Application     application = new Application(instrument, 0.025, 0.005);
	      
		   
		   
	         application.start();      
		 }
		 catch (Exception e) { e.printStackTrace();	}
	}
}