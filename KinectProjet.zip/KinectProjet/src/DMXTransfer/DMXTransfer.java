//  Created by BB on 06 05 11.

package DMXTransfer;

import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import pi.endpoint.AdaptaterDoubleSourceToDMXSource;
import pi.endpoint.DMXProbe;
import pi.endpoint.DMXSource;
import pi.endpoint.DoubleSource;
import pi.executive.ContinuousAgent;

public class DMXTransfer implements ContinuousAgent{

	private ArtnetSink 		sink;
	private DMXProbe        probe;
	private DmxPacket		packet;
	private int				chanel;
	
	
	public DMXTransfer(DoubleSource source, ArtnetSink sink, DmxPacket packet, int chanel)
	{
		this.chanel = chanel;
		this.sink = sink;
		this.probe   = new DMXProbe(new AdaptaterDoubleSourceToDMXSource(source));
		this.packet = packet;
	}
	public DMXTransfer(DMXSource source, ArtnetSink sink, DmxPacket packet, int chanel)
	{
		this.chanel = chanel;
		this.sink = sink;
		this.probe   = new DMXProbe(source);
		this.packet = packet;
	}
	
	@Override
	public void control() {
		
		sink.send(packet );
	}

	@Override
	public void delta(double dt) {
		packet.channelValue(chanel, probe.value());
	}

}
