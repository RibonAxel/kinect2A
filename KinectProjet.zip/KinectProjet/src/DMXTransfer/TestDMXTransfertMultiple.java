// Created by BB on 06/05/11

package DMXTransfer;

import generators.DMXSignalGenerator;
import generators.SignalGenerator;
import generators.signal.DMXSineWave;
import generators.signal.Sinewave;

import java.net.InetAddress;
import java.util.HashMap;

import pi.endpoint.AdaptaterDoubleValueToDMXValue;
import pi.endpoint.DMXValue;
import pi.endpoint.DoubleValue;
import pi.endpoint.Source;
import stream.UDPSink;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;

public class TestDMXTransfertMultiple {


	private static final String ADDRESS = "255.255.255.255";

	//private static final String ADDRESS  = "10.59.14.101";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	
	
	public static void test() {
		
		 try 
		 {
			 
	         InetAddress address = InetAddress.getByName(ADDRESS);
	         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
	         DmxPacket packet = new DmxPacket();
	         
	         
	         DoubleValue      S1 = new DoubleValue();     
	         SignalGenerator  G1 = new SignalGenerator(new Sinewave(120, 0.02), S1); 
	   
	         DMXValue      S2 = new DMXValue();
	         DMXSignalGenerator  G2 = new DMXSignalGenerator(new DMXSineWave(120, 0.1), S2); 
	         
	         DMXValue      S3 = new DMXValue();
	         DMXSignalGenerator  G3 = new DMXSignalGenerator(new DMXSineWave(120, 0.3), S3); 
	         
	         DMXValue      S4 = new DMXValue();
	         DMXSignalGenerator  G4 = new DMXSignalGenerator(new DMXSineWave(254, 0.1), S4); 
	         
	         
	         HashMap<Integer, Source> levelMap = new HashMap<Integer, Source>();
	       //remplissage de la hashmap
	         /*levelMap.put(19, new AdaptaterDoubleValueToDMXValue(S1));
	         levelMap.put(20,S2);
	         levelMap.put(21, S3);
	         levelMap.put(22, new AdaptaterDoubleValueToDMXValue(S1));
	         levelMap.put(23,S2);
	         levelMap.put(476, S3);
	         levelMap.put(512, new AdaptaterDoubleValueToDMXValue(S1));
	         levelMap.put(511 ,S2);
	         levelMap.put(510, S3);
	         levelMap.put(256, S4);*/
	         levelMap.put(2,S2);
	         levelMap.put(3, S3);
	         levelMap.put(7, new AdaptaterDoubleValueToDMXValue(S1));
	         levelMap.put(8,S2);
	         
	         //envoi de la hashmap 
	    //     DMXLevel 		L1 = new DMXLevel(levelMap , "level");
	     //    DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, levelMap);
	         
	    //     SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, G2, G3 ,G4, T1, L1});
	    //     Application     application = new Application(instrument, 0.025, 0.005);
	      
		   
		   
	    //     application.start();      
		 }
		 catch (Exception e) { e.printStackTrace();	}
	}
}