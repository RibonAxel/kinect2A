package DMXTransfer;

import java.util.Iterator;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;

import pi.endpoint.DMXProbe;
import pi.executive.ContinuousAgent;
import universe.DMXUniverse;
import universe.Patch;

public class DMXTransferMultiple implements ContinuousAgent{

	private ArtnetSink sink;
	private DmxPacket  packet;
	private DMXUniverse universe;

	public DMXTransferMultiple(ArtnetSink sink, DmxPacket packet, DMXUniverse universe)
	{
		this.sink = sink;
		this.packet = packet;
		this.universe = universe;
	}
	
	@Override
	public void control() {
		sink.send(packet );
	}

	@Override
	public void delta(double dt) {
		Iterator<Patch> itPatch = universe.getPatchs().iterator();
		while(itPatch.hasNext())
		{
			Patch p = itPatch.next();
			DMXProbe val = new DMXProbe(p.getSource());
			Iterator<Integer> itChanels = p.getChannels().iterator();
			while (itChanels.hasNext())
			{
				packet.channelValue(itChanels.next(), val.value());
			}
		}
	
	}

}
