// Created by BB on 11/05/11

package level;


import java.awt.Label;
import javax.swing.JFrame;

import pi.executive.ContinuousAgent;
import universe.DMXUniverse;



public class DMXLevel extends JFrame implements ContinuousAgent {

	   private static final int       WIDTH   = 550;
	   private static final int       HEIGHT  = 350;
	   private static final double FRAME_TIME = 0.050;
	   
	   private double  time    = 0;
	   private boolean refresh = true;

	   private DMXLevelData   samples;
	   private DMXLevelCanvas canvas;

	   private Label  zero  = new Label ("0", Label.LEFT);
	   private Label  max   = new Label ("512", Label.RIGHT);
	  // private HashMap levelMap = new HashMap();
	   private DMXUniverse universe = new DMXUniverse();
	   
	   
	   /*public DMXLevel(HashMap levelMap, String name) {
		   this.levelMap = levelMap;
		 */
	   public DMXLevel(DMXUniverse universe, String name)
	   {
		   this.universe = universe;
		   this.setTitle(name);
		   this.samples = new DMXLevelData (DMXLevelCanvas.SAMPLES);
		   this.getContentPane().setLayout(null);
		   this.setSize(WIDTH, HEIGHT);
		   this.samples = samples;
		   canvas = new DMXLevelCanvas(15, 25, samples);
		   this.getContentPane().add(canvas);
		   zero.setBounds( 20,8, 20,16); getContentPane().add(zero);
		   max.setBounds (430,8,100,16); getContentPane().add(max );
		   this.show();
	   }

	   
	   public String toString () { return "DMXOscilloscope " + this.getTitle(); }

	   public void control () { 
	      if (refresh) {
	         this.refresh();
	         refresh = false;
	      }
	    }
	   
	   	public void delta(double dt) {
	       this.sample();
	       time = time + dt;
	       if (time >= FRAME_TIME) {
	          refresh = true;
	          while (time >= FRAME_TIME) time = time - FRAME_TIME;
	       }
	       //max.setText(String.valueOf(dt*samples.size()));
	    }
	 
	   // the 3 following methods are synchronized to provide mutual exclusion 
	   // of the pi thread and the controller (gui thread)
	     
	   private synchronized void sample () { 
	      //double sample = probe.value();
	      samples.switchSamples(universe); 
	   }

	   private synchronized void refresh () {
	      canvas.update();
	   }
	   
	 /*  private synchronized void adjustGain(double g) {
	      probe.adjust(g);
	      samples.clear();
	   }*/
	  

		     
	    
}
