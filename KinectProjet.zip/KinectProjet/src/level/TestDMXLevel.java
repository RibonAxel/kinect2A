// Created by BB on 11/05/11

package level;


	import java.net.InetAddress;
	import java.util.HashMap;

	import artnet.as.DmxPacket;
	import artnet.stream.ArtnetSink;
	import generators.DMXSignalGenerator;
	import generators.SignalGenerator;
	import generators.signal.Constant;
	import generators.signal.DMXSineWave;

	import pi.endpoint.AdaptaterDoubleValueToDMXValue;
	import pi.endpoint.DMXValue;
	import pi.endpoint.DoubleValue;
	import stream.UDPSink;

	public class TestDMXLevel {		private static final String ADDRESS = "255.255.255.255";

		//private static final String ADDRESS  = "10.59.14.101";
		private static final int ARTNET_PORT = 6454;
		private static final int SUBNET      = 0;
		private static final int UNIVERSE    = 0;
		private static final int FIXTUREBLUE    = 4;
		private static final int FIXTURERED     = 2;
		private static final int FIXTUREGREEN   = 3;
		private static final int FIXTURETILT    = 8;
		private static final int FIXTUREDIMMER  = 6;
		
		
		public static void test() {
			
			 try 
			 {
		         InetAddress address = InetAddress.getByName(ADDRESS);
		         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
		         DmxPacket packet = new DmxPacket();
		         
		         int chanel = 1;
		         
		         HashMap levelMap = new HashMap();
		      
		         
		         DMXValue      S1 = new DMXValue();
		         DMXSignalGenerator  G1 = new DMXSignalGenerator(new DMXSineWave(120, 1), S1); 

		   
		         DMXValue      S2 = new DMXValue();
		         DMXSignalGenerator  G2 = new DMXSignalGenerator(new DMXSineWave(120, 0.1), S2); 

		         DMXValue      S3 = new DMXValue();
		         DMXSignalGenerator  G3 = new DMXSignalGenerator(new DMXSineWave(254, 0.21), S3); 
		         
		         DoubleValue      S4 = new DoubleValue();
		         SignalGenerator  G4 = new SignalGenerator(new Constant(0.5), S4); 
		         
		         //remplissage de la hashmap
		         levelMap.put(chanel, S1);
		         levelMap.put(2,S2);
		         levelMap.put(37, S3);
		         levelMap.put(98, S1);
		         levelMap.put(234,S2);
		         levelMap.put(476, S3);
		         levelMap.put(512, S1);
		         levelMap.put(511 ,S2);
		         levelMap.put(510, S3);
		         levelMap.put(256, new AdaptaterDoubleValueToDMXValue(S4));
		         
		         //envoi de la hashmap 
		//         DMXLevel 		O5 = new DMXLevel(levelMap , "level");
		         
		         
		         
		         
		        // DMXTransfer   Ttest = new DMXTransfer(S4, sink, packet, 17);
		         
		//         SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, G2, G3, G4, O5});
		//         Application     application = new Application(instrument, 0.025, 0.005);
		      
			   
			   
		//         application.start();      
			 }
			 catch (Exception e) { e.printStackTrace();	}
		}
	}