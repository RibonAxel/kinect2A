// Created by BB on 11/05/11
package level;


import java.util.Iterator;
import pi.endpoint.DMXProbe;
import universe.DMXUniverse;
import universe.Patch;

public class DMXLevelData {

	private int origine;  

	private double[] samples;
   
   
	public DMXLevelData (int size) { // size is number of samples
		this.samples   = new double[size];
		this.clear();
	}

	public int size()      { return samples.length;  }
   
	public double sample(int index) {
		int i = (origine + index) % samples.length ;
		return this.samples[i]; 
	}
   
	public void clear () {
		for (int i = 0;  i < samples.length; i++) { 
			samples[i] = 0.0;
		}    
		this.origine    = 520;
	}      
   
	public void switchSamples(DMXUniverse universe) {
		
		Iterator<Patch> itPatch = universe.getPatchs().iterator();
		while(itPatch.hasNext())
		{
			Patch p = itPatch.next();
			DMXProbe val = new DMXProbe(p.getSource());
			Iterator<Integer> itChanels = p.getChannels().iterator();
			while (itChanels.hasNext())
			{
				samples[itChanels.next()] = val.value();
			}	
		}
	 }
           
}
