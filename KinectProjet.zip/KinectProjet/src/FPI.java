import pi.examples.tank.TankWindow;
import record.ihm.TestPlayer;


import java.net.InetAddress;

import DMXTransfer.TestDMXTransfer;
import DMXTransfer.TestDMXTransfertMultiple;
import Global.TestGlobalController;
import auto.TestInterpolation;
import auto.TestRectangleMove;
import auto.TestSequenceur;
import auto.command.TestSequence;
import autoIterator.TestAdaptaterDoubleValueToDropBox;
import autoIterator.TestAutoSequencerController;
import autoIterator.TestChaser;
import autoIterator.TestFan;
import autoIterator.TestIteratorParallele;
import autoIterator.TestIteratorSequence;
import autoIterator.TestIteratorSequenceParallele;
import autoIterator.TestIteratorSequenceur;
import autoIterator.TestSequencerController;
import basic.HelloWorld;
import universe.TestUniverse;
import user.TestUser;
import coin.TestCoin;
import vanderpol.TestVanderpol;
import oscillator.TestOscillator;
import oscillo.TestDMXOscilloscope;
import oscillo.TestOscilloscope;
import level.TestDMXLevel;
import lorenz.TestLorenz;
import ccs.TestCCS;
import demo.ControlDirectMax500;
import demo.Demo1;
import demo.Test;
import demo.TestControlDirect;
import enveloppe.TestEnveloppe;
import generators.TestGenerators;
import generators.TestGlobalGenerator;
import generators.signal.polymorph.TestPolymorphController;
import generators.signal.polymorph.TestPolymorphControllerPanel;
import generators.signal.startStop.TestStartStop;

public class FPI {

    public static void main (String args[]) {
//        HelloWorld.test();
//        TankWindow tankWindow = new TankWindow();
//        tankWindow.show();
//        TestUser.test();
//        TestCoin.test();
//        TestVanderpol.test();
//        TestOscilloscope.test();
//        TestLorenz.test();
//        TestCCS.test();
//        TestGenerators.test();
//    	  TestDMXTransfer.test();
//	 	  TestDMXOscilloscope.test();
//	 	  TestDMXLevel.test();				remplac� par testUniverse
//    	  TestDMXTransfertMultiple.test();  remplac� par testUniverse
//    	  TestEnveloppe.test();
//    	  TestUniverse.test();
//    	  TestOscillator.test();
//    	TestPolymorphController.test();
//    	TestStartStop.test();
//    	TestPolymorphControllerPanel.test();
//    	TestGlobalGenerator.test();
//    	TestInterpolation.test();
//    	TestGlobalController.test();
//    	TestRectangleMove.test();
//    	TestSequenceur.test();
//    	TestSequence.test();
//    	TestIteratorSequenceur.test();
//    	TestIteratorSequence.test();
//    	TestIteratorParallele.test();
//    	TestIteratorSequenceParallele.test();
//   	TestAdaptaterDoubleValueToDropBox.test();
//    	TestPlayer.test();
//   	TestAutoSequencerController.test();
//    	TestChaser.test();
 		//TestControlDirect.test(); 
 		//au dessus peut etre
//    	TestSequencerController.test();
//		TestFan.test();
//   	ControlDirectMax500.test();
Demo1.test();
   	 
    	
 //   	Test.test();

    }
}
