//  Sinewave.java
//  Created by BB on 05 05 11.

package generators.signal;

public abstract class DMXSignal {

	 protected int value = 0;
	 
	   public void    open () { value = 0;  }
	   public int  value() { return value; }
	   public boolean atEnd() { return false; }
	   
	   public abstract void delta(double dt);

}
