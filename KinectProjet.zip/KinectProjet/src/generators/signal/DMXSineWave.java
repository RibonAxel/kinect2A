// Created by BB on 05/05/11

package generators.signal;

public class DMXSineWave extends DMXSignal{

	protected static double TWO_PI = (double) (2.0 * Math.PI);
	   
	   protected double amplitude;
	   protected double frequency;
	   protected double omega; 
	   protected double phase;
	  
	   public DMXSineWave (double frequency) {
	      this (1.0, frequency); 
	   }

	   public DMXSineWave (double amplitude, double frequency) {
	      if(amplitude<255 && amplitude>=0)
	    	  this.amplitude = amplitude;
	      else 
	    	  amplitude = 255;
	      this.phase     = 0.0;
	      this.frequency(frequency);
	   }

	   public double frequency () { 
	      return this.frequency; 
	   }

	   public void frequency(double frequency) {
	      this.frequency = frequency;
	      this.omega 	   = TWO_PI * frequency;   
	   }
	   
	   public void  open () { 
	      super.open();
	      phase = 0.0;
	   }
	      
	   public void delta(double dt) {
	      phase += omega * dt;
	      if (phase > TWO_PI) phase -= TWO_PI;
	      value = (int) ((Math.sin(phase)*(amplitude/2)) + amplitude/2);
	   }
	   

}