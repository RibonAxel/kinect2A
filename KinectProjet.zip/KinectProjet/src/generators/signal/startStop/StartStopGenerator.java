// Created by BB 16/05/2011

package generators.signal.startStop;

import generators.Generator;
import generators.StartStopGeneratorInterface;
import generators.signal.Signal;
import pi.endpoint.DoubleSink;

public class StartStopGenerator extends Generator implements StartStopGeneratorInterface{
	   
   private Signal behaviour;
   private DoubleSink output;

   private boolean run = false;
   private StartStopValue startStopBox;
    
	public StartStopGenerator(Signal behaviour, DoubleSink output) {
		this(behaviour, null, output);
	}
	
	public StartStopGenerator(Signal behaviour, StartStopValue startStopBox, DoubleSink output) {
		this.behaviour = behaviour;
	    this.output    = output;
	    this.startStopBox  	   = startStopBox;
	    this.initialize();
	}
   
	
	public void startStopBox(StartStopValue startStopBox){
		this.startStopBox = startStopBox;
	}
	public StartStopValue startStopBox(){
		return this.startStopBox;
	}
   
   private void initialize() {
	   this.behaviour.open();
   }
   @Override
   public void run() {
	   this.run = true;
	   this.initialize();
   }
   @Override
   public void stop() {
	   this.run = false;
	   output.value(0);
   }
   @Override
   public boolean running() { return this.run; }
   
   public void control () { 
	   if(this.run)
	   {
		   output.value(behaviour.value());        
	   }
   }
   
   public void delta (double dt) {

	   if(!this.startStopBox.run() && this.run){
		   this.stop();
	   }
	   if(this.startStopBox.run() && !this.run){
		   this.run();
	   }
	   if (this.run && !this.behaviour.atEnd()) {
		   this.behaviour.delta(dt);
	   }

   }
	   
}
