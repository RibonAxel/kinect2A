//  Created by BB on 17 05 11.

package generators.signal.startStop;

import generators.signal.Constant;
import generators.signal.Sinewave;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import universe.DMXUniverse;
import universe.Patch;

public class TestStartStop {

	public static void test() {
		   
		try 
		 {
			 
	    	 DoubleValue      S1 = new DoubleValue();     
	         StartStopValue		  TValue1 = new StartStopValue();
	 		 Constant c1 = new Constant(0.5);
			 StartStopController T1 = new StartStopController(TValue1, "Const");
	         StartStopGenerator  G1 = new StartStopGenerator(c1, TValue1, S1); 
	   
	    	 DoubleValue      S2 = new DoubleValue();     
	         StartStopValue		  TValue2 = new StartStopValue();
	 		 Sinewave c2 = new Sinewave(1);
			 StartStopController T2 = new StartStopController(TValue2, "Wave");
	         StartStopGenerator  G2 = new StartStopGenerator(c2, TValue2, S2); 
	         	         
	         DMXUniverse universe = new DMXUniverse();
	         Patch p1 = new Patch(S1);  p1.add(255);
	         Patch p2 = new Patch(S2);	p2.add(200);

	         universe.add(p1); universe.add(p2);       
	        
	         DMXLevel 		L1 = new DMXLevel(universe , "level");
	         
	         SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, G2, T1, T2, L1});
	         Application     application = new Application(instrument, 0.025, 0.005);
	      
		   
		   
	         application.start();      
		 }
		 catch (Exception e) { e.printStackTrace();	}	 
   }
        
}
