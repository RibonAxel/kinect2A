//  Created by BB on 17 05 11.

package generators.signal.startStop;


public interface StartStopEndPoint extends StartStopSource, StartStopSink{

}
