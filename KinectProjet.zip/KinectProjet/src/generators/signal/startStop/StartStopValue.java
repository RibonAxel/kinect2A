//  Created by BB on 17 05 11.


package generators.signal.startStop;

public class StartStopValue implements StartStopEndPoint{

	//oui ou non je tourne 
	
	protected boolean run=true;

	@Override
	public boolean run() {
		return this.run;
	}

	@Override
	public void run(boolean run) {
		this.run = run;
		
	}
	
	
	
}
