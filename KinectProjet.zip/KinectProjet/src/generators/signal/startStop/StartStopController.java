//  Created by BB on 17 05 11.

package generators.signal.startStop;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

import pi.executive.ContinuousAgent;


public class StartStopController extends JFrame implements ContinuousAgent{

	
	private static final int       WIDTH   = 530;
    private static final int       HEIGHT  = 270;
    private static final double FRAME_TIME = 0.050;
   
    private double  time    = 0;
    private boolean refresh = true;
    
	private  JLabel label;
	private Controller controller; 

    private StartStopValue box;
    

    private StartStopController(StartStopValue box){
    	this(box, "polyController");
    }
   
	public StartStopController (StartStopValue box, String name) {
	   	this.box = box;
	   	this.setTitle(name);
	   	this.getContentPane().setLayout(null);
	   	this.setSize(WIDTH, HEIGHT);
	    controller = new Controller();
	    
	    this.show();
	}
	
	public String toString () { return "TimeController " + this.getTitle(); }
	
	public void control () { 
		
    }
	
	public void delta(double dt) {
       time = time + dt;
       if (time >= FRAME_TIME) {
          refresh = true;
          while (time >= FRAME_TIME) time = time - FRAME_TIME;
       }
    }

	private synchronized void adjustRun(boolean run) {
		box.run(run);
	}	
	  
   private class Controller implements ItemListener {
	    private CheckboxGroup buttons = new CheckboxGroup();
	    private Checkbox start, stop;
		     
		public Controller() {
			this.add_start_Checkbox();
		    this.add_stop_Checkbox();  
		}

		//geometric BOX		
	    private void add_start_Checkbox () {
	        start = new java.awt.Checkbox("start", buttons, false);
	        start.setBounds(10,22,70,23);
	        start.addItemListener(this);
	        getContentPane().add(start); 
	    }	     
		     
	    private void add_stop_Checkbox () {
	    	stop = new java.awt.Checkbox("stop", buttons, true);
	    	stop.setBounds(80,22,70,23);
	    	stop.addItemListener(this);
	        getContentPane().add(stop); 
	    }	     
	 
		
	    public void itemStateChanged (ItemEvent e) { 
	        if (e.getSource() == start) { this.adjustRun(true); }
	        if (e.getSource() == stop) { this.adjustRun(false); }

	    }
	    
	    private void adjustRun(boolean run) {
	    	StartStopController.this.adjustRun(run);
	    }
   
   }
   
   
   
}