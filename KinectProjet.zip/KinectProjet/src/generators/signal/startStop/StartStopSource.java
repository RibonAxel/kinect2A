//  Created by BB on 17 05 11.

package generators.signal.startStop;

import pi.endpoint.Source;

public interface StartStopSource extends Source{
	public boolean run();
}
