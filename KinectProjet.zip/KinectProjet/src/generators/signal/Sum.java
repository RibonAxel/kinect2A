//  Created by Bernard Thirion 22/04/2011

package generators.signal;

public class Sum extends Signal {
   
   private Signal left, right;
   
   public Sum (Signal left, Signal right) {
      this.left  = left;
      this.right = right;
   }
   
   public void open () { 
      left.open(); 
      right.open(); 
   }
   
   public void delta(double dt) {
      left.delta(dt);
      right.delta(dt);
      value = (left.value() + right.value()) / 2.0;
   }

}
