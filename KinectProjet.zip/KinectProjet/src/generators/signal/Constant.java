//  Constant.java
//  Created by Bernard Thirion 22/04/2011

package generators.signal;

public class Constant extends Signal {

   public Constant(double value) {
      this.value = value;
   }
   
   public void open() {}
   
   public void delta(double dt) { }

}
