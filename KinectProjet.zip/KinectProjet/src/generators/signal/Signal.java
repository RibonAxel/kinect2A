//  Created by Bernard Thirion 22/04/2011

package generators.signal;

public abstract class Signal {

   protected double value = 0.0;
 
   public void    open () { value = 0.0;  }
   public double  value() { return value; }
   public boolean atEnd() { return false; }
   
   public abstract void delta(double dt);

}
