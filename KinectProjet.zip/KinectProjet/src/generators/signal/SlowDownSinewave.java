//  SlowDownSinewave.java 
//  Created by Bernard Thirion 22/04/2011

package generators.signal;

public class SlowDownSinewave extends Sinewave {
   
   private double ratio; 
   private int    count;
   private int    max;
      
   public SlowDownSinewave (double amplitude, double frequency, double ratio, int max) {
      super(amplitude, frequency);
      this.ratio = ratio;
      this.max   = max;
      this.count = 0;
   }

   public void open () { 
      super.open();
      count = 0;
   }
   
   public void delta(double dt) {
      if (count < max) {
         omega = omega * ratio;
       } else {
         frequency(frequency);
         count = 0;
      }
      super.delta(dt);
      count++;
   }
   
}
