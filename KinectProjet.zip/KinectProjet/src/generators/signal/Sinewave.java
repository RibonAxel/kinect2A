//  Sinewave.java
//  Created by Bernard Thirion on Fri Jan 02 2004.

package generators.signal;

public class Sinewave extends Signal {

   protected static double TWO_PI = (double) (2.0 * Math.PI);
   
   protected double amplitude;
   protected double frequency;
   protected double omega; 
   protected double phase;
  
   public Sinewave (double frequency) {
      this (1.0, frequency); 
   }

   public Sinewave (double amplitude, double frequency) {
      this.amplitude = amplitude;
      this.phase     = 0.0;
      this.frequency(frequency);
   }

   public double frequency () { 
      return this.frequency; 
   }

   public void frequency(double frequency) {
      this.frequency = frequency;
      this.omega 	   = TWO_PI * frequency;   
   }
   
   public void  open () { 
      super.open();
      phase = 0.0;
   }
      
   public void delta(double dt) {
      phase += omega * dt;
      if (phase > TWO_PI) phase -= TWO_PI;
      value = Math.sin(phase);
   }

}
