// Created by BB on 17/05/11
// A RENOMMER

package generators.signal.polymorph;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;



public class Instrument extends JFrame {

	private ArrayList<PolymorphValue> values = new ArrayList<PolymorphValue>();
	private ArrayList<PolymorphControllerPanel> controllers = new ArrayList<PolymorphControllerPanel>();
		
	public Instrument(String[] names)
	{
		
		this.setBounds(400, 400, 900, 400);
	
		this.setLayout(new BorderLayout());
		JPanel panel = new JPanel();
		
		panel.setPreferredSize(this.getSize());
		JTabbedPane onglets = new JTabbedPane(SwingConstants.TOP); 
		
		for(int i=0; i< names.length; i++)
		{
			values.add(new PolymorphValue());
			controllers.add(new PolymorphControllerPanel(values.get(i), names[i]));
			onglets.add(names[i], controllers.get(i));
		}
				
		onglets.setOpaque(true); 
		panel.add(onglets); 
			
		this.getContentPane().add(panel, BorderLayout.CENTER);				
		this.setVisible(true);
	
	}
	
	public ArrayList<PolymorphControllerPanel> getControllers(){
		return this.controllers;
	}
	
	
	
	public ArrayList<PolymorphValue> getValues(){
		return this.values;
	}
        
}

