// Created by BB on 13/05/11

package generators.signal.polymorph;


	import java.awt.Checkbox;
	import java.awt.CheckboxGroup;
	import java.awt.Dimension;
	import java.awt.event.ItemEvent;
	import java.awt.event.ItemListener;

	import javax.swing.JLabel;
	import javax.swing.JPanel;

	
	import GUI.DoubleSliderPanel;
	
import pi.executive.ContinuousAgent;


	public class PolymorphControllerPanel extends JPanel implements ContinuousAgent{

		
		private static final int       WIDTH   = 700;
	    private static final int       HEIGHT  = 300;
	    private static final double FRAME_TIME = 0.050;
	   
	    private double  time    = 0;
	    private boolean refresh = true;
	    
	    private  DoubleSliderPanel sliderFrequency;
		private  DoubleSliderPanel sliderAmplitude;
		private  DoubleSliderPanel sliderDephas;
		private  JLabel label;
		private Controller controller; 

	    private PolymorphValue box;
		
	    

	    private PolymorphControllerPanel(PolymorphValue box){
	    	this(box, "polyControler");
	    }
	   
		public PolymorphControllerPanel(PolymorphValue box, String name) {
		   	this.box = box;
		   	this.setName(name);
		   	this.setLayout(null);
		   	this.setPreferredSize(new Dimension(WIDTH,HEIGHT));
		   	
		   	
		   	this.setSize(WIDTH, HEIGHT);
		    controller = new Controller();
		    sliderFrequency = new DoubleSliderPanel(this, 100, 5, 70, 150, "frequency");
		    sliderAmplitude = new DoubleSliderPanel(this, 200, 5, 70, 150, "amplitude");
		    sliderDephas     = new DoubleSliderPanel(this, 300, 5, 70, 150, "phase");
		    this.show();  
		    
		    
		}
		
		public String toString () { return "PolymorphController " + this.getName(); }
		
		public void control () { 
			
	    }
		
		public void delta(double dt) {
	       this.majBox();
	       time = time + dt;
	       if (time >= FRAME_TIME) {
	          refresh = true;
	          while (time >= FRAME_TIME) time = time - FRAME_TIME;
	       }
	    }
		
		private void majBox() {
			this.box.amplitude(this.sliderAmplitude.getValue());
			this.box.frequency(this.sliderFrequency.getValue());
			this.box.dephas(this.sliderDephas.getValue());
		}

		private synchronized void adjustShape(ShapeEnum shape) {
			box.waveShape(shape);
		}
		private synchronized void adjustFrequency(double frequency){
			box.frequency(frequency);
		}
		private synchronized void adjustAmplitude(double amplitude){
			box.amplitude(amplitude);
		}
		private synchronized void adjustDephas(double dephas){
			box.dephas(dephas);
		}
		
		  
	   private class Controller implements ItemListener {
		    private CheckboxGroup buttons = new CheckboxGroup();
		    private Checkbox sin, triangle, square, sawtooth, rand, constant;
			     
			public Controller() {
				this.add_const_Checkbox();
			    this.add_sin_Checkbox();
			    this.add_square_Checkbox();
			    this.add_triangle_Checkbox();
			    this.add_sawtooth_Checkbox();
			    this.add_rand_Checkbox();   
			}

			//geometric BOX		
		    private void add_sin_Checkbox () {
		        sin = new java.awt.Checkbox("sinus", buttons, false);
		        sin.setBounds(10,10,70,23);
		        sin.addItemListener(this);
		        PolymorphControllerPanel.this.add(sin); 
		    }	     
			     
		    private void add_triangle_Checkbox () {
		        triangle = new java.awt.Checkbox("triangle", buttons, false);
		        triangle.setBounds(10,40,70,23);
		        triangle.addItemListener(this);
		        PolymorphControllerPanel.this.add(triangle); 
		    }	     
		 
		    private void add_square_Checkbox () {
		        square = new java.awt.Checkbox("square", buttons, false);
		        square.setBounds(10,70,70,23);
		        square.addItemListener(this);
		        PolymorphControllerPanel.this.add(square); 
		    }	
		      	     
		    private void add_sawtooth_Checkbox () {
		        sawtooth = new java.awt.Checkbox("sawtooth", buttons, false);
		        sawtooth.setBounds(10,100,70,23);
		        sawtooth.addItemListener(this);
		        PolymorphControllerPanel.this.add(sawtooth); 
		    }	     
			    
		    private void add_rand_Checkbox () {
		        rand = new java.awt.Checkbox("random", buttons, false);
		        rand.setBounds(10,130,70,23);
		        rand.addItemListener(this);
		        PolymorphControllerPanel.this.add(rand); 
		    }

			private void add_const_Checkbox() {
				constant = new java.awt.Checkbox("const", buttons, false);
		        constant.setBounds(10,160,70,23);
		        constant.addItemListener(this);
		        PolymorphControllerPanel.this.add(constant); 
				
			}
			
		    public void itemStateChanged (ItemEvent e) { 
		        if (e.getSource() == sin) { this.adjustShape(ShapeEnum.SINUS); }
		        if (e.getSource() == triangle) { this.adjustShape(ShapeEnum.TRIANGLE); }
		        if (e.getSource() == square) { this.adjustShape(ShapeEnum.SQUARE); }
		        if (e.getSource() == sawtooth) { this.adjustShape(ShapeEnum.SAWTOOTH); }
		        if (e.getSource() == rand) { this.adjustShape(ShapeEnum.RAND); }
		        if (e.getSource() == constant) { this.adjustShape(ShapeEnum.CONST); }
		    }
		    
		    private void adjustShape(ShapeEnum shape) {
		    	PolymorphControllerPanel.this.adjustShape(shape);
		    }
	   
	   }
	   
	   
	   
	}