// Created by BB on 16/05/11

package generators.signal.polymorph;

public class PolymorphValue implements PolymorphEndPoint{

	//Sert � calculer amplitude par rapport � une fonction 
	
	protected double amplitude;
	protected double frequency;
	protected double dephas;
	protected ShapeEnum shape = ShapeEnum.CONST;
	protected boolean inv = false;
	
	@Override
	public ShapeEnum waveShape() {
		return this.shape;
	}

	@Override
	public double frequency() {
		return this.frequency;
	}

	@Override
	public double amplitude() {
		return this.amplitude;
	}
	
	@Override
	public double dephas() {
		return this.dephas;
	}

	@Override
	public void frequency(double frequency) {
		this.frequency = frequency;
	}

	@Override
	public void amplitude(double amplitude) {
		this.amplitude = amplitude;
	}

	@Override
	public void waveShape(ShapeEnum shape) {
		this.shape = shape;
	}
	
	@Override
	public void waveInv(boolean inv) {
		this.inv = inv;
	}

	@Override
	public void dephas(double dephas) {
		this.dephas = dephas;
		
	}

	@Override
	public boolean waveInv() {

		return inv;
	}

}
