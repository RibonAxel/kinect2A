// Created by BB on 13/05/11

package generators.signal.polymorph;

import generators.signal.Signal;

public class PolymorphWave extends Signal {

   protected static double TWO_PI = (double) (2.0 * Math.PI);
   
   protected double amplitude;
   protected double frequency;
   protected double omega; 
   protected double phase;
   protected double dephas;
   protected ShapeEnum shape;
   protected boolean inv;

   public PolymorphWave (ShapeEnum shape) {
	   this(shape,false);
	   }

   public PolymorphWave (ShapeEnum shape, boolean inv) {
      this.amplitude = 0;
      this.phase     = 0.0;
      this.dephas	 = 0.0;
      this.frequency = 0.0;
      this.shape = shape;
      this.inv = inv;
   }

   public double frequency () { 
      return this.frequency; 
   }
   public void frequency(double frequency) {
      this.frequency = frequency;
      this.omega 	   = TWO_PI * frequency;   
   }
   
   public double amplitude()
   {
	   return this.amplitude;
   }
   public void amplitude(double amplitude)
   {
	   this.amplitude = amplitude;
   }
   
   public double dephas()
   {
	   return this.dephas;
   }
   public void dephas(double dephas)
   {
	   this.dephas = dephas;
   }
   
   public void  open () { 
      super.open();
      phase = 0.0;
   }
      
   public void delta(double dt) {
      phase += omega * dt;
      double truePhase = phase+ dephas*TWO_PI;
      
      if (truePhase > TWO_PI) phase -= TWO_PI;

      switch(shape){
	      case SINUS:   	value = (Math.sin(truePhase)+1)/2;
	      					break;
	      
	      case TRIANGLE:	value = (truePhase<Math.PI)? truePhase/Math.PI:(TWO_PI-(truePhase))/Math.PI;
	      					break;
	      					
	      case SQUARE:		value = (truePhase <= (TWO_PI/2)) ? 0:1;
	      					break;
	      
	      case SAWTOOTH:	value = truePhase/TWO_PI;
	      					break;
	      					
	      case RAND: 		value = Math.random();
	      					break;
	      
	      case CONST: 		value = 1;
	      					break;
	      
	      default: 			break;
      }  
      if(inv == true)
      {
    	  value=1-value;
      }
      value *= amplitude;
      
      

   }
   
   public void changeShape(ShapeEnum shape)
   {  
	   this.shape=shape;
   }
   public ShapeEnum shape()
   {
	   return this.shape;
   }
   
   public void changeInv(boolean inv)
   {  
	   this.inv=inv;
   }
   public boolean inv()
   {
	   return this.inv;
   }
   
}