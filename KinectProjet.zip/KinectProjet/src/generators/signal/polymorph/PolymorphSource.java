// Created by BB on 16/05/11

package generators.signal.polymorph;

import pi.endpoint.Source;

public interface PolymorphSource extends Source{
	public ShapeEnum waveShape();
	public double frequency();
	public double dephas();
	public double amplitude();
	public boolean waveInv();

}
