// Created by BB on 16/05/11

package generators.signal.polymorph;

public enum ShapeEnum {
	CONST, RAND, SAWTOOTH, SQUARE, SINUS, TRIANGLE

}
