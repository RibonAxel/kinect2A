// Created by BB on 13/05/11

package generators.signal.polymorph;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JFrame;
import javax.swing.JLabel;

import pi.executive.ContinuousAgent;


import GUI.DoubleSlider;

public class PolymorphController extends JFrame implements ContinuousAgent{

	
	private static final int       WIDTH   = 530;
    private static final int       HEIGHT  = 270;
    private static final double FRAME_TIME = 0.050;
   
    private double  time    = 0;
    private boolean refresh = true;
    
    private  DoubleSlider sliderFrequency, sliderAmplitude;
	private  JLabel label;
	private Controller controller; 

    private PolymorphValue box;
    

    private PolymorphController(PolymorphValue box){
    	this(box, "polyControler");
    }
    
	public PolymorphController (PolymorphValue box, String name) {
	   	this.box = box;
	   	this.setTitle(name);
	   	this.getContentPane().setLayout(null);
	   	this.setSize(WIDTH, HEIGHT);
	    controller = new Controller();
	    sliderFrequency = new DoubleSlider(this, 20, 5, 150, 150, "frequency");
	    sliderAmplitude = new DoubleSlider(this, 300, 5, 150, 150, "amplitude");
	    
	    this.show();
	}
	
	public String toString () { return "PolymorphController " + this.getTitle(); }
	
	public void control () { 
		
    }
	
	public void delta(double dt) {
       this.majBox();
       time = time + dt;
       if (time >= FRAME_TIME) {
          refresh = true;
          while (time >= FRAME_TIME) time = time - FRAME_TIME;
       }
    }
	
	private void majBox() {
		this.box.amplitude(this.sliderAmplitude.getValue());
		this.box.frequency(this.sliderFrequency.getValue());
	}

	private synchronized void adjustShape(ShapeEnum shape) {
		box.waveShape(shape);
	}
	private synchronized void adjustFrequency(double frequency){
		box.frequency(frequency);
	}
	private synchronized void adjustAmplitude(double amplitude){
		box.amplitude(amplitude);
	}
	
	  
   private class Controller implements ItemListener {
	    private CheckboxGroup buttons = new CheckboxGroup();
	    private Checkbox sin, triangle, square, sawtooth, rand, constant;
		     
		public Controller() {
			this.add_const_Checkbox();
		    this.add_sin_Checkbox();
		    this.add_square_Checkbox();
		    this.add_triangle_Checkbox();
		    this.add_sawtooth_Checkbox();
		    this.add_rand_Checkbox();   
		}

		//geometric BOX		
	    private void add_sin_Checkbox () {
	        sin = new java.awt.Checkbox("sinus", buttons, false);
	        sin.setBounds(10,205,70,23);
	        sin.addItemListener(this);
	        getContentPane().add(sin); 
	    }	     
		     
	    private void add_triangle_Checkbox () {
	        triangle = new java.awt.Checkbox("triangle", buttons, false);
	        triangle.setBounds(80,205,70,23);
	        triangle.addItemListener(this);
	        getContentPane().add(triangle); 
	    }	     
	 
	    private void add_square_Checkbox () {
	        square = new java.awt.Checkbox("square", buttons, false);
	        square.setBounds(160,205,70,23);
	        square.addItemListener(this);
	        getContentPane().add(square); 
	    }	
	      	     
	    private void add_sawtooth_Checkbox () {
	        sawtooth = new java.awt.Checkbox("sawtooth", buttons, false);
	        sawtooth.setBounds(230,205,90,23);
	        sawtooth.addItemListener(this);
	        getContentPane().add(sawtooth); 
	    }	     
		    
	    private void add_rand_Checkbox () {
	        rand = new java.awt.Checkbox("random", buttons, false);
	        rand.setBounds(320,205,70,23);
	        rand.addItemListener(this);
	        getContentPane().add(rand); 
	    }

		private void add_const_Checkbox() {
			constant = new java.awt.Checkbox("const", buttons, false);
	        constant.setBounds(400,205,70,23);
	        constant.addItemListener(this);
	        getContentPane().add(constant); 
			
		}
		
	    public void itemStateChanged (ItemEvent e) { 
	        if (e.getSource() == sin) { this.adjustShape(ShapeEnum.SINUS); }
	        if (e.getSource() == triangle) { this.adjustShape(ShapeEnum.TRIANGLE); }
	        if (e.getSource() == square) { this.adjustShape(ShapeEnum.SQUARE); }
	        if (e.getSource() == sawtooth) { this.adjustShape(ShapeEnum.SAWTOOTH); }
	        if (e.getSource() == rand) { this.adjustShape(ShapeEnum.RAND); }
	        if (e.getSource() == constant) { this.adjustShape(ShapeEnum.CONST); }
	    }
	    
	    private void adjustShape(ShapeEnum shape) {
	    	PolymorphController.this.adjustShape(shape);
	    }
   
   }
   
   
   
}