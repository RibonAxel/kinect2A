// Created by BB on 17/05/11

package generators.signal.polymorph;

import java.net.InetAddress;


import level.DMXLevel;

import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import DMXTransfer.DMXTransferMultiple;
import generators.PolymorphGenerator;
import pi.application.Application;
import pi.container.CompositeContainer;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;

public class TestPolymorphControllerPanel {

	private static final String ADDRESS = "255.255.255.255";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTUREMODE = 1;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTUREPAN    =  7;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTIFIXTUREMODE = {FIXTUREMODE, FIXTUREMODE+11, FIXTUREMODE+22, FIXTUREMODE+33};
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	private static final int[] MULTFIXTUREPAN = {FIXTUREPAN, FIXTUREPAN+11, FIXTUREPAN+22, FIXTUREPAN+33};
	
	public static void test() {
   
		try 
		 {

			
	         InetAddress address = InetAddress.getByName(ADDRESS);
	         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
	         DmxPacket packet = new DmxPacket();
	         
	         String[] names = {"blue", "red", "dimmer", "tilt", "pan", "mode"};
	         Instrument multPoly = new Instrument(names);
	         
	         
	         DoubleValue      S1 = new DoubleValue();     
	 		 PolymorphWave pw = new PolymorphWave(ShapeEnum.CONST);
	 		 PolymorphGenerator  G1 = new PolymorphGenerator(pw, multPoly.getValues().get(0), S1); 
	   
	         DoubleValue      S2 = new DoubleValue();     
	 		 PolymorphWave pw2 = new PolymorphWave(ShapeEnum.CONST);
			 PolymorphGenerator  G2 = new PolymorphGenerator(pw2, multPoly.getValues().get(1), S2); 
	         
	         DoubleValue      S3 = new DoubleValue();    
	 		 PolymorphWave pw3 = new PolymorphWave(ShapeEnum.CONST);
			 PolymorphGenerator  G3 = new PolymorphGenerator(pw3, multPoly.getValues().get(2), S3);
	         
	         DoubleValue      S4 = new DoubleValue();     
	 		 PolymorphWave pw4 = new PolymorphWave(ShapeEnum.CONST);
			 PolymorphGenerator  G4 = new PolymorphGenerator(pw4, multPoly.getValues().get(3), S4);
	         
	         DoubleValue      S5 = new DoubleValue();
	 		 PolymorphWave pw5 = new PolymorphWave(ShapeEnum.SINUS);
			 PolymorphGenerator  G5 = new PolymorphGenerator(pw5, multPoly.getValues().get(4), S5);
			 
			 DoubleValue      S6 = new DoubleValue();     
	 		 PolymorphWave pw6 = new PolymorphWave(ShapeEnum.CONST);
	         PolymorphGenerator  G6 = new PolymorphGenerator(pw6, multPoly.getValues().get(5), S6); 
	         	         
	         DMXUniverse universe = new DMXUniverse();
	         Patch p1 = new Patch(S1);  p1.add(MULTFIXTUREBLUE); 
	         Patch p2 = new Patch(S2);  p2.add(MULTFIXTURERED);
	         Patch p3 = new Patch(S3);  p3.add(MULTFIXTUREDIMMER);
	         Patch p4 = new Patch(S4);  p4.add(MULTFIXTURETILT);
	         Patch p5 = new Patch(S5);  p5.add(MULTFIXTUREPAN);
	         Patch p6 = new Patch(S6);  p6.add(MULTIFIXTUREMODE);
	         
	         universe.add(p1); universe.add(p2); universe.add(p3); universe.add(p4); universe.add(p5); universe.add(p6);
	        	        	         
	        
	         DMXLevel 		L1 = new DMXLevel(universe , "level");
	         DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);

	        // Agent[] agents = (Agent[]) multPoly.getControllers().toArray(new Agent[multPoly.getControllers().size()]);
	         	         	         
	         SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, G2, G3 ,G4, G5,G6, T1, L1});
	         SimpleContainer instrument2 = new SimpleContainer(((Agent[]) multPoly.getControllers().toArray(new Agent[multPoly.getControllers().size()])));
	         CompositeContainer compo = new CompositeContainer();
	         compo.addMember(instrument);
	         compo.addMember(instrument2);
	         Application     application = new Application(compo, 0.025, 0.005);
	      
		   
		   
	         application.start();      
			
		 }
		 catch (Exception e) { e.printStackTrace();	}	 
   }
        
}

