// Created by BB on 16/05/11

package generators.signal.polymorph;

public interface PolymorphSink {
	 public void frequency(double frequency);
	 public void amplitude(double amplitude);
	 public void dephas(double dephas);
	 public void waveShape(ShapeEnum shape);
	 public void waveInv(boolean inv);

}
