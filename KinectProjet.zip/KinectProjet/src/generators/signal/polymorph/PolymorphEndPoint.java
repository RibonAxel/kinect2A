package generators.signal.polymorph;


public interface PolymorphEndPoint extends PolymorphSource, PolymorphSink{

}
