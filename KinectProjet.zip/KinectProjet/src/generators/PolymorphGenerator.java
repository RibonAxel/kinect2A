// Created by BB 16/05/2011

package generators;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.PolymorphWave;
import pi.endpoint.DoubleSink;

public class PolymorphGenerator extends Generator implements PolymorphGeneratorInterface{

	private PolymorphWave behaviour;
	private DoubleSink output;
	private PolymorphValue polyBox;
	    
	public PolymorphGenerator (PolymorphWave behaviour, DoubleSink output){
		this.behaviour = behaviour;
	    this.output    = output;
	    this.polyBox = null;
	    this.initialize();
	}
	
	public PolymorphGenerator (PolymorphWave behaviour, PolymorphValue polyBox, DoubleSink output) {
		this.behaviour = behaviour;
	    this.output    = output;
	    this.polyBox  	   = polyBox;
	    this.initialize();
	}
	   
	private void initialize() {
		behaviour.open();
	}
	   
	public void polyBox(PolymorphValue polyBox){
		this.polyBox = polyBox;
	}
	public PolymorphValue polyBox(){
		return polyBox;
	}
	
	@Override
	public void control () { 
		output.value(behaviour.value());        
	}
	
	@Override
	public void delta (double dt) {
		if(polyBox!= null)
		{
			behaviour.amplitude(polyBox.amplitude());	
			behaviour.frequency(polyBox.frequency());
			behaviour.dephas(polyBox.dephas());
			behaviour.changeShape(polyBox.waveShape());
		}
		if (! behaviour.atEnd()) {
			behaviour.delta(dt);
		}
	}
}
