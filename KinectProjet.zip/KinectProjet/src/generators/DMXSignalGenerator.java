// Created by BB on 05/05/11

package generators;

import generators.signal.DMXSignal;
import pi.endpoint.DMXSink;

public class DMXSignalGenerator extends Generator {
	   
	   private DMXSignal behaviour;
	   private DMXSink output;
	   
	   
	   public DMXSignalGenerator (DMXSignal behaviour, DMXSink output) {
	      this.behaviour = behaviour;
	      this.output	 = output;
	      this.initialize();
	   }
	   
	   private void initialize() {
	      behaviour.open();
	   }
	   
	   public void control () { 
	      output.value(behaviour.value());        
	   }
	   
	   public void delta (double dt) { 
	      if (! behaviour.atEnd()) {
	         behaviour.delta(dt);
	      }
	   }
}
