package generators;

import generators.signal.startStop.StartStopValue;

public interface StartStopGeneratorInterface {
	public void run() ;
	public void stop();
	public boolean running();
	public StartStopValue startStopBox();
	public void startStopBox(StartStopValue startStopBox);
}
