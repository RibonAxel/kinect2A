package generators;

import pi.executive.ContinuousAgent;

public abstract class Generator  implements ContinuousAgent{
	
	
}
