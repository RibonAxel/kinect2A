package generators;

import generators.signal.polymorph.PolymorphValue;

public interface PolymorphGeneratorInterface {
	public void polyBox(PolymorphValue polyBox);
	public PolymorphValue polyBox();
}
