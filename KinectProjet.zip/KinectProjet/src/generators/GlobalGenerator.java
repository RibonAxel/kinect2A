package generators;

import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.startStop.StartStopValue;
import pi.endpoint.DoubleSink;

public class GlobalGenerator extends Generator implements PolymorphGeneratorInterface, StartStopGeneratorInterface{
	
	private PolymorphWave behaviour;
	private DoubleSink output;
	
	private PolymorphValue polyBox;
	private StartStopValue startStopBox;
	
	private boolean run = false;
	private boolean inv;
	    
	public GlobalGenerator (PolymorphWave behaviour, DoubleSink output){
		this(behaviour, null, null, output);
	}
	public GlobalGenerator (PolymorphWave behaviour, PolymorphValue polyBox, DoubleSink output){
		this(behaviour, polyBox, null, output);
	}
	public GlobalGenerator (PolymorphWave behaviour, StartStopValue startStopBox, DoubleSink output){
		this(behaviour, null, startStopBox, output);
	}
	
	public GlobalGenerator (PolymorphWave behaviour, PolymorphValue polyBox, StartStopValue startStopBox, DoubleSink output) {
	    this(behaviour, polyBox, startStopBox, output, false);
	}
	
	public GlobalGenerator (PolymorphWave behaviour, PolymorphValue polyBox, StartStopValue startStopBox, DoubleSink output, boolean inv) {
		this.behaviour = behaviour;
	    this.output    = output;
	    this.polyBox  	   = polyBox;
	    this.startStopBox = startStopBox;
	    this.inv = inv;
	    this.initialize();
	}
	   
	private void initialize() {
		behaviour.open();
	}
	   
	public void polyBox(PolymorphValue polyBox){
		this.polyBox = polyBox;
	}
	public PolymorphValue polyBox(){
		return this.polyBox;
	}
	public void startStopBox(StartStopValue StartStopBox){
		this.startStopBox = startStopBox;
	}
	public StartStopValue startStopBox(){
		return this.startStopBox;
	}

	
   @Override
   public void run() {
	   this.run = true;
	   this.initialize();
   }
   @Override
   public void stop() {
	   this.run = false;
	   output.value(0);
   }
   @Override
   public boolean running() { return this.run; }
	
	
	
	
	@Override
	public void control () { 
	   if(this.run)
	   {
		   output.value(behaviour.value());        
	   }      
	}
	
	@Override
	public void delta (double dt) {
		if(polyBox!= null && run)
		{
			behaviour.amplitude(polyBox.amplitude());	
			behaviour.frequency(polyBox.frequency());
			behaviour.dephas(polyBox.dephas());
			behaviour.changeShape(polyBox.waveShape());
			behaviour.changeInv(polyBox.waveInv());
		}
		if(startStopBox != null)
		{
			if(!this.startStopBox.run() && this.run){
			   this.stop();
		   }
		   if(this.startStopBox.run() && !this.run){
			   this.run();
		   }
		   if (this.run && !this.behaviour.atEnd()) {
			   this.behaviour.delta(dt);
		   }
		}
		else if (! behaviour.atEnd()) {
			behaviour.delta(dt);
			this.run = true;
		}
	}
}