// SignalGenerator.java
// Created by Bernard Thirion 22/04/2011

package generators;

import pi.endpoint.DoubleSink;
import generators.signal.Signal;

public class SignalGenerator extends Generator {
   
   private Signal behaviour;
   private DoubleSink output;
    
   public SignalGenerator (Signal behaviour, DoubleSink output) {
      this.behaviour = behaviour;
      this.output    = output;
      this.initialize();
   }
   
   private void initialize() {
      behaviour.open();
   }
   
   public void control () { 
      output.value(behaviour.value());        
   }
   
   public void delta (double dt) { 
      if (! behaviour.atEnd()) {
         behaviour.delta(dt);
      }
   }
   
}
