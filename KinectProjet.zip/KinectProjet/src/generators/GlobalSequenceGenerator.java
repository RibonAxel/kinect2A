package generators;

import autoIterator.DropBox;
import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.startStop.StartStopValue;
import pi.endpoint.DoubleSink;

public class GlobalSequenceGenerator extends Generator {
	
	private PolymorphWave behaviour;
	private DoubleSink output;
	 
	private DropBox dropBox;
	private StartStopValue globalStartStopValue;
	
	private boolean run = false;
	    
	public GlobalSequenceGenerator (PolymorphWave behaviour, DoubleSink output){
		this(behaviour, null, null, output);
	}
	public GlobalSequenceGenerator (PolymorphWave behaviour, DropBox dropBox, DoubleSink output){
		this(behaviour, dropBox, null, output);
	}
	public GlobalSequenceGenerator (PolymorphWave behaviour, StartStopValue globalStartStopValue, DoubleSink output){
		this(behaviour, null, globalStartStopValue, output);
	}
	
	public GlobalSequenceGenerator (PolymorphWave behaviour, DropBox dropBox, StartStopValue globalStartStopValue, DoubleSink output) {
		this.behaviour = behaviour;
	    this.output    = output;
	    this.dropBox  	   = dropBox;
	    this.globalStartStopValue = globalStartStopValue;
	    this.initialize();
	}
	   
	private void initialize() {
		behaviour.open();
	}
	   
	public void polyBox(DropBox dropBox){
		this.dropBox = dropBox;
	}
	public DropBox dropBox(){
		return this.dropBox;
	}
	public void globalStartStopValue(StartStopValue globalStartStopValue){
		this.globalStartStopValue = globalStartStopValue;
	}
	public StartStopValue globalStartStopBox(){
		return this.globalStartStopValue;
	}

	

   public void run() {
	   this.run = true;
	   this.initialize();
   }

   public void stop() {
	   this.run = false;
	   output.value(0);
   }

   public boolean running() { return this.run; }
	
	
	
	
	@Override
	public void control () { 
	   if(this.run)
	   {
		   output.value(behaviour.value());        
	   }      
	}
	
	@Override
	public void delta (double dt) {
		if(dropBox!= null && run)
		{
			behaviour.amplitude(dropBox.getAmplitude());	
			behaviour.frequency(dropBox.getFrequency());
			behaviour.dephas(dropBox.getDephas());
			behaviour.changeShape(dropBox.getShape());
		}
		if(globalStartStopValue != null)
		{
			if((!this.globalStartStopValue.run() || !this.dropBox.run()) && this.run){
			   this.stop();
		   }
			else if((this.globalStartStopValue.run() && this.dropBox.run()) && !this.run){
			   this.run();
		   }
		   if (this.run && !this.behaviour.atEnd()) {
			   this.behaviour.delta(dt);
		   }
		}
		else if (! behaviour.atEnd()) {
			behaviour.delta(dt);
			this.run = true;
		}
		  

	}
	
}