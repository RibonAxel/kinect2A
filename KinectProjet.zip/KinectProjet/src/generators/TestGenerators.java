//  TestGenerators.java
//  Created by Bernard 22/04/2011

package generators;

import pi.executive.Agent;
import pi.endpoint.DMXValue;
import pi.endpoint.DoubleValue;
import pi.container.Container;
import pi.container.SimpleContainer;
import pi.application.Application;
import oscillo.DMXOscilloscope;
import oscillo.Oscilloscope;

import generators.signal.*;

public class TestGenerators {
   
   public static void test() {
   
      DoubleValue      S1 = new DoubleValue();
      SignalGenerator  G1 = new SignalGenerator(new Sinewave(1.0, 1.0), S1); 
      Oscilloscope     O1 = new Oscilloscope(S1, "generator 1");
      Oscilloscope     O11 = new Oscilloscope(S1, "generator 1 copie");
 
      DoubleValue      S2 = new DoubleValue();
      SignalGenerator  G2 = new SignalGenerator(new SlowDownSinewave(1.0, 1.0, 0.995, 600), S2);
      Oscilloscope     O2 = new Oscilloscope(S2, "generator 2");
 
      DoubleValue      S3 = new DoubleValue();
      Sinewave         W1 = new Sinewave(1.5, 0.5);
      SlowDownSinewave W2 = new SlowDownSinewave(0.5, 0.6, 0.994, 800);
      SignalGenerator  G3 = new SignalGenerator(new Sum(W1, W2), S3);
      Oscilloscope     O3 = new Oscilloscope(S3, "generator 3");
      
	   
      SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, O1, G1,O11, G2,O2, G3,O3});
      Application     application = new Application(instrument, 0.025, 0.005);
      
	   
	   
      application.start();        
   }
        
}
