package coin;

import pi.container.SimpleContainer;
import pi.application.Application;

public class TestCoin {
   
   public static void test() {
        
        SimpleContainer c = new SimpleContainer(
                                         new Coin(System.out)
                                 );
		Application     a = new Application(c, 1.0);
        a.start();        
    }
        
}
