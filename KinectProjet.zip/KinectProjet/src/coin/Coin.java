//  Coin.java
//  Created by Bernard Thirion 16-03-07.

package coin;

import java.io.PrintStream;
import pi.executive.DefaultDiscreteAgent;
import pi.executive.DiscreteAction;
import pi.executive.State;

public class Coin extends DefaultDiscreteAgent {

   private static final int MAX_FIRINGS = 20;
      
   private int firings = 0;
   private PrintStream out;
   
   private class CoinState  extends State { }
   
   private class CoinAction extends DiscreteAction {
   
      private State  then;
      private String name;    
        
      public CoinAction (State from, State then, String name)  { 
         super(from); this.then = then; this.name = name;
      }      
      
      public DefaultDiscreteAgent context() { 
         return Coin.this;  
      }

      public State then() { 
         return then;  
      }

	  public boolean isEnabled() { return (firings < MAX_FIRINGS); }
      
      public void jump()  { 
         firings++;
         out.println (firings + " -> " + name); 
      }
	}
   
   public Coin (PrintStream out) {
      this.out = out;
      CoinState  Idle   = new CoinState(); 
      CoinState  Head   = new CoinState(); 
      CoinState  Tail   = new CoinState();
      CoinAction toss_1 = new CoinAction (Idle, Head, "toss"); 
      CoinAction toss_2 = new CoinAction (Idle, Tail, "toss"); 
      CoinAction heads  = new CoinAction (Head, Idle, "heads"); 
      CoinAction tail   = new CoinAction (Tail, Idle, "tail"); 
      this.adapt(Idle);
   }
   
}
