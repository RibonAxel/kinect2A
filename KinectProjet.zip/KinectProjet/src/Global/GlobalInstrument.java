package Global;
//Created by BB on 17/05/11


import generators.signal.polymorph.PolymorphValue;
import generators.signal.startStop.StartStopValue;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;




public class GlobalInstrument extends JFrame {

	private ArrayList<PolymorphValue> polyBoxs = new ArrayList<PolymorphValue>();
	private ArrayList<StartStopValue> ssBoxs = new ArrayList<StartStopValue>();
	private ArrayList<GlobalController> controllers = new ArrayList<GlobalController>();
		
	public GlobalInstrument(String[] names)
	{
		
		this.setBounds(400, 400, 930, 350);
	
		this.setLayout(new BorderLayout());
		JPanel panel = new JPanel();
		
		panel.setPreferredSize(this.getSize());
		JTabbedPane onglets = new JTabbedPane(SwingConstants.TOP); 
		
		for(int i=0; i< names.length; i++)
		{
			polyBoxs.add(new PolymorphValue());
			ssBoxs.add(new StartStopValue());
			controllers.add(new GlobalController(polyBoxs.get(i), ssBoxs.get(i), names[i]));
			onglets.add(names[i], controllers.get(i));
		}
		
		onglets.setOpaque(true); 
		panel.add(onglets); 
			
		this.getContentPane().add(panel, BorderLayout.CENTER);				
		this.setVisible(true);
	
	}
	
	public ArrayList<GlobalController> getControllers(){
		return this.controllers;
	}
	
	
	
	public ArrayList<PolymorphValue> getPolyBoxs(){
		return this.polyBoxs;
	}
	
	public ArrayList<StartStopValue> getssBoxs(){
		return this.ssBoxs;
	}
     
}

