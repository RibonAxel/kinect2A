package Global;



	// Created by BB on 18/05/11

		import generators.signal.polymorph.PolymorphValue;
import generators.signal.polymorph.ShapeEnum;
import generators.signal.startStop.StartStopController;
import generators.signal.startStop.StartStopValue;

import java.awt.Checkbox;
		import java.awt.CheckboxGroup;
		import java.awt.Dimension;
		import java.awt.event.ItemEvent;
		import java.awt.event.ItemListener;

		import javax.swing.JLabel;
		import javax.swing.JPanel;

		
		import GUI.DoubleSliderPanel;
		
import pi.executive.ContinuousAgent;


		public class GlobalController extends JPanel implements ContinuousAgent{

			//cr�e les sliders 
			private static final int       WIDTH   = 830;
		    private static final int       HEIGHT  = 240;
		    private static final double FRAME_TIME = 0.050;
		   
		    private double  time    = 0;
		    private boolean refresh = true;
		    
		    private  DoubleSliderPanel sliderFrequency;
			private  DoubleSliderPanel sliderAmplitude;
			private  DoubleSliderPanel sliderDephas;
			private  JLabel label;
			private Controller controller; 

		    private PolymorphValue box;
		    private StartStopValue ssbox;
			
		    

		    private GlobalController(PolymorphValue box, StartStopValue ssbox){
		    	this(box,ssbox, "GlobalControler");
		    }
		    

			public GlobalController(PolymorphValue box,StartStopValue ssbox, String name) {
				this.ssbox=ssbox;
			   	this.box = box;
			   	this.setName(name);
			   	this.setLayout(null);
			   	this.setPreferredSize(new Dimension(WIDTH,HEIGHT));
			   	
			   	
			   	this.setSize(WIDTH, HEIGHT);
			    controller = new Controller();
			    sliderFrequency = new DoubleSliderPanel(this, 100, 5, 70, 150, "frequency");
			    sliderAmplitude = new DoubleSliderPanel(this, 200, 5, 70, 150, "amplitude");
			    sliderDephas     = new DoubleSliderPanel(this, 300, 5, 70, 150, "phase");
			    this.show();  
			    
			    
			}
			
			public String toString () { return "PolymorphController " + this.getName(); }
			
			public void control () { 
				
		    }
			
			public void delta(double dt) {
		       this.majBox();
		       time = time + dt;
		       if (time >= FRAME_TIME) {
		          refresh = true;
		          while (time >= FRAME_TIME) time = time - FRAME_TIME;
		       }
		    }
			
			private synchronized void adjustRun(boolean run) {
				ssbox.run(run);
			}	
			
			private void majBox() {
				this.box.amplitude(this.sliderAmplitude.getValue());
				this.box.frequency(this.sliderFrequency.getValue());
				this.box.dephas(this.sliderDephas.getValue());
			}

			private synchronized void adjustShape(ShapeEnum shape) {
				box.waveShape(shape);
			}
			private synchronized void adjustInv(boolean inv) {
				box.waveInv(inv);
			}
			private synchronized void adjustFrequency(double frequency){
				box.frequency(frequency);
			}
			private synchronized void adjustAmplitude(double amplitude){
				box.amplitude(amplitude);
			}
			private synchronized void adjustDephas(double dephas){
				box.dephas(dephas);
			}
			
			  
		   private class Controller implements ItemListener {
			    private CheckboxGroup buttons = new CheckboxGroup();
			    private CheckboxGroup ssbuttons = new CheckboxGroup();
			    private CheckboxGroup invbuttons = new CheckboxGroup();
			    private Checkbox sin, triangle, square, sawtooth, rand, constant, start, stop, inv, normal;
				     
				public Controller() {
					this.add_const_Checkbox();
				    this.add_sin_Checkbox();
				    this.add_square_Checkbox();
				    this.add_triangle_Checkbox();
				    this.add_sawtooth_Checkbox();
				    this.add_rand_Checkbox();   
				    this.add_start_Checkbox();   
				    this.add_stop_Checkbox();  
				    this.add_normal_Checkbox();
				    this.add_inv_Checkbox();
				}

				//geometric BOX		
			    private void add_sin_Checkbox () {
			        sin = new java.awt.Checkbox("sinus", buttons, false);
			        sin.setBounds(10,10,70,23);
			        sin.addItemListener(this);
			        GlobalController.this.add(sin); 
			    }	     
				     
			    private void add_triangle_Checkbox () {
			        triangle = new java.awt.Checkbox("triangle", buttons, false);
			        triangle.setBounds(10,40,70,23);
			        triangle.addItemListener(this);
			        GlobalController.this.add(triangle); 
			    }	     
			 
			    private void add_square_Checkbox () {
			        square = new java.awt.Checkbox("square", buttons, false);
			        square.setBounds(10,70,70,23);
			        square.addItemListener(this);
			        GlobalController.this.add(square); 
			    }	
			      	     
			    private void add_sawtooth_Checkbox () {
			        sawtooth = new java.awt.Checkbox("sawtooth", buttons, false);
			        sawtooth.setBounds(10,100,80,23);
			        sawtooth.addItemListener(this);
			        GlobalController.this.add(sawtooth); 
			    }	     
				    
			    private void add_rand_Checkbox () {
			        rand = new java.awt.Checkbox("random", buttons, false);
			        rand.setBounds(10,130,70,23);
			        rand.addItemListener(this);
			        GlobalController.this.add(rand); 
			    }

				private void add_const_Checkbox() {
					constant = new java.awt.Checkbox("const", buttons, false);
			        constant.setBounds(10,160,70,23);
			        constant.addItemListener(this);
			        GlobalController.this.add(constant); 
					
				}
				
				//startstop BOX
				
				private void add_start_Checkbox() {
					start = new java.awt.Checkbox("start", ssbuttons, true);
			        start.setBounds(420,40,70,23);
			        start.addItemListener(this);
			        GlobalController.this.add(start); 
					
				}
				
				private void add_stop_Checkbox() {
					stop = new java.awt.Checkbox("stop", ssbuttons, false);
			        stop.setBounds(420,70,70,23);
			        stop.addItemListener(this);
			        GlobalController.this.add(stop); 
					
				}
				
				//inversion BOX
				
				private void add_normal_Checkbox() {
					normal = new java.awt.Checkbox("normal", invbuttons, true);
			        normal.setBounds(420,110,70,23);
			        normal.addItemListener(this);
			        GlobalController.this.add(normal); 
				}
				private void add_inv_Checkbox() {
					inv = new java.awt.Checkbox("inv", invbuttons, false);
			        inv.setBounds(420,140,70,23);
			        inv.addItemListener(this);
			        GlobalController.this.add(inv); 
				}
				
			    public void itemStateChanged (ItemEvent e) { 
			        if (e.getSource() == sin) { this.adjustShape(ShapeEnum.SINUS); }
			        if (e.getSource() == triangle) { this.adjustShape(ShapeEnum.TRIANGLE); }
			        if (e.getSource() == square) { this.adjustShape(ShapeEnum.SQUARE); }
			        if (e.getSource() == sawtooth) { this.adjustShape(ShapeEnum.SAWTOOTH); }
			        if (e.getSource() == rand) { this.adjustShape(ShapeEnum.RAND); }
			        if (e.getSource() == constant) { this.adjustShape(ShapeEnum.CONST); }
			        if (e.getSource() == start) { this.adjustRun(true);  }
			        if (e.getSource() == stop) {  this.adjustRun(false); }
			        if (e.getSource() == normal) {  this.adjustInv(false); }
			        if (e.getSource() == inv) {  this.adjustInv(true); }
			    }
			    private void adjustRun(boolean run) {
			    	GlobalController.this.adjustRun(run);
			    }
			    private void adjustShape(ShapeEnum shape) {
			    	GlobalController.this.adjustShape(shape);
			    } 
			    private void adjustInv(boolean inv) {
			    	GlobalController.this.adjustInv(inv);
			    } 

		   
		   }
		   
		   
		   
		}