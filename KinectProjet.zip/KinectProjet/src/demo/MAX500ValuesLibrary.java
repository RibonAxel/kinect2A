package demo;

public class MAX500ValuesLibrary {

	public static final double GOBO_OPEN  	= 5.0/255.0;
	public static final double GOBO_1     	= 15.0/255.0;
	public static final double GOBO_2    	= 25.0/255.0;
	public static final double GOBO_3     	= 35.0/255.0;
	public static final double GOBO_4   	= 45.0/255.0;
	public static final double GOBO_5   	= 55.0/255.0;
	public static final double GOBO_6      = 65.0/255.0;
	public static final double GOBO_7     	= 75.0/255.0;
	public static final double GOBO_8     	= 85.0/255.0;
	public static final double GOBO_9     	= 95.0/255.0;
	public static final double SHAKEGOBO_9 = 105.0/255.0;
	public static final double SHAKEGOBO_8 = 120.0/255.0;
	public static final double SHAKEGOBO_7 = 135.0/255.0;
	public static final double SHAKEGOBO_6 = 150.0/255.0;
	public static final double SHAKEGOBO_5 = 165.0/255.0;
	public static final double SHAKEGOBO_4 = 180.0/255.0;
	public static final double SHAKEGOBO_3 = 195.0/255.0;
	public static final double SHAKEGOBO_2 = 110.0/255.0;
	public static final double SHAKEGOBO_1 = 225.0/255.0;
	public static final double TURNINGWHEEL= 240.0/255.0;

	public static final double SHUTTERCLOSE= 5.0/255.0;
	public static final double SHUTTEROPEN= 40.0/255.0;
	
		
}
