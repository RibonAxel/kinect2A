package demo;


//Created by BB on 27/05/11

import java.net.InetAddress;


import level.DMXLevel;

import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import DMXTransfer.DMXTransferMultiple;
import Global.GlobalInstrument;
import generators.GlobalGenerator;
import generators.PolymorphGenerator;
import generators.signal.polymorph.Instrument;
import generators.signal.polymorph.PolymorphWave;
import generators.signal.polymorph.ShapeEnum;
import pi.application.Application;
import pi.container.CompositeContainer;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;

public class TestControlDirect {

	private static final String ADDRESS = "10.59.1.2";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	private static final int FIXTURE1 = 113;
	private static final int FIXTURE2 = 114;
	private static final int FIXTURE3 = 3;
	private static final int FIXTURE4 = 4;
	private static final int FIXTURE5 = 5;
	private static final int FIXTURE6 = 6;
	private static final int FIXTURE7  = 7;
	private static final int FIXTURE8  = 8;
	private static final int FIXTURE9  = 9;
	private static final int FIXTURE10  = 10;
	private static final int FIXTURE11  = 11;
	private static final int FIXTURE12  = 12;
	private static final int FIXTURE13  = 13;
	private static final int FIXTURE14  = 14;
	private static final int FIXTURE15  = 15;
	private static final int FIXTURE16  = 16;
	private static final int FIXTURE17  = 17;
 //jusqu'a 123
	public static void test() {
 
		try 
		 {

	         InetAddress address = InetAddress.getByName(ADDRESS);
	         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
	         DmxPacket packet = new DmxPacket();
	         
	         String[] names = {"1", "2", "3", "4", "5", "6","7","8","9","10","11","12","13","14","15","16","17"};
	         GlobalInstrument multPoly = new GlobalInstrument(names);
	         
	         //juste same idea 
	         
	         DoubleValue      S1 = new DoubleValue();     
	 		 PolymorphWave pw = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G1 = new GlobalGenerator(pw, multPoly.getPolyBoxs().get(0),  multPoly.getssBoxs().get(0), S1); 
	   
	         DoubleValue      S2 = new DoubleValue();     
	 		 PolymorphWave pw2 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G2 = new GlobalGenerator(pw2, multPoly.getPolyBoxs().get(1),  multPoly.getssBoxs().get(1), S2); 
	         
	         DoubleValue      S3 = new DoubleValue();    
	 		 PolymorphWave pw3 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G3 = new GlobalGenerator(pw3, multPoly.getPolyBoxs().get(2),  multPoly.getssBoxs().get(2), S3); 
	         
	         DoubleValue      S4 = new DoubleValue();     
	 		 PolymorphWave pw4 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G4 = new GlobalGenerator(pw4, multPoly.getPolyBoxs().get(3),  multPoly.getssBoxs().get(3), S4); 
	         
	         DoubleValue      S5 = new DoubleValue();
	 		 PolymorphWave pw5 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G5 = new GlobalGenerator(pw5, multPoly.getPolyBoxs().get(4),  multPoly.getssBoxs().get(4), S5); 
			 
			 DoubleValue      S6 = new DoubleValue();     
	 		 PolymorphWave pw6 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G6 = new GlobalGenerator(pw6, multPoly.getPolyBoxs().get(5),  multPoly.getssBoxs().get(5), S6); 
			 
			 DoubleValue      S7 = new DoubleValue();     
	 		 PolymorphWave pw7 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G7 = new GlobalGenerator(pw7, multPoly.getPolyBoxs().get(6),  multPoly.getssBoxs().get(6), S7); 
			 
			 DoubleValue      S8 = new DoubleValue();     
	 		 PolymorphWave pw8 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G8= new GlobalGenerator(pw8, multPoly.getPolyBoxs().get(7),  multPoly.getssBoxs().get(7), S8); 
			 
			 DoubleValue      S9 = new DoubleValue();     
	 		 PolymorphWave pw9 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G9 = new GlobalGenerator(pw9, multPoly.getPolyBoxs().get(8),  multPoly.getssBoxs().get(8), S9); 
			 
			 DoubleValue      S10 = new DoubleValue();     
	 		 PolymorphWave pw10 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G10= new GlobalGenerator(pw10, multPoly.getPolyBoxs().get(9),  multPoly.getssBoxs().get(9), S10); 
			 
			 DoubleValue      S11 = new DoubleValue();     
	 		 PolymorphWave pw11 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G11 = new GlobalGenerator(pw11, multPoly.getPolyBoxs().get(10),  multPoly.getssBoxs().get(10), S11); 
	 		 
			 
			 DoubleValue      S12 = new DoubleValue();     
	 		 PolymorphWave pw12 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G12 = new GlobalGenerator(pw12, multPoly.getPolyBoxs().get(11),  multPoly.getssBoxs().get(11), S12); 
			 
			 DoubleValue      S13 = new DoubleValue();     
	 		 PolymorphWave pw13 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G13 = new GlobalGenerator(pw13, multPoly.getPolyBoxs().get(12),  multPoly.getssBoxs().get(12), S13); 
			 
			 DoubleValue      S14 = new DoubleValue();     
	 		 PolymorphWave pw14 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G14 = new GlobalGenerator(pw14, multPoly.getPolyBoxs().get(13),  multPoly.getssBoxs().get(13), S14); 
			 
			 DoubleValue      S15 = new DoubleValue();     
	 		 PolymorphWave pw15 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G15 = new GlobalGenerator(pw15, multPoly.getPolyBoxs().get(14),  multPoly.getssBoxs().get(14), S15); 
			 
			 DoubleValue      S16 = new DoubleValue();     
	 		 PolymorphWave pw16 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G16 = new GlobalGenerator(pw16, multPoly.getPolyBoxs().get(15),  multPoly.getssBoxs().get(15), S16); 
			 
			 DoubleValue      S17 = new DoubleValue();     
	 		 PolymorphWave pw17 = new PolymorphWave(ShapeEnum.CONST);
	 		 GlobalGenerator  G17 = new GlobalGenerator(pw17, multPoly.getPolyBoxs().get(16),  multPoly.getssBoxs().get(16), S17); 
	         
			 
			
	         DMXUniverse universe = new DMXUniverse();
	         Patch p1 = new Patch(S1);  p1.add(FIXTURE1); 
	         Patch p2 = new Patch(S2);  p2.add(FIXTURE2);
	         Patch p3 = new Patch(S3);  p3.add(FIXTURE3);
	         Patch p4 = new Patch(S4);  p4.add(FIXTURE4);
	         Patch p5 = new Patch(S5);  p5.add(FIXTURE5);
	         Patch p6 = new Patch(S6);  p6.add(FIXTURE6);
	         Patch p7 = new Patch(S7);  p7.add(FIXTURE7);
	         Patch p8 = new Patch(S8);  p8.add(FIXTURE8);
	         Patch p9 = new Patch(S9);  p9.add(FIXTURE9);
	         Patch p10 = new Patch(S10);  p10.add(FIXTURE10);
	         Patch p11 = new Patch(S11);  p11.add(FIXTURE11);
	         
	         Patch p12 = new Patch(S12);  p12.add(FIXTURE12);
	         Patch p13 = new Patch(S13);  p13.add(FIXTURE13);
	         Patch p14 = new Patch(S14);  p14.add(FIXTURE14);
	         Patch p15 = new Patch(S15);  p15.add(FIXTURE15);
	         Patch p16 = new Patch(S16);  p16.add(FIXTURE16);
	         Patch p17 = new Patch(S17);  p17.add(FIXTURE17);
	         
	         universe.add(p1); universe.add(p2); universe.add(p3); universe.add(p4); universe.add(p5); universe.add(p6);
	         universe.add(p7);universe.add(p8);universe.add(p9);universe.add(p10);universe.add(p11);universe.add(p12);
	         universe.add(p13);universe.add(p14);universe.add(p15);universe.add(p16);universe.add(p17);
	        	        	         
	        
	         DMXLevel 		L1 = new DMXLevel(universe , "level");
	         DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);

	        // Agent[] agents = (Agent[]) multPoly.getControllers().toArray(new Agent[multPoly.getControllers().size()]);
	         	         	         
	         SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, G2, G3 ,G4, G5,G6,G7,G8,G9,G10,G11,G12,G13,G14,G15,G16,G17, T1, L1});
	         SimpleContainer instrument2 = new SimpleContainer(((Agent[]) multPoly.getControllers().toArray(new Agent[multPoly.getControllers().size()])));
	         CompositeContainer compo = new CompositeContainer();
	         compo.addMember(instrument);
	         compo.addMember(instrument2);
	         Application     application = new Application(compo, 0.025, 0.005);
	      
	         application.start();      
			
		 }
		 catch (Exception e) { e.printStackTrace();	}	 
 }
      
}

