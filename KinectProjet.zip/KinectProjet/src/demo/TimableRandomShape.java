package demo;

import pi.endpoint.AdaptaterDoubleValueToDropBox;
import pi.endpoint.DoubleValue;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.DropBox;
import autoIterator.command.Interpolation;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;
import autoIterator.command.shape.Shape;

public class TimableRandomShape extends Shape {

	private int nbrOfMove;

	private DropBox tiltBox, panBox;
	
	public TimableRandomShape(int nbrOfMove, CommandTime oneMoveTime, DropBox tiltBox, DropBox panBox){
		super(oneMoveTime);
		this.nbrOfMove = nbrOfMove;
		
		this.tiltBox = tiltBox;
		this.panBox = panBox;
	}
		
	public TimableRandomShape(int nbrOfMove, CommandTime oneMoveTime, DoubleValue tiltBox, DoubleValue panBox){
		this(nbrOfMove, oneMoveTime, new AdaptaterDoubleValueToDropBox(tiltBox), new AdaptaterDoubleValueToDropBox(panBox));
	}
	
	private void createShape() {
		double startPan = this.panBox.getAmplitude();
		double startTilt = this.tiltBox.getAmplitude();
		
		this.shape = new Sequence();
		
		for(int i=0; i<nbrOfMove; i++)
		{
			double targetPan = Math.random();
			double targetTilt = Math.random();
			Parallele p = new Parallele();
			p.addCommand(new Interpolation(startTilt, targetTilt, new CommandTime(this.executionTime, TimeScaleEnum.ECLAT), tiltBox));
			p.addCommand(new Interpolation(startPan , targetPan, new CommandTime(this.executionTime, TimeScaleEnum.ECLAT), panBox));
			
			this.shape.addCommand(p);
		//	this.shape.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.SEC)));
			
			startPan = targetPan;
			startTilt = targetTilt;
		}
	}
	
	@Override
	public void begin() {
		this.isExhausted = false;
		this.createShape();
		this.shape.begin();
	}

	@Override
	public void reverseBegin() {
		this.isExhausted = false;
		this.createShape();
		this.shape.reverseBegin();
	}
	
	@Override
	public void control() {
		if(!this.shape.isExhausted())
			this.shape.control();
		
	}

	@Override
	public void execute(double dt) {
		if(!this.shape.isExhausted()){
			this.shape.execute(dt);
		}
		else{
			this.isExhausted = true;
		}
	}
}