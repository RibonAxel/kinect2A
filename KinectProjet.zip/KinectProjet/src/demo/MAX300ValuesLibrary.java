package demo;

public class MAX300ValuesLibrary {

	public static final double GOBO_OPEN   = 5.0/255.0;
	public static final double GOBO_1      = 15.0/255.0;
	public static final double GOBO_2      = 25.0/255.0;
	public static final double GOBO_3      = 35.0/255.0;
	public static final double GOBO_4	   = 45.0/255.0;
	public static final double GOBO_5      = 55.0/255.0;
	public static final double GOBO_6      = 65.0/255.0;
	public static final double GOBO_7      = 75.0/255.0;
	public static final double SHAKEGOBO_7 = 85.0/255.0;
	public static final double SHAKEGOBO_6 = 110.0/255.0;
	public static final double SHAKEGOBO_5 = 130.0/255.0;
	public static final double SHAKEGOBO_4 = 150.0/255.0;
	public static final double SHAKEGOBO_3 = 170.0/255.0;
	public static final double SHAKEGOBO_2 = 190.0/255.0;
	public static final double SHAKEGOBO_1 = 210.0/255.0;
	public static final double GOBOTURNINGWHEELSLOW= 222.0/255.0;
	public static final double GOBOTURNINGWHEELFAST= 227.0/255.0;

	
	public static final double SHUTTERCLOSE = 5.0/255.0;
	public static final double SHUTTEROPEN  = 40.0/255.0;
	
	
	public static final double COLORWHEELWHITE    = 10.0/255.0;
	public static final double COLORWHEELRED  = 20.0/255.0;
	public static final double COLORWHEELYELLOW  = 40.0/255.0;
	public static final double COLORWHEELGREEN  = 50.0/255.0;
	public static final double COLORWHEELPINK  = 70.0/255.0;
	public static final double COLORWHEELBLUE  = 80.0/255.0;
	public static final double COLORWHEELORANGE  = 100.0/255.0;
	public static final double COLORWHEELMAGENTA  = 110.0/255.0;
	public static final double COLORWHEELLIGHTBLUE  = 125.0/255.0;
	public static final double COLORWHEELLIGHTGREEN  = 140.0/255.0;
	public static final double COLORWHEELTURNING  = 170.0/255.0;

}
