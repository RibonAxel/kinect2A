package demo;

import java.net.InetAddress;

import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.AdaptaterInverserDoubleValue;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import universe.DMXUniverse;
import universe.Patch;
import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.AdaptaterOneToSeveralBox;
import autoIterator.AutoSequencerController;
import autoIterator.CommandBox;
import autoIterator.FixturesGroup;
import autoIterator.SequencerController;
import autoIterator.SequencerControllerV2;
import autoIterator.SequencerParam;
import autoIterator.SequencerParametrable;
import autoIterator.Sequenceur;
import autoIterator.command.Chaser;
import autoIterator.command.Command;
import autoIterator.command.Fan;
import autoIterator.command.Interpolation;
import autoIterator.command.LightOnGroups;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;

public class Demo1 {

	private static final String ADDRESS = "10.59.1.2"; //10.59.1.4  new address?
	private static final int ARTNET_PORT = 6454; // 8000  new port???
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	public static void test() {
		   
		try 
		{
			InetAddress address = InetAddress.getByName(ADDRESS); //mix IP et du port
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);
			DmxPacket packet = new DmxPacket(); //Cr�ation de Liste de channel
			
			DMXUniverse universe = new DMXUniverse(); //Cr�ation d'une liste de patch

			
			//max36 1 and 2
			DoubleValue	Max36_1Pan = new DoubleValue(); 	DoubleValue	Max36_2Pan = new DoubleValue(); 
			DoubleValue	Max36_1Tilt = new DoubleValue(); 	DoubleValue	Max36_2Tilt = new DoubleValue();
			DoubleValue	Max36_1Red = new DoubleValue(); 	DoubleValue	Max36_2Red = new DoubleValue();
			DoubleValue	Max36_1Blue = new DoubleValue(); 	DoubleValue	Max36_2Blue = new DoubleValue();
			DoubleValue	Max36_1Green = new DoubleValue(); 	DoubleValue	Max36_2Green = new DoubleValue(); 
			DoubleValue	Max36_1Dimmer = new AdaptaterInverserDoubleValue( new DoubleValue()); 	DoubleValue	Max36_2Dimmer = new AdaptaterInverserDoubleValue(new DoubleValue()); 
			DoubleValue	Max36_1Strobe = new DoubleValue();	DoubleValue	Max36_2Strobe = new DoubleValue(); 
			Patch pMax36_1Pan = new Patch(Max36_1Pan); 			pMax36_1Pan.add(FixtureLibrary.MAX36_1PAN); 		universe.add(pMax36_1Pan);	
			Patch pMax36_2Pan = new Patch(Max36_2Pan); 			pMax36_2Pan.add(FixtureLibrary.MAX36_2PAN); 		universe.add(pMax36_2Pan);
			Patch pMax36_1Tilt = new Patch(Max36_1Tilt); 		pMax36_1Tilt.add(FixtureLibrary.MAX36_1TILT);		universe.add(pMax36_1Tilt);
			Patch pMax36_2Tilt = new Patch(Max36_2Tilt); 		pMax36_2Tilt.add(FixtureLibrary.MAX36_2TILT); 		universe.add(pMax36_2Tilt);
			Patch pMax36_1Red = new Patch(Max36_1Red); 			pMax36_1Red.add(FixtureLibrary.MAX36_1RED); 		universe.add(pMax36_1Red);
			Patch pMax36_2Red = new Patch(Max36_2Red); 			pMax36_2Red.add(FixtureLibrary.MAX36_2RED); 		universe.add(pMax36_2Red);
			Patch pMax36_1Blue = new Patch(Max36_1Blue); 		pMax36_1Blue.add(FixtureLibrary.MAX36_1BLUE); 		universe.add(pMax36_1Blue);
			Patch pMax36_2Blue = new Patch(Max36_2Blue); 		pMax36_2Blue.add(FixtureLibrary.MAX36_2BLUE); 		universe.add(pMax36_2Blue);
			Patch pMax36_1Green = new Patch(Max36_1Green); 		pMax36_1Green.add(FixtureLibrary.MAX36_1GREEN); 	universe.add(pMax36_1Green);
			Patch pMax36_2Green = new Patch(Max36_2Green);		pMax36_2Green.add(FixtureLibrary.MAX36_2GREEN); 	universe.add(pMax36_2Green);
			Patch pMax36_1Dimmer = new Patch(Max36_1Dimmer);	pMax36_1Dimmer.add(FixtureLibrary.MAX36_1DIMMER); 	universe.add(pMax36_1Dimmer);
			Patch pMax36_2Dimmer = new Patch(Max36_2Dimmer);	pMax36_2Dimmer.add(FixtureLibrary.MAX36_2DIMMER); 	universe.add(pMax36_2Dimmer);
			Patch pMax36_1Strobe = new Patch(Max36_1Strobe);	pMax36_1Strobe.add(FixtureLibrary.MAX36_1STROBE); 	universe.add(pMax36_1Strobe);
			Patch pMax36_2Strobe = new Patch(Max36_2Strobe);	pMax36_2Strobe.add(FixtureLibrary.MAX36_2STROBE); 	universe.add(pMax36_2Strobe);
			Max36_1Dimmer.value(0);  Max36_2Dimmer.value(0);
			
/*
			//max500
			DoubleValue	Max500Pan = new DoubleValue(); 	
			DoubleValue	Max500Tilt = new DoubleValue(); 	
			DoubleValue	Max500ColorWheel = new DoubleValue(); 	
			DoubleValue	Max500Gobo = new DoubleValue(); 	
			DoubleValue	Max500TurningGobo = new DoubleValue();
			DoubleValue	Max500TurningSpeed = new DoubleValue();
			DoubleValue	Max500Prism = new DoubleValue(); 	
			DoubleValue	Max500Focus = new DoubleValue();
			DoubleValue	Max500Dimmer = new DoubleValue();
			DoubleValue	Max500Shutter = new DoubleValue(); 	
			DoubleValue	Max500Control = new DoubleValue();
			Patch pMax500Pan = new Patch(Max500Pan); 					pMax500Pan.add(FixtureLibrary.MAX500PAN); 						universe.add(pMax500Pan);	
			Patch pMax500Tilt = new Patch(Max500Tilt); 					pMax500Tilt.add(FixtureLibrary.MAX500TILT); 					universe.add(pMax500Tilt);	
			Patch pMax500ColorWheel = new Patch(Max500ColorWheel); 		pMax500ColorWheel.add(FixtureLibrary.MAX500COLORWHEEL); 		universe.add(pMax500ColorWheel);	
			Patch pMax500Gobo = new Patch(Max500Gobo); 					pMax500Gobo.add(FixtureLibrary.MAX500GOBO); 					universe.add(pMax500Gobo);	
			Patch pMax500TurningGobo = new Patch(Max500TurningGobo); 	pMax500TurningGobo.add(FixtureLibrary.MAX500TURNINGGOBO); 		universe.add(pMax500TurningGobo);
			Patch pMax500TurningSpeed = new Patch(Max500TurningSpeed); 	pMax500TurningSpeed.add(FixtureLibrary.MAX500TURNINGSPEED); 	universe.add(pMax500TurningSpeed);	
			Patch pMax500Prism = new Patch(Max500Prism); 				pMax500Prism.add(FixtureLibrary.MAX500PRISM); 					universe.add(pMax500Prism);
			Patch pMax500Focus = new Patch(Max500Focus); 				pMax500Focus.add(FixtureLibrary.MAX500FOCUS); 					universe.add(pMax500Focus);
			Patch pMax500Dimmer = new Patch(Max500Dimmer); 				pMax500Dimmer.add(FixtureLibrary.MAX500DIMMER); 				universe.add(pMax500Dimmer);
			Patch pMax500Shutter = new Patch(Max500Shutter); 			pMax500Shutter.add(FixtureLibrary.MAX500SHUTTER); 				universe.add(pMax500Shutter);
			Patch pMax500Control = new Patch(Max500Control); 			pMax500Control.add(FixtureLibrary.MAX500CONTROL); 				universe.add(pMax500Control);	
			Max500Shutter.value(1);
*/		
			
			//Acrobat
			DoubleValue	AcrobatX = new DoubleValue(); 	
			DoubleValue	AcrobatY = new DoubleValue(); 	
			DoubleValue	AcrobatZ = new DoubleValue(); 	
			DoubleValue	AcrobatSpeed = new DoubleValue(); 	
			DoubleValue	AcrobatRed = new DoubleValue(); 	
			DoubleValue	AcrobatGreen = new DoubleValue();
			DoubleValue	AcrobatBlue = new DoubleValue();
			DoubleValue	AcrobatDimmer = new DoubleValue(); 	
			DoubleValue	AcrobatStrobe = new DoubleValue();
			DoubleValue	AcrobatAuto = new DoubleValue();
			DoubleValue	AcrobatMacroXYZ = new DoubleValue(); 	
			Patch pAcrobatX = new Patch(AcrobatX); 				 pAcrobatX.add(FixtureLibrary.ACROBATPAN); 				universe.add(pAcrobatX);	
			Patch pAcrobatY = new Patch(AcrobatY);				 pAcrobatY.add(FixtureLibrary.ACROBATTILT1); 				universe.add(pAcrobatY);	
			Patch pAcrobatZ = new Patch(AcrobatZ); 				 pAcrobatZ.add(FixtureLibrary.ACROBATTILT2); 				universe.add(pAcrobatZ);	
			Patch pAcrobatSpeed = new Patch(AcrobatSpeed); 		 pAcrobatSpeed.add(FixtureLibrary.ACROBATSPEED); 		universe.add(pAcrobatSpeed);	
			Patch pAcrobatRed = new Patch(AcrobatRed); 			 pAcrobatRed.add(FixtureLibrary.ACROBATRED); 			universe.add(pAcrobatRed);	
			Patch pAcrobatGreen = new Patch(AcrobatGreen); 		 pAcrobatGreen.add(FixtureLibrary.ACROBATGREEN); 		universe.add(pAcrobatGreen);	
			Patch pAcrobatBlue = new Patch(AcrobatBlue); 		 pAcrobatBlue.add(FixtureLibrary.ACROBATBLUE); 			universe.add(pAcrobatBlue);	
			Patch pAcrobatDimmer = new Patch(AcrobatDimmer);	 pAcrobatDimmer.add(FixtureLibrary.ACROBATDIMMER); 		universe.add(pAcrobatDimmer);	
			Patch pAcrobatStrobe = new Patch(AcrobatStrobe);	 pAcrobatStrobe.add(FixtureLibrary.ACROBATSTROBE); 		universe.add(pAcrobatStrobe);	
			Patch pAcrobatAuto = new Patch(AcrobatAuto); 		 pAcrobatAuto.add(FixtureLibrary.ACROBATAUTO); 			universe.add(pAcrobatAuto);	
			Patch pAcrobatMacroXYZ = new Patch(AcrobatMacroXYZ); pAcrobatMacroXYZ.add(FixtureLibrary.ACROBATMACROXYZ); 	universe.add(pAcrobatMacroXYZ);	

			//MAX300
			DoubleValue	Max300Pan = new DoubleValue(); 	
			DoubleValue	Max300Tilt = new DoubleValue(); 	
			DoubleValue	Max300ColorWheel = new DoubleValue(); 	
			DoubleValue	Max300Gobo = new DoubleValue(); 	
			DoubleValue	Max300TurningGobo = new DoubleValue();
			DoubleValue	Max300TurningSpeed = new DoubleValue();
			DoubleValue	Max300Prism = new DoubleValue(); 	
			DoubleValue	Max300Dimmer = new DoubleValue();
			DoubleValue	Max300Strobe = new DoubleValue(); 	
			DoubleValue	Max300Control = new DoubleValue();
			Patch pMax300Pan = new Patch(Max300Pan); 					pMax300Pan.add(FixtureLibrary.MAX300PAN); 						universe.add(pMax300Pan);	
			Patch pMax300Tilt = new Patch(Max300Tilt); 					pMax300Tilt.add(FixtureLibrary.MAX300TILT); 					universe.add(pMax300Tilt);	
			Patch pMax300ColorWheel = new Patch(Max300ColorWheel); 		pMax300ColorWheel.add(FixtureLibrary.MAX300COLORWHEEL); 		universe.add(pMax300ColorWheel);	
			Patch pMax300Gobo = new Patch(Max300Gobo); 					pMax300Gobo.add(FixtureLibrary.MAX300GOBO); 					universe.add(pMax300Gobo);	
			Patch pMax300TurningGobo = new Patch(Max300TurningGobo); 	pMax300TurningGobo.add(FixtureLibrary.MAX300TURNINGSPEED); 		universe.add(pMax300TurningGobo);
			Patch pMax300TurningSpeed = new Patch(Max300TurningSpeed); 	pMax300TurningSpeed.add(FixtureLibrary.MAX300TURNINGSPEED); 	universe.add(pMax300TurningSpeed);	
			Patch pMax300Prism = new Patch(Max300Prism); 				pMax300Prism.add(FixtureLibrary.MAX300PRISM); 					universe.add(pMax300Prism);
			Patch pMax300Dimmer = new Patch(Max300Dimmer); 				pMax300Dimmer.add(FixtureLibrary.MAX300DIMMER); 				universe.add(pMax300Dimmer);
			Patch pMax300Strobe= new Patch(Max300Strobe); 				pMax300Strobe.add(FixtureLibrary.MAX300STROBE); 				universe.add(pMax300Strobe);
			Patch pMax300Control = new Patch(Max300Control); 			pMax300Control.add(FixtureLibrary.MAX300CONTROL); 				universe.add(pMax300Control);	
			Max300Strobe.value(MAX300ValuesLibrary.SHUTTEROPEN);
		
			FixturesGroup allFixtureGroup = new FixturesGroup();
			allFixtureGroup.addFixture(Max36_1Pan, Max36_1Tilt, Max36_1Red, Max36_1Blue, Max36_1Green, Max36_1Dimmer);
			allFixtureGroup.addFixture(Max36_2Pan, Max36_2Tilt, Max36_2Red, Max36_2Blue, Max36_2Green, Max36_2Dimmer);
//			allFixtureGroup.addFixture(Max500Pan, Max500Tilt, Max500ColorWheel, Max500ColorWheel, Max500ColorWheel, Max500Dimmer);
			allFixtureGroup.addFixture(Max300Pan, Max300Tilt, Max300ColorWheel, Max300ColorWheel, Max300ColorWheel, Max300Dimmer);
			allFixtureGroup.addFixture(AcrobatX, AcrobatZ, AcrobatRed, AcrobatBlue, AcrobatGreen, AcrobatDimmer);

			FixturesGroup max36Group = new FixturesGroup();
			max36Group.addFixture(Max36_1Pan, Max36_1Tilt, Max36_1Red, Max36_1Blue, Max36_1Green, Max36_1Dimmer);
			max36Group.addFixture(Max36_2Pan, Max36_2Tilt, Max36_2Red, Max36_2Blue, Max36_2Green, Max36_2Dimmer);

			FixturesGroup rgbGroup = new FixturesGroup();
			rgbGroup.addFixture(Max36_1Pan, Max36_1Tilt, Max36_1Red, Max36_1Blue, Max36_1Green, Max36_1Dimmer);
			rgbGroup.addFixture(Max36_2Pan, Max36_2Tilt, Max36_2Red, Max36_2Blue, Max36_2Green, Max36_2Dimmer);
			rgbGroup.addFixture(AcrobatX, AcrobatY, AcrobatRed, AcrobatBlue, AcrobatGreen, AcrobatDimmer);
			
			AdaptaterOneToSeveralBox rgbBlue = new AdaptaterOneToSeveralBox();
			rgbBlue.addDropBox(Max36_1Blue); rgbBlue.addDropBox(Max36_2Blue); rgbBlue.addDropBox(AcrobatBlue);
			
			AdaptaterOneToSeveralBox rgbRed = new AdaptaterOneToSeveralBox();
			rgbRed.addDropBox(Max36_1Red); rgbRed.addDropBox(Max36_2Red); rgbRed.addDropBox(AcrobatRed);
			
			AdaptaterOneToSeveralBox rgbGreen = new AdaptaterOneToSeveralBox();
			rgbGreen.addDropBox(Max36_1Green); rgbGreen.addDropBox(Max36_2Green); rgbGreen.addDropBox(AcrobatGreen);
			
			AdaptaterOneToSeveralBox rgbDimmer = new AdaptaterOneToSeveralBox();
			rgbDimmer.addDropBox(Max36_1Dimmer); rgbDimmer.addDropBox(Max36_2Dimmer); rgbDimmer.addDropBox(AcrobatDimmer);
			
			AdaptaterOneToSeveralBox rgbStrobe = new AdaptaterOneToSeveralBox();
			rgbStrobe.addDropBox(Max36_1Strobe); rgbStrobe.addDropBox(Max36_2Strobe); rgbStrobe.addDropBox(AcrobatStrobe);
			
			AdaptaterOneToSeveralBox lyreTilt = new AdaptaterOneToSeveralBox();
			lyreTilt.addDropBox(Max36_1Tilt); lyreTilt.addDropBox(Max36_2Tilt); lyreTilt.addDropBox(Max300Tilt);
			
			AdaptaterOneToSeveralBox rgbPan = new AdaptaterOneToSeveralBox();
			rgbPan.addDropBox(Max36_1Pan); rgbPan.addDropBox(Max36_2Pan); rgbPan.addDropBox(Max300Pan);
			
			Parallele cmdrgbLightOn = new Parallele();
			cmdrgbLightOn.addCommand(new SetValue(1, rgbDimmer));
			cmdrgbLightOn.addCommand(new SetValue(1, rgbBlue));
			cmdrgbLightOn.addCommand(new SetValue(1, rgbRed));
			cmdrgbLightOn.addCommand(new SetValue(1, rgbGreen));
			SetValue cmdrgbLightOff = new SetValue(0, rgbDimmer);
			Parallele cmdrgbLightSoft = new Parallele();
			cmdrgbLightSoft.addCommand(cmdrgbLightOn);
			cmdrgbLightSoft.addCommand(new SetValue(0.5, rgbDimmer));
			
			Parallele cmdrgbStrobeOn = new Parallele();
			cmdrgbStrobeOn.addCommand(new SetValue(20.0/255.0, Max36_1Strobe));
			cmdrgbStrobeOn.addCommand(new SetValue(20.0/255.0, Max36_2Strobe));
			cmdrgbStrobeOn.addCommand(new SetValue(250.0/255.0, AcrobatStrobe));
			
			SetValue cmdrgbStrobeOff = new SetValue(0, rgbStrobe);
						
			Parallele p1 = new Parallele();
			p1.addCommand(new Interpolation(1, 0, new CommandTime(1, TimeScaleEnum.SEC), rgbBlue));
			p1.addCommand(new Interpolation(0, 0.5, new CommandTime(1, TimeScaleEnum.SEC), rgbRed));
			p1.addCommand(new Interpolation(0.5, 1, new CommandTime(1, TimeScaleEnum.SEC), rgbGreen));
			Parallele p2 = new Parallele();
			p2.addCommand(new Interpolation(1, 0, new CommandTime(1, TimeScaleEnum.SEC), rgbGreen));
			p2.addCommand(new Interpolation(0, 0.5, new CommandTime(1, TimeScaleEnum.SEC), rgbBlue));
			p2.addCommand(new Interpolation(0.5, 1, new CommandTime(1, TimeScaleEnum.SEC), rgbRed));
			Parallele p3 = new Parallele();
			p3.addCommand(new Interpolation(1, 0, new CommandTime(1, TimeScaleEnum.SEC), rgbRed));
			p3.addCommand(new Interpolation(0, 0.5, new CommandTime(1, TimeScaleEnum.SEC), rgbGreen));
			p3.addCommand(new Interpolation(0.5, 1, new CommandTime(1, TimeScaleEnum.SEC), rgbBlue));
			Sequence cdmrgbColorRoll= new Sequence();
			cdmrgbColorRoll.addCommand(p1);
			cdmrgbColorRoll.addCommand(p2);
			cdmrgbColorRoll.addCommand(p3);
			
			Chaser cmdrgbChaser = new Chaser(new CommandTime(2, TimeScaleEnum.SEC), rgbGroup);
			
			SetValue   cmdrgbBlueOn =new SetValue(1, rgbBlue);
			
			SetValue cmdrgbBlueOff =new SetValue(0, rgbBlue);
			
			SetValue cmdrgbRedOn  = new SetValue(1, rgbRed);
			
			SetValue cmdrgbRedOff = new SetValue(0, rgbRed);
			
			SetValue cmdrgbGreenOn = new SetValue(1, rgbGreen);
			
			SetValue cmdrgbGreenOff = new SetValue(0, rgbGreen);
			
			Parallele cmdrgbRGB = new Parallele();
			cmdrgbRGB.addCommand(new SetValue(1, Max36_1Blue)); cmdrgbRGB.addCommand(new SetValue(0, Max36_1Red)); cmdrgbRGB.addCommand(new SetValue(0, Max36_1Green));
			cmdrgbRGB.addCommand(new SetValue(0, Max36_2Blue)); cmdrgbRGB.addCommand(new SetValue(0, Max36_2Red)); cmdrgbRGB.addCommand(new SetValue(1, Max36_2Green));
			cmdrgbRGB.addCommand(new SetValue(0, AcrobatBlue)); cmdrgbRGB.addCommand(new SetValue(1, AcrobatRed)); cmdrgbRGB.addCommand(new SetValue(0, AcrobatGreen));
			
			
			Parallele cmdmoveInitUp = new Parallele();
			cmdmoveInitUp.addCommand(new SetValue(0.5, Max36_1Tilt));  cmdmoveInitUp.addCommand(new SetValue(0.5, Max36_1Pan));
			cmdmoveInitUp.addCommand(new SetValue(0.5, Max36_2Tilt));  cmdmoveInitUp.addCommand(new SetValue(0.5, Max36_2Pan));
			cmdmoveInitUp.addCommand(new SetValue(0.5, AcrobatX)); 	 cmdmoveInitUp.addCommand(new SetValue(0.5, AcrobatY)); cmdmoveInitUp.addCommand(new SetValue(0.5, AcrobatZ));
			cmdmoveInitUp.addCommand(new SetValue(0.5, Max300Tilt));   cmdmoveInitUp.addCommand(new SetValue(0.5, Max300Pan));
//			cmdmoveInitUp.addCommand(new SetValue(0.5, Max500Tilt));   cmdmoveInitUp.addCommand(new SetValue(0.5, Max500Pan));
			
			Parallele cmdmoveInitBoard = new Parallele();
			cmdmoveInitBoard.addCommand(new SetValue(69.0/255.0, Max36_1Tilt));  cmdmoveInitBoard.addCommand(new SetValue(106.0/255.0, Max36_1Pan));
			cmdmoveInitBoard.addCommand(new SetValue(23.0/255.0, Max36_2Tilt));  cmdmoveInitBoard.addCommand(new SetValue(80.0/255.0, Max36_2Pan));
			cmdmoveInitBoard.addCommand(new SetValue(6.0/255.0, AcrobatX)); 	 cmdmoveInitBoard.addCommand(new SetValue(14.0/255.0, AcrobatY)); cmdmoveInitBoard.addCommand(new SetValue(38.0/255.0, AcrobatZ));
			cmdmoveInitBoard.addCommand(new SetValue(194.0/255.0, Max300Tilt));   cmdmoveInitBoard.addCommand(new SetValue(166.0/255.0, Max300Pan));
//			cmdmoveInitBoard.addCommand(new SetValue(0.5, Max500Tilt));   cmdmoveInitBoard.addCommand(new SetValue(0.5, Max500Pan));
			
			
			Fan cmdmoveFan = new Fan(new CommandTime(5, TimeScaleEnum.SEC), allFixtureGroup);
			
			Parallele cmdmoveSlowRandom = new Parallele();
			cmdmoveSlowRandom.addCommand(new TimableRandomShape(5, new CommandTime(8, TimeScaleEnum.SEC), Max36_1Tilt, Max36_1Pan));
			cmdmoveSlowRandom.addCommand(new TimableRandomShape(5, new CommandTime(8, TimeScaleEnum.SEC), Max36_2Tilt, Max36_2Pan));
			cmdmoveSlowRandom.addCommand(new TimableRandomShape(5, new CommandTime(8, TimeScaleEnum.SEC), AcrobatX, AcrobatY));
			cmdmoveSlowRandom.addCommand(new TimableRandomShape(5, new CommandTime(8, TimeScaleEnum.SEC), AcrobatZ, AcrobatZ));
			cmdmoveSlowRandom.addCommand(new TimableRandomShape(5, new CommandTime(8, TimeScaleEnum.SEC), Max300Tilt, Max300Pan));
//			slowRandom.addCommand(new TimableRandomShape(5, new CommandTime(8, TimeScaleEnum.SEC), Max500Tilt, Max500Pan));
			
			Parallele cmdmoveFastRandom = new Parallele();
			cmdmoveFastRandom.addCommand(new TimableRandomShape(10, new CommandTime(1, TimeScaleEnum.SEC), Max36_1Tilt, Max36_1Pan));
			cmdmoveFastRandom.addCommand(new TimableRandomShape(10, new CommandTime(1, TimeScaleEnum.SEC), Max36_2Tilt, Max36_2Pan));
			cmdmoveFastRandom.addCommand(new TimableRandomShape(10, new CommandTime(1, TimeScaleEnum.SEC), AcrobatX, AcrobatY));
			cmdmoveFastRandom.addCommand(new TimableRandomShape(10, new CommandTime(1, TimeScaleEnum.SEC), AcrobatZ, AcrobatZ));
			cmdmoveFastRandom.addCommand(new TimableRandomShape(10, new CommandTime(1, TimeScaleEnum.SEC), Max300Tilt, Max300Pan));
//			fastRandom.addCommand(new TimableRandomShape(10, new CommandTime(1, TimeScaleEnum.SEC), Max500Tilt, Max500Pan));
					

			Sequence cmdmoveSunDay = new Sequence();
			//rise
			cmdmoveSunDay.addCommand(cmdmoveInitUp);
			cmdmoveSunDay.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.SEC)));
			Parallele parallele = new Parallele();
			parallele.addCommand(new Interpolation(0, 0.5, new CommandTime(20, TimeScaleEnum.SEC), AcrobatZ));
			parallele.addCommand(new Interpolation(0, 0.5, new CommandTime(20, TimeScaleEnum.SEC), lyreTilt));
			parallele.addCommand(new Interpolation(0, 1, new CommandTime(20, TimeScaleEnum.SEC), rgbDimmer));
			parallele.addCommand(new SetValue(1, rgbRed));
			parallele.addCommand(new SetValue(0.5, rgbGreen));
			parallele.addCommand(new SetValue(0, rgbBlue));
			parallele.addCommand(new Interpolation(0, 1, new CommandTime(20, TimeScaleEnum.SEC), Max300Dimmer));
			parallele.addCommand(new SetValue(MAX300ValuesLibrary.COLORWHEELORANGE, Max300ColorWheel));
			cmdmoveSunDay.addCommand(parallele);
			//fall
			parallele = new Parallele();
			parallele.addCommand(new Interpolation(1, 0, new CommandTime(20, TimeScaleEnum.SEC), rgbDimmer));
			parallele.addCommand(new SetValue(1, rgbRed));
			parallele.addCommand(new SetValue(0.3, rgbGreen));
			parallele.addCommand(new SetValue(0, rgbBlue));
			parallele.addCommand(new Interpolation(0.5, 1, new CommandTime(20, TimeScaleEnum.SEC), AcrobatZ));
			parallele.addCommand(new Interpolation(0.5, 1, new CommandTime(20, TimeScaleEnum.SEC), lyreTilt));
			parallele.addCommand(new SetValue(MAX300ValuesLibrary.COLORWHEELRED, Max300ColorWheel));
			cmdmoveSunDay.addCommand(parallele);

			Parallele cmdmoveAcrobatAutoOn = new Parallele();
			cmdmoveAcrobatAutoOn.addCommand(new SetValue(1, AcrobatMacroXYZ));
			cmdmoveAcrobatAutoOn.addCommand(new SetValue(1, AcrobatAuto));
			Parallele cmdmoveAcrobatAutoOff = new Parallele();
			cmdmoveAcrobatAutoOff.addCommand(new SetValue(0, AcrobatMacroXYZ));
			cmdmoveAcrobatAutoOff.addCommand(new SetValue(0, AcrobatAuto));		
			
			SetValue cmdmax300LightOn = new SetValue(1, Max300Dimmer);
			SetValue cmdmax300LightOff = new SetValue(0, Max300Dimmer);
			
			SetValue cmdmax300ColorWheelWhite = new SetValue(0, Max300ColorWheel);
			SetValue cmdmax300ColorWheelBlue = new SetValue(MAX300ValuesLibrary.COLORWHEELBLUE, Max300ColorWheel);
			SetValue cmdmax300ColorWheelMagenta = new SetValue(MAX300ValuesLibrary.COLORWHEELMAGENTA, Max300ColorWheel);
			SetValue cmdmax300ColorWheelGreen = new SetValue(MAX300ValuesLibrary.COLORWHEELGREEN, Max300ColorWheel);
			SetValue cmdmax300ColorTurning = new SetValue(MAX300ValuesLibrary.COLORWHEELTURNING, Max300ColorWheel);

			SetValue cmdmax300Gobo0 = new SetValue(MAX300ValuesLibrary.GOBO_OPEN, Max300Gobo);
			SetValue cmdmax300Gobo1 = new SetValue(MAX300ValuesLibrary.GOBO_1, Max300Gobo);
			SetValue cmdmax300Gobo2 = new SetValue(MAX300ValuesLibrary.GOBO_3, Max300Gobo);
			SetValue cmdmax300Gobo3 = new SetValue(MAX300ValuesLibrary.GOBO_5, Max300Gobo);
			SetValue cmdmax300Gobo4 = new SetValue(MAX300ValuesLibrary.SHAKEGOBO_1, Max300Gobo);
			SetValue cmdmax300GoboTurningSlow = new SetValue(MAX300ValuesLibrary.GOBOTURNINGWHEELSLOW, Max300Gobo);
			SetValue cmdmax300GoboTurningFast = new SetValue(MAX300ValuesLibrary.GOBOTURNINGWHEELFAST, Max300Gobo);

			SetValue cmdmax300PrismOn = new SetValue(1, Max300Prism);
			SetValue cmdmax300PrismOff = new SetValue(0.03, Max300Prism);
			
			
			String[] namesRGB = {"light on", "light off", "light soft", "strobe on", "strobe off", "chaser", "color roll", "RGB", "blue on", "blue off", "red on", "red off", "green on", "green off"};		//"rectangle", "initPosition", "lightRoll", "red on", "blue on", "random", "strobo", "fan move", "change gobo", "Max500 pan move", "Max500 tilt move", "Acrobat auto on", "Acrobat auto off", };
			Command[] commandsRGB = {cmdrgbLightOn, cmdrgbLightOff, cmdrgbLightSoft, cmdrgbStrobeOn, cmdrgbStrobeOff, cmdrgbChaser, cdmrgbColorRoll, cmdrgbRGB, cmdrgbBlueOn, cmdrgbBlueOff, cmdrgbRedOn, cmdrgbRedOff, cmdrgbGreenOn, cmdrgbGreenOff};		//rectangle, setV, lightRoll, cmdRed, cmdBlue, randomCmd, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP, Command.STOP};
			
			String[] namesMove = {"init up", "init on board", "fan move",  "slow random", "fast random", "sunday", "acrobat auto", "acrobat manu"};
			Command[] commandsMove = {cmdmoveInitUp, cmdmoveInitBoard, cmdmoveFan,  cmdmoveSlowRandom, cmdmoveFastRandom, cmdmoveSunDay, cmdmoveAcrobatAutoOn, cmdmoveAcrobatAutoOff};
			
			String[] namesMax300 = {"light on", "light off", "white", "magenta", "blue", "green", "turning color", "gobo 1", "gobo 2", "gobo 3", "gobo 4", "turning gobo 1", "turning gobo 2", "gobo off", "prism on", "prism off"};
			Command[] commandsMax300 = {cmdmax300LightOn, cmdmax300LightOff, cmdmax300ColorWheelWhite, cmdmax300ColorWheelMagenta, cmdmax300ColorWheelBlue, cmdmax300ColorWheelGreen, cmdmax300ColorTurning, cmdmax300Gobo1, cmdmax300Gobo2, cmdmax300Gobo3, cmdmax300Gobo4, cmdmax300GoboTurningSlow, cmdmax300GoboTurningFast, cmdmax300Gobo0, cmdmax300PrismOn, cmdmax300PrismOff};
			
			CommandBox commandBox = new CommandBox();
		
			SequencerControllerV2 sequencerController = new  SequencerControllerV2(commandBox, namesRGB, commandsRGB, namesMove, commandsMove, namesMax300, commandsMax300);
			
			SequencerParametrable sequencer = new SequencerParametrable(commandBox);	

			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	
			SimpleContainer instrument  = new SimpleContainer(new Agent[] {sequencer, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);
			
			
			
			application.start();      
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
	
}

	

