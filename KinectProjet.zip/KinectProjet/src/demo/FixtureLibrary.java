package demo;

public class FixtureLibrary {

//  Labo config
    public static final int MAX36_1MODE    = 33;
    public static final int MAX36_1RED     = 34;
    public static final int MAX36_1GREEN   = 35;
    public static final int MAX36_1BLUE    = 36;
    public static final int MAX36_1STROBE  = 37;
    public static final int MAX36_1DIMMER  = 38;
    public static final int MAX36_1PAN     = 39;
    public static final int MAX36_1TILT    = 40;
    
    public static final int MAX36_2MODE    = 49;
    public static final int MAX36_2RED     = 50;
    public static final int MAX36_2GREEN   = 51;
    public static final int MAX36_2BLUE    = 52;
    public static final int MAX36_2STROBE  = 53;
    public static final int MAX36_2DIMMER  = 54;
    public static final int MAX36_2PAN     = 55;
    public static final int MAX36_2TILT    = 56;
    
    public static final int MAX500PAN    		= 113;
    public static final int MAX500PANFINE 		= 114;
    public static final int MAX500TILT     		= 115;
    public static final int MAX500TILTFINE  	= 116;
    public static final int MAX500SPEED 		= 117;
    public static final int MAX500COLORWHEEL   	= 118; //pas le bon canal
    public static final int MAX500TURNINGGOBO  	= 120;
    public static final int MAX500TURNINGSPEED 	= 121;
    public static final int MAX500PRISM     	= 122;
    public static final int MAX500FOCUS    		= 123;
    public static final int MAX500DIMMER     	= 124;
    public static final int MAX500SHUTTER    	= 125;
    public static final int MAX500CONTROL     	= 126;
    
    public static final int ACROBATPAN    		= 17;
    public static final int ACROBATTILT1   		= 18;
    public static final int ACROBATTILT2   		= 19;
    public static final int ACROBATSPEED  		= 20;
    public static final int ACROBATRED 			= 21;
    public static final int ACROBATGREEN 		= 22;
    public static final int ACROBATBLUE    		= 23;
    public static final int ACROBATDIMMER  		= 24;
    public static final int ACROBATSTROBE  		= 25;
    public static final int ACROBATAUTO    		= 26;
    public static final int ACROBATMACROXYZ 	= 27;
    
    public static final int MAX300PAN     		= 97;
    public static final int MAX300TILT   		= 98;
    public static final int MAX300COLORWHEEL   	= 99;
    public static final int MAX300GOBO  		= 100;
    public static final int MAX300TURNINGSPEED 	= 101;
    public static final int MAX300PRISM 		= 102;
    public static final int MAX300DIMMER    	= 103;
    public static final int MAX300STROBE  		= 104;
    public static final int MAX300CONTROL  		= 105;
    
    public static final int SXX50PAN 		= 1;
    public static final int SXX50TILT 		= 2;
    public static final int SXX50COLOR 		= 3;
    public static final int SXX50SHUTTER 	= 4;
    public static final int SXX50DIMMER 	= 5;
    public static final int SXX50GOBO 		= 6;
    public static final int SXX50ROTATION 	= 7;
    public static final int SXX50PRISM 		= 8;
    public static final int SXX50FOCUS 		= 9;
    public static final int SXX50CONTROL 	= 10;
    public static final int SXX50PROGRAM 	= 11;

    public static final int MAGICALSPOT1MODE 	= 45;
    public static final int MAGICALSPOT1RED 	= 46;
    public static final int MAGICALSPOT1GREEN 	= 47;
    public static final int MAGICALSPOT1BLUE 	= 48;
    
    public static final int MAGICALSPOT2MODE 	= 65;
    public static final int MAGICALSPOT2RED 	= 66;
    public static final int MAGICALSPOT2GREEN 	= 67;
    public static final int MAGICALSPOT2BLUE	= 68;
    
    public static final int MAGICALSPOT3MODE 	= 69;
    public static final int MAGICALSPOT3RED 	= 70;
    public static final int MAGICALSPOT3GREEN 	= 71;
    public static final int MAGICALSPOT3BLUE 	= 72;
    
    public static final int MAGICALSPOT4MODE 	= 73;
    public static final int MAGICALSPOT4RED 	= 74;
    public static final int MAGICALSPOT4GREEN 	= 75;
    public static final int MAGICALSPOT4BLUE	= 76;
    
    public static final int MAGICALSPOT5MODE 	= 77;
    public static final int MAGICALSPOT5RED 	= 78;
    public static final int MAGICALSPOT5GREEN 	= 79;
    public static final int MAGICALSPOT5BLUE	= 80;
    
    public static final int MAGICALSPOT6MODE 	= 61;
    public static final int MAGICALSPOT6RED 	= 62;
    public static final int MAGICALSPOT6GREEN 	= 63;
    public static final int MAGICALSPOT6BLUE	= 64;
    
    public static final int QUADRABEAMCHASE 	= 81;
    public static final int QUADRABEAMSTROBE 	= 82;
    public static final int QUADRABEAMRED 		= 83;
    public static final int QUADRABEAMGREEN		= 84;
    public static final int QUADRABEAMBLUE		= 85;
    public static final int QUADRABEAMDIMMER	= 86;

}
 
 
