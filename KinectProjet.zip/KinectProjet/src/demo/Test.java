package demo;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Set;

import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import auto.command.CommandTime;
import auto.command.TimeScaleEnum;
import autoIterator.AdaptaterOneToSeveralBox;
import autoIterator.CommandBox;
import autoIterator.FixturesGroup;
import autoIterator.SequencerController;
import autoIterator.SequencerControllerV2;
import autoIterator.SequencerParametrable;
import autoIterator.command.Command;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import autoIterator.command.SetValue;
import autoIterator.command.Wait;
import level.DMXLevel;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;
import sun.awt.AWTAccessor.SequencedEventAccessor;
import universe.DMXUniverse;
import universe.Patch;


public class Test {

	private static final String ADDRESS = "10.59.1.2"; //10.59.1.4  new address?
	private static final int ARTNET_PORT = 6454; // 8000  new port???
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	
	public static void test() {

		try 
		{

			InetAddress address = InetAddress.getByName(ADDRESS); //mix IP et du port
			ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);
			DmxPacket packet = new DmxPacket(); //Cr�ation de Liste de channel

			DMXUniverse universe = new DMXUniverse(); //Cr�ation d'une liste de patch
			
			DoubleValue Max36_1Blue = new DoubleValue(); 			Patch pMax36_1Blue = new Patch(Max36_1Blue); 			pMax36_1Blue.add(FixtureLibrary.MAX36_1BLUE); 		universe.add(pMax36_1Blue);	
			DoubleValue Max36_1Green = new DoubleValue(); 			Patch pMax36_1Green = new Patch(Max36_1Green);			pMax36_1Green.add(FixtureLibrary.MAX36_1GREEN); 	universe.add(pMax36_1Green);	
			DoubleValue Max36_1Red = new DoubleValue(); 			Patch pMax36_1Red = new Patch(Max36_1Red);				pMax36_1Red.add(FixtureLibrary.MAX36_1RED); 		universe.add(pMax36_1Red);	
			DoubleValue Max36_1Tilt = new DoubleValue(); 			Patch pMax36_1Tilt = new Patch(Max36_1Tilt);			pMax36_1Tilt.add(FixtureLibrary.MAX36_1TILT); 		universe.add(pMax36_1Tilt);	
			DoubleValue Max36_1Dimmer = new DoubleValue(); 			Patch pMax36_1Dimmer = new Patch(Max36_1Dimmer);		pMax36_1Dimmer.add(FixtureLibrary.MAX36_1DIMMER); 	universe.add(pMax36_1Dimmer);	
			DoubleValue Max36_1Pan = new DoubleValue(); 			Patch pMax36_1Pan = new Patch(Max36_1Pan);				pMax36_1Pan.add(FixtureLibrary.MAX36_1PAN); 		universe.add(pMax36_1Pan);		
		
			DoubleValue Max36_2Blue = new DoubleValue(); 			Patch pMax36_2Blue = new Patch(Max36_2Blue); 			pMax36_2Blue.add(FixtureLibrary.MAX36_2BLUE); 		universe.add(pMax36_2Blue);	
			DoubleValue Max36_2Green = new DoubleValue(); 			Patch pMax36_2Green = new Patch(Max36_2Green);			pMax36_2Green.add(FixtureLibrary.MAX36_2GREEN); 	universe.add(pMax36_2Green);	
			DoubleValue Max36_2Red = new DoubleValue(); 			Patch pMax36_2Red = new Patch(Max36_2Red);				pMax36_2Red.add(FixtureLibrary.MAX36_2RED); 		universe.add(pMax36_2Red);	
			DoubleValue Max36_2Tilt = new DoubleValue(); 			Patch pMax36_2Tilt = new Patch(Max36_2Tilt);			pMax36_2Tilt.add(FixtureLibrary.MAX36_2TILT); 		universe.add(pMax36_2Tilt);	
			DoubleValue Max36_2Dimmer = new DoubleValue(); 			Patch pMax36_2Dimmer = new Patch(Max36_2Dimmer);		pMax36_2Dimmer.add(FixtureLibrary.MAX36_2DIMMER); 	universe.add(pMax36_2Dimmer);	
			DoubleValue Max36_2Pan = new DoubleValue(); 			Patch pMax36_2Pan = new Patch(Max36_2Pan);				pMax36_2Pan.add(FixtureLibrary.MAX36_2PAN); 		universe.add(pMax36_2Pan);		

			
			FixturesGroup allSpot = new FixturesGroup();

			allSpot.addFixture(Max36_1Pan, Max36_1Tilt, Max36_1Red, Max36_1Blue, Max36_1Green, Max36_1Dimmer);
			allSpot.addFixture(Max36_2Pan, Max36_2Tilt, Max36_2Red, Max36_2Blue, Max36_2Green, Max36_2Dimmer);
			
			AdaptaterOneToSeveralBox rgbBlanc = new AdaptaterOneToSeveralBox();
			rgbBlanc.addDropBox(Max36_1Blue);rgbBlanc.addDropBox(Max36_1Green);rgbBlanc.addDropBox(Max36_1Red);	rgbBlanc.addDropBox(Max36_2Blue);rgbBlanc.addDropBox(Max36_2Green);rgbBlanc.addDropBox(Max36_2Red);
			
			AdaptaterOneToSeveralBox rgbRouge = new AdaptaterOneToSeveralBox();
			rgbRouge.addDropBox(Max36_1Red);rgbRouge.addDropBox(Max36_2Red);
			
			AdaptaterOneToSeveralBox rgbVert = new AdaptaterOneToSeveralBox();
			rgbRouge.addDropBox(Max36_1Green);rgbRouge.addDropBox(Max36_2Green);
			
			AdaptaterOneToSeveralBox rgbBleu = new AdaptaterOneToSeveralBox();
			rgbRouge.addDropBox(Max36_1Blue);rgbRouge.addDropBox(Max36_2Blue);
			
			Parallele cmdrgbLight = new Parallele();
			cmdrgbLight.addCommand(new SetValue(0.1, rgbBlanc));
			cmdrgbLight.addCommand(new SetValue(0.37, Max36_1Pan));
			cmdrgbLight.addCommand(new SetValue(0.3, Max36_1Tilt));
			cmdrgbLight.addCommand(new SetValue(0.37, Max36_2Pan));
			cmdrgbLight.addCommand(new SetValue(0.3, Max36_2Tilt));
			
			Parallele cmdrgbMove = new Parallele();
			cmdrgbMove.addCommand(new SetValue(0.1, rgbBlanc));
			cmdrgbMove.addCommand(new SetValue(0.27, Max36_1Pan));
			cmdrgbMove.addCommand(new SetValue(0.3, Max36_1Tilt));
			cmdrgbMove.addCommand(new SetValue(0.1, Max36_2Pan));
			cmdrgbMove.addCommand(new SetValue(0.4, Max36_2Tilt));
		
			Parallele cmdrgbNull = new Parallele();
			cmdrgbNull.addCommand(new SetValue(0, rgbBlanc));
			
			Sequence seqDay = new Sequence();
			seqDay.addCommand(cmdrgbLight);
			seqDay.addCommand(new Wait(new CommandTime(2, TimeScaleEnum.SEC)));
			seqDay.addCommand(cmdrgbMove);
			
			String[] namesRGB = {"light on","move","light off","day"};
			Command[] commandsRGB = {cmdrgbLight, cmdrgbMove, cmdrgbNull,seqDay};

			CommandBox commandBox = new CommandBox();
		
			SequencerController seq = new SequencerController(commandBox, namesRGB, commandsRGB);
			
			SequencerParametrable sequencer = new SequencerParametrable(commandBox);	

			DMXLevel 		L1 = new DMXLevel(universe , "level");
			DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);

			SimpleContainer instrument  = new SimpleContainer(new Agent[] {sequencer, L1, T1});
			Application     application = new Application(instrument, 0.025, 0.005);

			application.start();
		}
		catch (Exception e) { e.printStackTrace();	}	 
	}
}
