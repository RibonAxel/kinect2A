package joints;

public class Corps {
	
	private Hand handRight;
	private Hand handLeft; 
	
	private Noeud head;
	
	public Corps(Hand right,Hand left){
		this.handRight=right;
		this.handLeft=left;
	}
	
	public Hand getHandRight() {
		return handRight;
	}

	
	public Hand getHandLeft() {
		return handLeft;
	}


	public Noeud getHead() {
		return head;
	}


	public void setHandRight(Hand handRight) {
		this.handRight = handRight;
	}


	public void setHandLeft(Hand handLeft) {
		this.handLeft = handLeft;
	}


	public void setHead(Noeud head) {
		this.head = head;
	}

}
