package joints;

public class Hand extends Noeud{

	private boolean open;
	private int orientation;
	// 0 : right 1 left

	public Hand(boolean b, int i) {
		this.open = b;
		this.orientation = i;
	}

	public boolean getOpen() {
		return open;
	}
	
	public void setOpen(boolean open){
		this.open=open;
	}

	public int getOrientation() {
		return orientation;
	}

	public void setOrientation(int orientation) {
		this.orientation = orientation;
	}
	
}
