//  Created by BB on 11 05 11.

package universe;

import java.util.ArrayList;

public class DMXUniverse {

	private ArrayList<Patch> patchs = new ArrayList<Patch>();
	
	public DMXUniverse()
	{}
	
	public void add(Patch patch)
	{
		this.patchs.add(patch);
	}
	
	public ArrayList<Patch> getPatchs()
	{
		return this.patchs;
	}
	
	public String toString()
	{
		return this.patchs.toString();
	}
}
