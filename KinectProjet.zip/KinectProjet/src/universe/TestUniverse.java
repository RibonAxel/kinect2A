//remplace tstDMXTransfertMult et TstDMXLevel suite au changement de gestion apport� par l'univer
//  Created by BB on 11 05 11.

package universe;

import generators.DMXSignalGenerator;
import generators.SignalGenerator;
import generators.signal.Constant;
import generators.signal.DMXSineWave;
import generators.signal.Sinewave;

import java.net.InetAddress;

import level.DMXLevel;

import DMXTransfer.DMXTransferMultiple;
import artnet.as.DmxPacket;
import artnet.stream.ArtnetSink;
import pi.application.Application;
import pi.container.SimpleContainer;
import pi.endpoint.DMXValue;
import pi.endpoint.DoubleValue;
import pi.executive.Agent;
import stream.UDPSink;

public class TestUniverse {

	private static final String ADDRESS = "255.255.255.255";

	//private static final String ADDRESS  = "10.59.14.101";
	private static final int ARTNET_PORT = 6454;
	private static final int SUBNET      = 0;
	private static final int UNIVERSE    = 0;
	private static final int FIXTUREBLUE    = 4;
	private static final int FIXTURERED     = 2;
	private static final int FIXTUREGREEN   = 3;
	private static final int FIXTURETILT    = 8;
	private static final int FIXTUREDIMMER  = 6;
	private static final int[] MULTFIXTUREBLUE = {FIXTUREBLUE, FIXTUREBLUE+11, FIXTUREBLUE+22, FIXTUREBLUE+33};
	private static final int[] MULTFIXTURERED = {FIXTURERED, FIXTURERED+11, FIXTURERED+22, FIXTURERED+33};
	private static final int[] MULTFIXTURETILT = {FIXTURETILT, FIXTURETILT+11, FIXTURETILT+22, FIXTURETILT+33};
	private static final int[] MULTFIXTUREDIMMER = {FIXTUREDIMMER, FIXTUREDIMMER+11, FIXTUREDIMMER+22, FIXTUREDIMMER+33};
	
	public static void test() {
		
		 try 
		 {
			 
	         InetAddress address = InetAddress.getByName(ADDRESS);
	         ArtnetSink sink  = new ArtnetSink (new UDPSink(address, ARTNET_PORT), SUBNET, UNIVERSE);         
	         DmxPacket packet = new DmxPacket();
	         
	         
	         DoubleValue      S1 = new DoubleValue();     
	         SignalGenerator  G1 = new SignalGenerator(new Sinewave(120, 0.02), S1); 
	   
	         DMXValue      S2 = new DMXValue();
	         DMXSignalGenerator  G2 = new DMXSignalGenerator(new DMXSineWave(120, 0.1), S2); 
	         
	         DoubleValue      S3 = new DoubleValue();
	         SignalGenerator  G3 = new SignalGenerator( new Constant(1), S3); 
	         
	         DMXValue      S4 = new DMXValue();
	         DMXSignalGenerator  G4 = new DMXSignalGenerator(new DMXSineWave(254, 0.1), S4); 
	         
	         
	         DMXUniverse universe = new DMXUniverse();
	         Patch p1 = new Patch(S1);  p1.add(MULTFIXTUREBLUE); 
	         Patch p2 = new Patch(S2);  p2.add(MULTFIXTURERED);
	         Patch p3 = new Patch(S3);  p3.add(MULTFIXTUREDIMMER);
	         Patch p4 = new Patch(S4);  p4.add(MULTFIXTURETILT);
	         
	         universe.add(p1); universe.add(p2); universe.add(p3); universe.add(p4);
	        	        	         
	        
	         DMXLevel 		L1 = new DMXLevel(universe , "level");
	         DMXTransferMultiple T1 = new DMXTransferMultiple(sink, packet, universe);
	         
	         SimpleContainer instrument  = new SimpleContainer(new Agent[] {G1, G2, G3 ,G4, T1, L1});
	         Application     application = new Application(instrument, 0.025, 0.005);
	      
		   
		   
	         application.start();      
		 }
		 catch (Exception e) { e.printStackTrace();	}
	}
}