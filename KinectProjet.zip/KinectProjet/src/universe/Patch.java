//created by BB 11/05/11

package universe;

import java.util.ArrayList;

import pi.endpoint.AdaptaterDoubleSourceToDMXSource;
import pi.endpoint.DMXSource;
import pi.endpoint.DoubleSource;


public class Patch {
	
	private DMXSource source; //valeur int
	private ArrayList<Integer> channels = new ArrayList<Integer>();

	public Patch(DMXSource source)
	{
		this.source = source;
	}
	public Patch(DoubleSource source)
	{
		this.source =  new AdaptaterDoubleSourceToDMXSource(source);
	}
	
	public void add(int channel)
	{
		this.channels.add((Integer) channel);
	}
	public void add(int channels[])
	{
		for(int i=0; i<channels.length; i++)
			this.add(channels[i]);
	}
	public void remove(int channel)
	{
		this.channels.remove((Integer) channel);
	}
	public void remove( int channels[])
	{
		for(int i=0;i<channels.length; i++)
			this.remove(channels[i]);
	}
	
	public ArrayList<Integer> getChannels()
	{
		return this.channels;
	}
	public DMXSource getSource()
	{
		return this.source;
	}
	public void setSource(DMXSource source)
	{
		this.source = source;
	}
	public void setSource(DoubleSource source)
	{
		this.source = new AdaptaterDoubleSourceToDMXSource(source);
	}
	
	
	public String toString()
	{
		return this.source.toString() +"   " + this.channels.toString();
	}
	
	
	
}