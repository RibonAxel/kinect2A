package kinectprojet;

import java.net.InetAddress;

import dmx.memory.osc.DMXMemoryProxy;
import dmx.osc.DMXProxy;
import osc.stream.OSCSink;
import stream.UDPSink;

public class FactoryOSC {

	private static final String HOSTNAME = "10.59.1.4"; //10.59.1.4  new address?
	private static final int OSC_PORT = 8000; // 8000  new port???
	//private static final int SUBNET      = 0;
	//private static final int UNIVERSE    = 0;

	private static final String DMX        = "/dmx";

	public static DMXProxy createProxy(){
	     return(new DMXProxy(DMX, createOSCSink(HOSTNAME, OSC_PORT)));
	}
	
	public static DMXMemoryProxy createMemoryProxy(){
	     return(new DMXMemoryProxy(DMX, createOSCSink(HOSTNAME, OSC_PORT)));
	}

	private static OSCSink createOSCSink(String HOSTNAME, int OSC_PORT) {
		try {
			InetAddress address = InetAddress.getByName(HOSTNAME);
			OSCSink osc = new OSCSink(new UDPSink(address, OSC_PORT));
			return osc;
		} catch (Exception e) { System.out.println (e); }
		return null;
	}
}
