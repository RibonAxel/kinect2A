package kinectprojet;

import processing.core.PApplet;

import java.util.ArrayList;

import KinectPV2.KJoint;
import KinectPV2.KSkeleton;
import KinectPV2.KinectPV2;
import autoIterator.command.Parallele;
import autoIterator.command.Sequence;
import controller.ControllerGestureHand;
import controller.ControllerInterface;
import controller.ControllerMoveHand;
import controller.ControllerPaintHand;
import controller.ControllerSliderHand;
import demo.FixtureLibrary;
import dmx.memory.osc.DMXMemoryProxy;
import dmx.osc.DMXProxy;
import joints.Corps;
import joints.Hand;


public class KinectProjet extends PApplet {

	KinectPV2 kinect;
	
	public static DMXProxy dmxProxy;
	DMXMemoryProxy dmxMemoryProxy;

	public static KJoint[] joints;
	
	ArrayList<ControllerInterface> listController = new ArrayList<ControllerInterface>();

	private Corps body = new Corps(new Hand(true,0),new Hand(true,1));

	private int testOne;

	public static float xDepart;

	public void settings() {
		size(1920, 1080, "processing.opengl.PGraphics3D");
	}

	public void setup() {
		kinect = new KinectPV2(this);

		dmxProxy = FactoryOSC.createProxy();
		//dmxMemoryProxy = FactoryOSC.createMemoryProxy();
		
		ArrayList<Integer> listThree = new ArrayList<Integer>();
		listThree.add(FixtureLibrary.MAGICALSPOT1RED);
		listThree.add(FixtureLibrary.MAGICALSPOT1BLUE);
		listThree.add(FixtureLibrary.MAGICALSPOT1MODE);
		listThree.add(FixtureLibrary.MAGICALSPOT2RED);
		listThree.add(FixtureLibrary.MAGICALSPOT2BLUE);
		listThree.add(FixtureLibrary.MAGICALSPOT2MODE);
		listThree.add(FixtureLibrary.MAGICALSPOT3RED);
		listThree.add(FixtureLibrary.MAGICALSPOT3BLUE);
		listThree.add(FixtureLibrary.MAGICALSPOT3MODE);
		listThree.add(FixtureLibrary.MAGICALSPOT4RED);
		listThree.add(FixtureLibrary.MAGICALSPOT4BLUE);
		listThree.add(FixtureLibrary.MAGICALSPOT4MODE);
		listThree.add(FixtureLibrary.MAGICALSPOT5RED);
		listThree.add(FixtureLibrary.MAGICALSPOT5BLUE);
		listThree.add(FixtureLibrary.MAGICALSPOT5MODE);
		listThree.add(FixtureLibrary.MAGICALSPOT6RED);
		listThree.add(FixtureLibrary.MAGICALSPOT6BLUE);
		listThree.add(FixtureLibrary.MAGICALSPOT6MODE);
		listController.add(new ControllerSliderHand(dmxProxy,listThree,body.getHandRight(),body.getHandLeft()));
		
		/*
		ArrayList<Integer> listFour = new ArrayList<Integer>();
		listFour.add(FixtureLibrary.MAX36_1GREEN);
		listController.add(new ControllerPaintHand(dmxProxy,listFour, body.getHandRight(), body.getHandLeft()));
		
		ArrayList<Integer> listTwo = new ArrayList<Integer>();
		listTwo.add(35);
		listController.add(new ControllerGestureHand(dmxProxy,listTwo,body.getHandRight(),body.getHandLeft()));
		*/
		ArrayList<Integer> listOne = new ArrayList<Integer>();
		listOne.add(FixtureLibrary.MAGICALSPOT1RED);
		listOne.add(FixtureLibrary.MAGICALSPOT1BLUE);
		listOne.add(FixtureLibrary.MAGICALSPOT1MODE);
		listOne.add(FixtureLibrary.MAGICALSPOT2RED);
		listOne.add(FixtureLibrary.MAGICALSPOT2BLUE);
		listOne.add(FixtureLibrary.MAGICALSPOT2MODE);
		listOne.add(FixtureLibrary.MAGICALSPOT3RED);
		listOne.add(FixtureLibrary.MAGICALSPOT3BLUE);
		listOne.add(FixtureLibrary.MAGICALSPOT3MODE);
		listOne.add(FixtureLibrary.MAGICALSPOT4RED);
		listOne.add(FixtureLibrary.MAGICALSPOT4BLUE);
		listOne.add(FixtureLibrary.MAGICALSPOT4MODE);
		listOne.add(FixtureLibrary.MAGICALSPOT5RED);
		listOne.add(FixtureLibrary.MAGICALSPOT5BLUE);
		listOne.add(FixtureLibrary.MAGICALSPOT5MODE);
		listOne.add(FixtureLibrary.MAGICALSPOT6RED);
		listOne.add(FixtureLibrary.MAGICALSPOT6BLUE);
		listOne.add(FixtureLibrary.MAGICALSPOT6MODE);
		listController.add(new ControllerMoveHand(dmxProxy,listOne,body.getHandRight(),body.getHandLeft()));
		
		kinect.enableSkeletonColorMap(true);
		kinect.enableColorImg(true);
		kinect.enableBodyTrackImg(true);

		kinect.init();
	}

	public void draw() {
		background(0);

		image(kinect.getPointCloudDepthImage(), 0, 0, width, height); 

		ArrayList<KSkeleton> skeletonArray =  kinect.getSkeletonColorMap();

		//individual JOINTS
		for (int i = 0; i < skeletonArray.size(); i++) {
			KSkeleton skeleton1 = (KSkeleton) skeletonArray.get(i);

			if (skeleton1.isTracked()) {
				joints = skeleton1.getJoints();
				
				if (testOne == 0){
					xDepart = joints[KinectPV2.JointType_HandLeft].getX();
					testOne +=1;
				}

				int col  = skeleton1.getIndexColor();
				fill(col);
				stroke(col);
				drawBody(joints);
				//draw different color for each hand state
				drawHandState(joints[KinectPV2.JointType_HandRight]);
				drawHandState(joints[KinectPV2.JointType_HandLeft]);
				
				updateBody(this.body,joints);

				for (ControllerInterface controller : listController) {
					controller.update();
				}
			}
		}
		fill(255, 0, 0);
		text(frameRate, 50, 50);
	}

	private void updateBody(Corps body, KJoint[] joints) {
		updateHand(body.getHandRight(), joints[KinectPV2.JointType_HandRight]);
		updateHand(body.getHandLeft(), joints[KinectPV2.JointType_HandLeft]);

	}

	private void updateHand(Hand hand, KJoint kJoint ){
		
		hand.setX(kJoint.getX());
		hand.setY(kJoint.getY());
		hand.setZ(kJoint.getZ());

		
		if (hand.getOrientation() == 0)
			hand.setOpen(!(joints[KinectPV2.JointType_HandRight].getState() == KinectPV2.HandState_Closed));
		else
			hand.setOpen(!(joints[KinectPV2.JointType_HandLeft].getState() == KinectPV2.HandState_Closed));
	}

	//DRAW BODY
	void drawBody(KJoint[] joints) {
		drawBone(joints, KinectPV2.JointType_Head, KinectPV2.JointType_Neck);
		drawBone(joints, KinectPV2.JointType_Neck, KinectPV2.JointType_SpineShoulder);
		drawBone(joints, KinectPV2.JointType_SpineShoulder, KinectPV2.JointType_SpineMid);
		drawBone(joints, KinectPV2.JointType_SpineMid, KinectPV2.JointType_SpineBase);
		drawBone(joints, KinectPV2.JointType_SpineShoulder, KinectPV2.JointType_ShoulderRight);
		drawBone(joints, KinectPV2.JointType_SpineShoulder, KinectPV2.JointType_ShoulderLeft);
		drawBone(joints, KinectPV2.JointType_SpineBase, KinectPV2.JointType_HipRight);
		drawBone(joints, KinectPV2.JointType_SpineBase, KinectPV2.JointType_HipLeft);

		// Right Arm
		drawBone(joints, KinectPV2.JointType_ShoulderRight, KinectPV2.JointType_ElbowRight);
		drawBone(joints, KinectPV2.JointType_ElbowRight, KinectPV2.JointType_WristRight);
		drawBone(joints, KinectPV2.JointType_WristRight, KinectPV2.JointType_HandRight);
		drawBone(joints, KinectPV2.JointType_HandRight, KinectPV2.JointType_HandTipRight);
		drawBone(joints, KinectPV2.JointType_WristRight, KinectPV2.JointType_ThumbRight);

		// Left Arm
		drawBone(joints, KinectPV2.JointType_ShoulderLeft, KinectPV2.JointType_ElbowLeft);
		drawBone(joints, KinectPV2.JointType_ElbowLeft, KinectPV2.JointType_WristLeft);
		drawBone(joints, KinectPV2.JointType_WristLeft, KinectPV2.JointType_HandLeft);
		drawBone(joints, KinectPV2.JointType_HandLeft, KinectPV2.JointType_HandTipLeft);
		drawBone(joints, KinectPV2.JointType_WristLeft, KinectPV2.JointType_ThumbLeft);

		// Right Leg
		drawBone(joints, KinectPV2.JointType_HipRight, KinectPV2.JointType_KneeRight);
		drawBone(joints, KinectPV2.JointType_KneeRight, KinectPV2.JointType_AnkleRight);
		drawBone(joints, KinectPV2.JointType_AnkleRight, KinectPV2.JointType_FootRight);

		// Left Leg
		drawBone(joints, KinectPV2.JointType_HipLeft, KinectPV2.JointType_KneeLeft);
		drawBone(joints, KinectPV2.JointType_KneeLeft, KinectPV2.JointType_AnkleLeft);
		drawBone(joints, KinectPV2.JointType_AnkleLeft, KinectPV2.JointType_FootLeft);

		drawJoint(joints, KinectPV2.JointType_HandTipLeft);
		drawJoint(joints, KinectPV2.JointType_HandTipRight);
		drawJoint(joints, KinectPV2.JointType_FootLeft);
		drawJoint(joints, KinectPV2.JointType_FootRight);

		drawJoint(joints, KinectPV2.JointType_ThumbLeft);
		drawJoint(joints, KinectPV2.JointType_ThumbRight);

		drawJoint(joints, KinectPV2.JointType_Head);
	}

	//draw joint
	void drawJoint(KJoint[] joints, int jointType) {
		pushMatrix();
		translate(joints[jointType].getX(), joints[jointType].getY(), joints[jointType].getZ());
		ellipse(0, 0, 25, 25);
		popMatrix();
	}

	//draw bone
	void drawBone(KJoint[] joints, int jointType1, int jointType2) {
		pushMatrix();
		translate(joints[jointType1].getX(), joints[jointType1].getY(), joints[jointType1].getZ());
		ellipse(0, 0, 25, 25);
		popMatrix();
		line(joints[jointType1].getX(), joints[jointType1].getY(), joints[jointType1].getZ(), joints[jointType2].getX(), joints[jointType2].getY(), joints[jointType2].getZ());
	}

	//draw hand state
	void drawHandState(KJoint joint) {
		noStroke();
		handState(joint.getState());
		pushMatrix();
		translate(joint.getX(), joint.getY(), joint.getZ());
		ellipse(0, 0, 70, 70);
		popMatrix();
	}

	/*
		Different hand state
		 KinectPV2.HandState_Open
		 KinectPV2.HandState_Closed
		 KinectPV2.HandState_Lasso
		 KinectPV2.HandState_NotTracked
	 */
	void handState(int handState) {
		switch(handState) {
		case KinectPV2.HandState_Open:
			fill(0, 255, 0);
			break;
		case KinectPV2.HandState_Closed:
			//getCmdrgbLightOn().control();
			fill(255, 0, 0);
			break;
		case KinectPV2.HandState_Lasso:
			fill(0, 0, 255);
			break;
		case KinectPV2.HandState_NotTracked:
			fill(255, 255, 255);
			break;
		}
	}

	public static void main(String _args[]) {
		PApplet.main(new String[] { kinectprojet.KinectProjet.class.getName() });
	}
}
