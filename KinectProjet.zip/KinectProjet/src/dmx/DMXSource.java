package dmx;

public interface DMXSource {
   public int get(int channel); // channel is 1..512
   public boolean hasChanged(); // used for transmission optimisation
   public void resetChanged();
}
