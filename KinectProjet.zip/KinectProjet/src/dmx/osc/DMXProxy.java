//  DMXProxy.java, client object
//  Created by Bernard Thirion on 26/01/2015

// Supported messages 
// ------------------
//
//  name/set/ 1..512 0..255

package dmx.osc;

import osc.as.OSCMessage;
import osc.stream.OSCSink;
import osc.space.proxies.ObjectProxy;
import dmx.DMXSink;


public class DMXProxy extends ObjectProxy implements DMXSink {

   private final static String SET = "set";

   private OSCMessage set;
      
   public DMXProxy (String objectName, OSCSink sink) {
      super(objectName, sink);
      set  = new OSCMessage(ObjectProxy.selector(objectName, SET), 2);
   }
   
   private boolean checkRange(int channel, int value) {
      return (channel >= 1) && (channel <= 512) &&
             (value   >= 0) && (value <= 255);
      
   }
   
   public void set(int channel, int value) { // channel is 1..512, value is 0..255
      if (checkRange(channel, value)) {
         set.setArgument(0, new Integer(channel));
         set.setArgument(1, new Integer(value));
         sink.send(set);
      } else {
         System.out.println("Illegal dmx message : channel => " + channel + " value " + value);
      }
   }
    
}
