// DMXFrame.java
// Created by Bernard Thirion 31/10/2011
// channeles are from 1 to LENGTH, values are from 0 to 255

package dmx;

public class DMXFrame implements DMXSource, DMXSink {
   
   public final static int LENGTH = 512; 

   private boolean changed = false;
   
   private int[] channels = new int[LENGTH];
   
   public DMXFrame() { 
 
   }
   
   public int get(int channel) {
      return channels[channel - 1]; 
   }
   
   public void set(int channel, int value) {
      if (get(channel) != value) {
         channels[channel - 1] = value;
         changed = true;
      }
   }
   
   public void set(DMXFrame from) {
      for (int i = 0; i < channels.length; i++) {
         channels[i] = from.channels[i];
      }
      changed = true;
   }
   
   public void set (byte[] bytes) {
      int max = Math.min(bytes.length, LENGTH);
      for (int i = 0; i < max; i++) {
         int value = bytes[i];
         if (value < 0) value += 256; 
         channels[i] = value; 
      }
      changed = true;
   }
   
   public byte[] bytes() {
      byte[] result = new byte[channels.length];
      for (int i = 0; i < channels.length; i++) {
         result[i] = (byte) (channels[i]%256);   // modulo not really required
      }
      return result; 
   }

   public boolean hasChanged() {
      return changed;
   }

   public void resetChanged() {
      changed = false;
   }
      
   private int clamp(int channel) {
      return Math.max(1, Math.min(channel, 512));
   }
   
   public void dump(int from, int to) {
      int first = clamp(from);
      int last  = clamp(to);
      for (int i = first ; i <= last; i ++) {
         System.out.println (i + " => " + get(i));
      }
   }

   public void dump() {
      this.dump(1, 512);
   }

}
