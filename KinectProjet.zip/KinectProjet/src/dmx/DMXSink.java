package dmx;

public interface DMXSink {
   public void set(int channel, int value); // channel is 1..512, value is 0..255
}
