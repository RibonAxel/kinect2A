// DMXMemoryInterface.java
// Created by Bernard Thirion 27/01/2015

// externally memories are indexed from 1 to N

package dmx.memory;

public interface DMXMemoryInterface {
   
   static final int MEMORY_FIRST =  1; // Lowest  memory name
   static final int MEMORY_LAST  = 12; // Highest memory name

   public void load (int from);
   public void store(int to  );
   
}
