//  DMXMemoryProxy.java, client object
//  Created by Bernard Thirion on 27/01/2015

// Supported messages 
// ------------------
//
//  .../name/load  1..N
//  .../name/store 1..N

package dmx.memory.osc;

import osc.as.OSCMessage;
import osc.stream.OSCSink;
import osc.space.proxies.ObjectProxy;
import dmx.memory.DMXMemoryInterface;


public class DMXMemoryProxy extends ObjectProxy implements DMXMemoryInterface {

   private final static String LOAD  = "load";
   private final static String STORE = "store";

   private OSCMessage load;
   private OSCMessage store;
      
   public DMXMemoryProxy (String objectName, OSCSink sink) {
      super(objectName, sink);
      load  = new OSCMessage(ObjectProxy.selector(objectName, LOAD ), 1);
      store = new OSCMessage(ObjectProxy.selector(objectName, STORE), 1);
   }
   
   private boolean validMemory(int memory) {
      return (memory >= MEMORY_FIRST) && (memory <= MEMORY_LAST);
   }
   
   public void load(int from) { 
      if (validMemory(from)) {
         load.setArgument(0, new Integer(from));
         sink.send(load);
      } else {
         System.out.println("Illegal load : memory => " + from);
      }
   }
 
   public void store(int to) { 
      if (validMemory(to)) {
         store.setArgument(0, new Integer(to));
         sink.send(store);
      } else {
         System.out.println("Illegal store : name => " + to);
      }
   }
   
}
